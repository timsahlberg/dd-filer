---
name: karrusel
description: Laver et færdigt Instagram-karruselopslag (1080x1350-slides, første slide bevæger sig) ud fra et Word/Google Docs/tekst-dokument og evt. billeder i 00_Indbakke/Karrusel, i kursistens brand og stil, og lægger slides + opslagstekst i 03_Final/Karrusel.
argument-hint: "[noter, eller navnet på dokumentet/mappen i indbakken]"
---

# Karruselopslag

Noter: **$ARGUMENTS**

Kør uden at spørge undervejs. Arbejd fra arbejdsmappen. Python `./_System/.venv/Scripts/python.exe`, scripts `${CLAUDE_PLUGIN_ROOT}/scripts/`. Læs `CLAUDE.md`, `_System/brand.json` og `_System/stil.md` først. Skriv dansk. Trinstatus i `udgivet.json` som i talkinghead-video.

## Ét dokument eller én mappe = ét opslag
I `00_Indbakke/Karrusel/`: et løst dokument (Word .docx, Google Docs, .txt, .rtf) eller en mappe med dokument + billeder/video. Ligger der kun dokumenter løst, er hvert sit eget opslag.
- `./_System/.venv/Scripts/python.exe "${CLAUDE_PLUGIN_ROOT}/scripts/inbox.py" claim karrusel` (`busy`/`empty`/`waiting` → stop). Slut altid med `release karrusel`.

## a) Projekt
Læs teksten: `./_System/.venv/Scripts/python.exe "${CLAUDE_PLUGIN_ROOT}/scripts/tekst.py" "00_Indbakke/Karrusel/<dokument eller mappe>"` (en .pages-fil kan ikke læses: bed om Word-eksport). Emne: 2–6 ord. `./_System/.venv/Scripts/python.exe "${CLAUDE_PLUGIN_ROOT}/scripts/new_project.py" karrusel "<emne>" --file="<dokument eller mappe>"` → `01_Projekter/Karrusel/KA-<nr>_<emne>_<dato>/`.

## b) Materialer
Se hvert billede i `1_Raw` med Read og hver video med et stillbillede. Notér hvad de viser, og hvor motivet sidder (til `focus`). Figurer/objekter kursisten selv har lagt i `02_Materialer/Figurer` (PNG med gennemsigtig baggrund) kan bruges.

## c) Manus (slides.json)
- **Kilde:** kun teksten og billederne. Opfind ingen tal, navne eller påstande.
- **Følg `_System/stil.md`** (antal slides, tekstmængde, slide-typer, forside). Som udgangspunkt 5–10 slides, aldrig over 20; overskrift 2–6 ord, brødtekst højst ca. 25 ord; højst ét `*accent*`-udtryk pr. slide.
- **Variation:** mindst 5 forskellige typer på 7+ slides, aldrig samme type mere end to gange i træk, og en anden forside/rytme end de seneste opslag (se deres `2_Projekt/slides.json`).
- **Slide 1 bevæger sig altid** (`motion`, 5 sek. løkke), og forsiden varierer mellem: `figure: "husfigur"` (et pixel-hus i brandets farve, der hopper og blinker, gerne `peek: true`), `notifikationer` (`messages` fra teksten), `likes` (kun tal fra teksten), `telefon` (`screen` = et billede), `objekt` (et PNG fra `02_Materialer/Figurer`), eller kursistens eget billede som `image` med en af dem. Har kursisten en stærk video, kan slide 1 være en `video`. Tekst: `title` (lille linje), `accent` (stor linje), `kicker` (pille). Frame 0 skal se færdig ud. Se motion-slidens frames ved 0, 1, 2,5 og 4 sek.: figuren må ikke dække tekst.
- **Typer** (felter øverst i `karrusel.py`): `cover`, `poster`, `point`, `image`, `split`, `duo`, `list`, `steps`, `cards`, `collage`, `stat`, `quote`, `compare`, `chat`, `phone`, `statement`, `story`, `wall`, `video`, `cta`, `letter`. Tekst uden billeder: brug `point` uden billede, `list`, `steps`, `compare`, `stat`, `quote`, `chat`, `letter`, `cta`.
- **Sidste slide:** `cta` (brandets `cta_word` + `cta_keyword`, plus hvad de får) eller `letter` med CTA'en i teksten.
Skriv `<projekt>/2_Projekt/slides.json`.

## d) Udkast → final
1. `./_System/.venv/Scripts/python.exe "${CLAUDE_PLUGIN_ROOT}/scripts/karrusel.py" render "<projekt>" --udkast`
2. Se `2_Projekt/udkast/oversigt.jpg` og hver slide: intet skåret, teksten ikke krympet for meget (forkort så), stavning, sammenhæng. Ret og kør igen, til det sidder.
3. `./_System/.venv/Scripts/python.exe "${CLAUDE_PLUGIN_ROOT}/scripts/karrusel.py" render "<projekt>"` → `3_Final` (næste version, overskriver aldrig). `check_final.py "<projekt>/3_Final"` skal være ok.

## e) Opslagstekst og levering
Skill `opslagstekst` med teksten og slides som kilde (teksten skal lægge op til at swipe) → `<projekt>/opslag.md`. `./_System/.venv/Scripts/python.exe "${CLAUDE_PLUGIN_ROOT}/scripts/deliver.py" "<projekt>"` → `03_Final/Karrusel/<projekt>/` med slides i rækkefølge (01, 02 …) og opslagsteksten.

## f) Svar
Kort: ID, antal slides, mappen i 03_Final, og at slides uploades i rækkefølge 01 → N (slide 01 er en video).
