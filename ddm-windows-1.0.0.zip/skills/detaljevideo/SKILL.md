---
name: detaljevideo
description: Klipper en cinematisk 9:16-detaljevideo på 10-30 sek. af uklippet råmateriale (drone, b-roll af en bolig eller et område) i 00_Indbakke/Detaljevideoer - finder selv de brugbare bidder, klipper på musikkens slag, uden tekst og logo - og lægger den i 03_Final/Detaljevideoer.
argument-hint: "[noter om stemning eller længde]"
---

# Detaljevideo

Noter: **$ARGUMENTS**

Kør uden at spørge undervejs. Arbejd fra arbejdsmappen. Python `./_System/.venv/Scripts/python.exe`, scripts `${CLAUDE_PLUGIN_ROOT}/scripts/`. Skriv dansk. Kun 9:16, 10–30 sek., **ingen tekst og intet logo**. Trinstatus i `udgivet.json`.

## Én mappe = én video
- `./_System/.venv/Scripts/python.exe "${CLAUDE_PLUGIN_ROOT}/scripts/inbox.py" claim detaljevideo` (`busy`/`empty`/`waiting` → stop). Slut altid med `release detaljevideo`.

## a) Projekt og brief
Emne fra mappenavnet/dokumentet (`tekst.py` på mappen). `./_System/.venv/Scripts/python.exe "${CLAUDE_PLUGIN_ROOT}/scripts/new_project.py" detaljevideo "<emne>" --file="<mappe>"`. Brief fra dokumentet: hvad der skal fremhæves, stemning, længde (standard 15–20 sek.). Klip med ★ i navnet skal med.

## b) Scan råmaterialet
`./_System/.venv/Scripts/python.exe "${CLAUDE_PLUGIN_ROOT}/scripts/detalje.py" scan "<projekt>"` (ca. 8 sek. pr. klip) → `2_Projekt/scan.json` (bedste bidder pr. klip: start, score, skarp, rolig, lys, bevaegelse) og kontaktark i `2_Projekt/scan/`. Se `oversigt.jpg` og klippenes ark med Read, og **vælg ud fra billederne, ikke kun scoren** (rolige skud over vand får lav skarphed, men kan være flottest). Fravælg skæve horisonter, mennesker tæt på, nummerplader, rod.

## c) Musik
`./_System/.venv/Scripts/python.exe "${CLAUDE_PLUGIN_ROOT}/scripts/detalje.py" musik` viser numrene i `02_Materialer/Musik` med tempo og længde. Vælg et, der passer til stemningen, og som ikke er brugt i de seneste detaljevideoer (se deres `2_Projekt/edit.json`). `detalje.py beats "02_Materialer/Musik/<nummer>"` → `beat_s` og `beats`; vælg `music_start` på et slag i nummerets stærkeste del (typisk 25–60 % inde). Ingen musik i mappen: `"music": null` (videoen laves stille, og kursisten lægger lyd på i Instagram; nævn det i svaret).

## d) Klip (edit.json)
`<projekt>/2_Projekt/edit.json` (felter øverst i `detalje.py`):
- **Fortælling:** etablering (bred drone) → tilgang (facade, omgivelser) → detaljer (indretning, materialer, lys, udsigt) → det stærkeste skud → roligt, bredt slut. Uden bolig: by → kvarter → bygninger → slut.
- **Rytme:** hvert skud er 2 slag (`2*beat_s`) eller 4 slag (`4*beat_s`); start og slut med 4 slag. Uden musik: 1,1–2,2 sek. pr. skud.
- **Slowmotion:** 50/60 fps → `speed` 0.5–0.7; 24–30 fps → 1.0. `start + dur*speed` inden for en kandidat. Vandrette optagelser: `crop_x` så motivet er i 9:16-udsnittet.
- `grade`: "cinematic" (standard) eller "neutral".

## e) Udkast → final
`detalje.py render "<projekt>" --udkast` → `2_Projekt/udkast/udkast.mp4`; tag et stillbillede midt i hvert skud og se dem (ryk, uskarpt, skæv horisont, motiv uden for udsnittet, to ens skud i træk). Ret og gentag. Final: `detalje.py render "<projekt>"` → `3_Final` (næste version). `check_final.py "<projekt>/3_Final"` skal være ok.

## f) Opslagstekst og levering
Skill `opslagstekst` ud fra dokumentet (område, bolig, stemning; ingen opfundne fakta) → `<projekt>/opslag.md`. `deliver.py "<projekt>"` → `03_Final/Detaljevideoer/`.

## g) Svar
Kort: ID, længde, antal skud, musiknummer (eller "uden musik"), hvor filen ligger. Skriv tilbagevendende ønsker fra kursisten (fx "flere detaljer, færre droneskud") ind i `_System/stil.md` under **Detaljevideoer**, så de gælder fremover.
