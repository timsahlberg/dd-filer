---
name: start
description: Opsætning af Den Digitale Mæglers content-system hos kursisten, trin for trin - tjekliste, installation, arbejdsmappe, brand, stil fra Instagram, musik, automatisk kørsel og en testvideo. Brug den, når kursisten skriver /start, "sæt systemet op", "kom i gang" eller lige har installeret plugin'en.
disable-model-invocation: true
---

# Opsætning af content-systemet (Windows)

Du guider en mægler, der ikke er teknisk, gennem hele opsætningen. Skriv på dansk, kort og venligt, ét trin ad gangen. Forklar hvad der sker, før du gør det, og vent på svar ved hvert "spørg". Brug AskUserQuestion til valg og ja/nej. Kør selv alle kommandoer, du kan; bed kun kursisten gøre det, der kræver deres egen handling (adgangskode, login, upload af filer).

Plugin-mappen: `${CLAUDE_PLUGIN_ROOT}`. Scripts: `${CLAUDE_PLUGIN_ROOT}/scripts/`.

**Genoptag:** findes der allerede en arbejdsmappe (spørg, eller søg efter `_System/ddm.json` i Dokumenter og i Google Drive-mappen), så læs `"opsaetning"` i `_System/ddm.json` og fortsæt fra det første trin, der ikke er `true`. Gem status efter hvert trin (`"opsaetning": {"tjekliste": true, ...}`).

## Trin 1 · Tjekliste (før noget installeres)
Vis listen og spørg punkt for punkt (AskUserQuestion, flere valg): "Sæt flueben ved det, du har":
1. **Claude-abonnement** (Pro eller Max) og **Claude-desktopappen** installeret. Den automatiske kørsel kræver desktopappen.
2. **Computeren er tændt og Claude-appen åben, når systemet skal arbejde.** Systemet kører på din egen computer, ikke i skyen. Lukker du computeren, venter dit materiale bare, til den er tændt igen.
3. **En pc med Windows 10 eller 11 (64-bit). Et NVIDIA-grafikkort gør transskription hurtigere, men er ikke nødvendigt.**
4. **Mindst 20 GB fri plads** (videoer fylder).
5. **Adgangskoden til computeren** (bruges til at installere programmer).
6. **Google Chrome** installeret (bruges til at lave slides og hente din hjemmeside).
7. **Valgfrit: Google Drive-programmet** ("Drive til computer"), hvis du vil have mappen online og dele den med andre.
8. **Valgfrit: logget ind på Instagram i Chrome** (gør det nemmere at hente stil-referencer).
Mangler 1, 2, 3, 4 eller 5: forklar hvorfor det er nødvendigt og stop, til det er på plads. 6–8 kan ordnes undervejs.

## Trin 2 · Installér programmerne
Forklar: "Nu installerer jeg de programmer, systemet bruger: ffmpeg (video), Node.js (grafik), uv (Python) og evt. Chrome. Det tager 5–15 minutter." Spørg om lov først (installationen accepterer programmernes licensvilkår), og installér kun det, der mangler (tjek med `--version` først).
1. Tjek winget: `winget --version`. Mangler det, så bed kursisten installere **App Installer** fra Microsoft Store og prøv igen.
2. Installér det, der mangler (et vindue kan spørge "Vil du tillade, at appen foretager ændringer?": bed kursisten trykke **Ja**):
   - `winget install --id Gyan.FFmpeg -e --accept-source-agreements --accept-package-agreements`
   - `winget install --id OpenJS.NodeJS.LTS -e --accept-source-agreements --accept-package-agreements`
   - `winget install --id astral-sh.uv -e --accept-source-agreements --accept-package-agreements`
   - Chrome, hvis den mangler: `winget install --id Google.Chrome -e --accept-source-agreements --accept-package-agreements`
3. **Genstart Claude:** nye programmer kan først findes, når Claude-appen er lukket helt og åbnet igen. Gem `"installeret_venter_genstart": true` i en lille fil `Documents/DDM-opsaetning.json`, bed kursisten lukke Claude (også i systembakken) og åbne den igen og skrive `/ddm-windows:start`; fortsæt så med tjekket her.
Tjek bagefter med `ffmpeg -version`, `npx --version` og `uv --version`. Fejler noget, så forklar præcis hvad og prøv igen; giv ikke op efter første fejl.

## Trin 3 · Vælg arbejdsmappe
Spørg (AskUserQuestion):
- **Lokal mappe (anbefalet, nemmest):** `C:\Users\<dit navn>\Documents\DDM-Content (Dokumenter\DDM-Content)`. Alt ligger på computeren.
- **Online via Google Drive:** kræver Google Drive-programmet. Mappen lægges i Drive-mappen (G:\My Drive eller G:\Mit drev (drevbogstavet kan være et andet)), så alt, også de færdige videoer, synkroniseres online og kan deles. Find den rigtige sti (`ls`/`dir` i Drive-mappen; "My Drive" eller "Mit drev"), og bekræft med kursisten.
- **Har de ingen Google-konto, så brug den lokale mappe.**
Opret mappen og Python-miljøet, og lav arbejdsmappen:
```
mkdir -p "<mappe>/_System"
uv venv --python 3.12 "<mappe>/_System/.venv"
uv pip install --python "<mappe>/_System/.venv/Scripts/python.exe" faster-whisper numpy opencv-python-headless yt-dlp gallery-dl pymupdf
"<mappe>/_System/.venv/Scripts/python.exe" "${CLAUDE_PLUGIN_ROOT}/scripts/setup_workspace.py" "<mappe>" --navn "<kursistens navn>" [--online]
```
Har computeren et NVIDIA-grafikkort (`nvidia-smi` virker), så tilbyd hurtigere transskription (valgfrit, ca. 1 GB): `uv pip install --python "<mappe>/_System/.venv/Scripts/python.exe" nvidia-cublas-cu12 nvidia-cudnn-cu12`. Systemet virker også uden; så bruges processoren.
Spørg derefter: "Må jeg give systemet lov til selv at køre sine egne værktøjer i din arbejdsmappe, så den automatiske kørsel ikke stopper og spørger hver gang?" Ja → kør `setup_workspace.py` igen med `--tilladelser`. Forklar, at det kun gælder systemets egne værktøjer i den mappe.
Kør `"<mappe>/_System/.venv/Scripts/python.exe" "${CLAUDE_PLUGIN_ROOT}/scripts/doctor.py"` fra arbejdsmappen, og vis resultatet som en tjekliste (✓/✗). Alt påkrævet skal være ✓, før du går videre. Hent også HyperFrames én gang: `npx --yes hyperframes --version`.

**Herfra arbejder du i arbejdsmappen** (`cd "<mappe>"`), så alle stier er relative til den. Python er `./_System/.venv/Scripts/python.exe`.

## Trin 4 · Dit brand
Kør skill `brand` (følg den helt). Den guider kursisten i at hente den visuelle identitet ind (brand-PDF, logo, hjemmeside) og låser farver, fonte, CTA og tone.

## Trin 5 · Din stil
Kør skill `stil`. Kursisten finder 2–4 Instagram-opslag, de kan lide (reels og karruseller fra andre profiler), og systemet analyserer dem og låser stilen.

## Trin 6 · Musik (til detaljevideoer)
Forklar: "Detaljevideoer klippes til musik. Du skal selv vælge numre, som du har ret til at bruge på Instagram." Guide trin for trin:
1. Gå til **pixabay.com/music** (gratis, ingen konto nødvendig til de fleste numre) eller **YouTube Audio Library** (kræver Google-konto).
2. Søg på fx "cinematic", "piano ambient", "corporate inspiring". Vælg 5–10 instrumentale numre.
3. Download dem og læg dem i `02_Materialer/Musik`.
4. Alternativ: lad mappen være tom; så laves detaljevideoerne uden musik, og du lægger lyd på direkte i Instagram (trending lyd virker ofte bedst).
Kør `./_System/.venv/Scripts/python.exe "${CLAUDE_PLUGIN_ROOT}/scripts/detalje.py" musik` for at vise, hvad der ligger.

## Trin 7 · Automatisk kørsel
Spørg, om systemet skal tjekke indbakken af sig selv hvert 15. minut. Ja → opret en planlagt opgave med værktøjet til planlagte opgaver (scheduled tasks / `create_scheduled_task`), cron `*/15 * * * *`, titel "DDM · nyt i indbakken", og denne prompt (udfyld stierne):
```
Du er {navn}s automatiske SoMe-produktion. Skriv på dansk. Arbejdsmappe: <mappe>.
1. cd til arbejdsmappen og kør: ./_System/.venv/Scripts/python.exe "${CLAUDE_PLUGIN_ROOT}/scripts/inbox.py" status talking-head, ... status karrusel, ... status detaljevideo.
2. Er ingen "ready": svar kun "Intet nyt" og stop.
3. For hvert format, der er "ready": følg plugin-skillen (talkinghead-video, karrusel eller detaljevideo) uden at spørge, én ting ad gangen,
   start med inbox.py claim <format> og slut altid med inbox.py release <format>.
4. Slut med en kort liste over det færdige i 03_Final, eller hvad der fejlede.
```
Forklar: den kører kun, når computeren er tændt og Claude-appen åben. Uden automatisk kørsel bruger kursisten bare kommandoerne selv.

## Trin 8 · Prøv det
Lav en testkarrusel sammen med kursisten: bed dem skrive 3–5 linjer om et emne, de kender (fx "3 fejl når man sælger selv"), gem det som `00_Indbakke/Karrusel/test.txt`, og kør skill `karrusel` på det. Vis resultatet (`2_Projekt/udkast/oversigt.jpg` og `03_Final/Karrusel/...`). Spørg om farver og stil sidder rigtigt; ret i brand.json/stil.md og kør igen, til de er glade.

## Trin 9 · Færdig
Vis en kort oversigt:
- Hvor arbejdsmappen ligger, og at Claude skal åbnes i den mappe (i desktopappen: vælg mappen, når du starter en ny session).
- Sådan bruges det: læg materiale i `00_Indbakke/<format>` (eller skriv kommandoen), og find det færdige i `03_Final/<format>` sammen med opslagsteksten (`*_opslag.txt`).
- Kommandoerne: `/ddm-windows:talkinghead-video`, `/ddm-windows:karrusel`, `/ddm-windows:detaljevideo`, `/ddm-windows:hjaelp`.
- Vigtigt: computeren tændt, upload hele mapper på én gang, skriv dokumenter færdige før de lægges i indbakken, gennemse altid før du poster.
