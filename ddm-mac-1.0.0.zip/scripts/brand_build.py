"""Builds the brand files from _System/brand.json: fonts in _System/fonts and _System/brand.css.

  python brand_build.py            (run from the workspace after brand.json is written)

brand.json (written by the brand skill with the kursist):
  {"navn": "...", "firma": "...", "footer": "Navn · Firma", "handle": "@...",
   "cta_word": "Kommentér", "cta_keyword": "GUIDE", "cta_tekst": "Kommentér GUIDE, så sender jeg dig ...",
   "tone": "kort beskrivelse af tonen", "sprog": "da",
   "farver": {"bg", "surface", "line", "chip_line", "text", "muted", "accent", "on_accent", "good", "bad", "info"},
   "fonte": {"head": "Google Font-navn", "body": "...", "mono": "..."},
   "font_filer": {"head": "02_Materialer/Brand/MinFont.ttf"}   (optional: own font files instead of Google Fonts),
   "logo": "02_Materialer/Brand/logo.png", "reel_layout": "split" | "fuld", "undertekster": "ord" | "linje"}
Fonts named in "fonte" are downloaded from Google Fonts (free licence) unless a file is given in "font_filer".
Warns when text and background have too little contrast (below 4.5:1).
"""
import json, os, re, shutil, sys, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import paths  # noqa: E402

OLD_UA = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.112 Safari/534.30"}
BUNDLED = {"Bricolage Grotesque", "Instrument Sans", "JetBrains Mono"}


def lum(h):
    c = [int(h[i:i + 2], 16) / 255 for i in (1, 3, 5)]
    c = [x / 12.92 if x <= 0.03928 else ((x + 0.055) / 1.055) ** 2.4 for x in c]
    return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]


def contrast(a, b):
    la, lb = sorted((lum(a), lum(b)), reverse=True)
    return (la + 0.05) / (lb + 0.05)


def google_font(family, dst):
    """Download the upright weights 400-800 of a Google Font (woff/ttf). Returns [(file, weight)]."""
    fam = family.replace(" ", "+")
    css = ""
    for query in (fam + ":wght@400;500;600;700;800", fam + ":wght@400;700", fam):
        try:
            with urllib.request.urlopen(urllib.request.Request(f"https://fonts.googleapis.com/css2?family={query}", headers=OLD_UA), timeout=20) as r:
                css = r.read().decode()
                break
        except Exception:
            continue
    got = []
    for block in re.findall(r"@font-face\s*{[^}]+}", css):
        w = re.search(r"font-weight:\s*(\d+)", block)
        u = re.search(r"url\((https://[^)]+?\.(ttf|woff2?|otf))\)", block)
        if u and "font-style: italic" not in block:
            weight = w.group(1) if w else "400"
            fn = re.sub(r"[^A-Za-z0-9]", "", family) + f"-{weight}.{u.group(2)}"
            with urllib.request.urlopen(u.group(1), timeout=30) as r:
                open(os.path.join(dst, fn), "wb").write(r.read())
            got.append((fn, weight))
    return got


def main():
    paths.load()
    sysdir = os.path.join(paths.ROOT, "_System")
    b = json.load(open(os.path.join(sysdir, "brand.json"), encoding="utf-8"))
    fonts_dir = os.path.join(sysdir, "fonts")
    os.makedirs(fonts_dir, exist_ok=True)
    faces, report = [], {}
    for role, fam in (b.get("fonte") or {}).items():
        if not fam:
            continue
        own = (b.get("font_filer") or {}).get(role)
        if own:
            src = os.path.join(paths.ROOT, own)
            fn = os.path.basename(src)
            shutil.copy2(src, os.path.join(fonts_dir, fn))
            faces.append(f'@font-face {{ font-family: "{fam}"; src: url("fonts/{fn}"); font-weight: 100 900; }}')
            report[role] = f"egen fil {fn}"
        elif fam in BUNDLED:
            report[role] = "følger med systemet"
        else:
            got = google_font(fam, fonts_dir)
            if not got:
                report[role] = f"IKKE FUNDET på Google Fonts: {fam} (vælg en anden, eller læg font-filen i 02_Materialer/Brand)"
                continue
            for fn, w in got:
                faces.append(f'@font-face {{ font-family: "{fam}"; src: url("fonts/{fn}"); font-weight: {w}; }}')
            report[role] = f"hentet {len(got)} vægte"
    f = b.get("farver") or {}
    keymap = {"bg": "--bg", "surface": "--surface", "line": "--line", "chip_line": "--chip-line", "text": "--text", "muted": "--muted",
              "accent": "--accent", "on_accent": "--on-accent", "good": "--accent-pastel", "bad": "--bad-text"}
    root = [f"  {v}: {f[k]};" for k, v in keymap.items() if f.get(k)]
    fo = b.get("fonte") or {}
    for k, v in (("head", "--head"), ("body", "--body"), ("mono", "--mono")):
        if fo.get(k):
            fallback = "monospace" if k == "mono" else "sans-serif"
            root.append(f'  {v}: "{fo[k]}", {fallback};')
    # the .card/.tag helpers on slides use these too
    css = "/* Bygget af brand_build.py ud fra _System/brand.json. Ret brand.json og kør igen i stedet for at rette her. */\n"
    css += "\n".join(faces) + "\n:root {\n" + "\n".join(root) + "\n}\n"
    open(os.path.join(sysdir, "brand.css"), "w", encoding="utf-8").write(css)
    warn = []
    if f.get("text") and f.get("bg") and contrast(f["text"], f["bg"]) < 4.5:
        warn.append(f"Tekst på baggrund har lav kontrast ({contrast(f['text'], f['bg']):.1f}:1). Vælg lysere tekst eller mørkere baggrund.")
    if f.get("on_accent") and f.get("accent") and contrast(f["on_accent"], f["accent"]) < 4.5:
        warn.append("Teksten på accentfarven er svær at læse. Brug sort eller hvid som on_accent.")
    print(json.dumps({"brand_css": os.path.join(sysdir, "brand.css").replace("\\", "/"), "fonte": report, "advarsler": warn}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
