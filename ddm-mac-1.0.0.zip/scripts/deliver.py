"""Puts the finished files of a project in 03_Final (if the workspace lies in the Google Drive app, it is synced online).

  python deliver.py <projektmappe>

03_Final holds only the newest version of each video: a _v2 replaces the _v1 there, while the project's own 3_Final keeps
every version. Talking-head and detaljevideo files lie loose in 03_Final/<format>/; a karrusel gets a folder per post, and
only its highest version as a whole is kept (a v2 with fewer slides leaves no v1 slides behind).
The project's opslag.md (the post texts) goes along as <ID>_<emne>_opslag.txt. Prints JSON with the delivered files.
"""
import json, os, re, shutil, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import paths  # noqa: E402

MEDIA = (".mp4", ".mov", ".m4v", ".png", ".jpg", ".jpeg")


def latest(files, whole=False):
    if whole:
        vers = {f: int(m.group(1)) for f in files if (m := re.search(r"_v(\d+)\.\w+$", f))}
        top = max(vers.values(), default=0)
        return sorted(f for f in files if vers.get(f, 0) == top), {re.sub(r"_v\d+\.\w+$", "", f) for f in files}
    best = {}
    for f in files:
        m = re.match(r"(.+)_v(\d+)(\.\w+)$", f)
        base, n = (m.group(1), int(m.group(2))) if m else (f, 0)
        if base not in best or n > best[base][0]:
            best[base] = (n, f)
    return sorted(f for _, f in best.values()), set(best)


def main(project_dir):
    paths.load(project_dir)
    project = os.path.abspath(project_dir)
    name = os.path.basename(project)
    final = os.path.join(project, "3_Final")
    files = sorted(f for f in os.listdir(final) if f.lower().endswith(MEDIA))
    if not files:
        sys.exit(f"Ingen færdige filer i {final}")
    _, fmt = paths.format_of_project(name)
    newest, bases = latest(files, whole=bool(fmt) and not fmt.get("finals_flat"))
    out = paths.finals_dir(project)
    os.makedirs(out, exist_ok=True)
    for f in newest:
        dst = os.path.join(out, f)
        if not os.path.exists(dst) or os.path.getsize(dst) != os.path.getsize(os.path.join(final, f)):
            shutil.copy2(os.path.join(final, f), dst)
    removed = []
    for f in os.listdir(out):
        m = re.match(r"(.+)_v\d+\.\w+$", f)
        if f not in newest and m and m.group(1) in bases:
            os.remove(os.path.join(out, f))
            removed.append(f)
    opslag = os.path.join(project, "opslag.md")
    if os.path.exists(opslag):
        txt = name.rsplit("_", 1)[0] + "_opslag.txt"
        shutil.copy2(opslag, os.path.join(out, txt))
        newest = newest + [txt]
    print(json.dumps({"project": name, "mappe": out.replace("\\", "/"), "filer": newest, "fjernet_gamle": removed,
                      "online": bool(paths.CFG.get("online"))}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main(sys.argv[1] if len(sys.argv) > 1 else sys.exit(__doc__))
