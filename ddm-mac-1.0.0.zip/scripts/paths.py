"""Shared paths and settings for the Den Digitale Mægler content system (Mac and Windows).

The kursist's workspace is the folder the setup created (a local folder, or one inside the Google Drive app). It holds
00_Indbakke, 01_Projekter, 02_Materialer, 03_Final and _System/ddm.json. Scripts find it by walking up from the
current folder to the first one with _System/ddm.json (Claude runs them from the workspace), or from DDM_WORKSPACE.
"""
import json, os, platform, shutil, sys

PLUGIN = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSETS = os.path.join(PLUGIN, "assets")
IS_MAC = platform.system() == "Darwin"
IS_WIN = platform.system() == "Windows"

FORMATS = {
    "talking-head": {"code": "TH", "folder": "Talking-head", "label": "Talking-head", "aliases": ["th", "reel", "talkinghead"], "finals_flat": True},
    "karrusel": {"code": "KA", "folder": "Karrusel", "label": "Karrusel", "aliases": ["ka", "carousel"], "finals_flat": False, "inbox_mode": "folder"},
    "detaljevideo": {"code": "DV", "folder": "Detaljevideoer", "label": "Detaljevideo", "aliases": ["dv", "detalje", "detaljevideoer"], "finals_flat": True, "inbox_mode": "folder"},
}


def find_root(start=None):
    env = os.environ.get("DDM_WORKSPACE")
    if env and os.path.exists(os.path.join(env, "_System", "ddm.json")):
        return os.path.abspath(env)
    d = os.path.abspath(start or os.getcwd())
    while True:
        if os.path.exists(os.path.join(d, "_System", "ddm.json")):
            return d
        up = os.path.dirname(d)
        if up == d:
            sys.exit("Fandt ikke din arbejdsmappe (_System/ddm.json). Åbn Claude i den mappe, opsætningen lavede, eller kør opsætningen først.")
        d = up


ROOT = None
CFG = {}


def load(start=None):
    global ROOT, CFG
    ROOT = find_root(start)
    CFG = json.load(open(os.path.join(ROOT, "_System", "ddm.json"), encoding="utf-8"))
    return ROOT, CFG


def brand():
    p = os.path.join(ROOT, "_System", "brand.json")
    return json.load(open(p, encoding="utf-8")) if os.path.exists(p) else {}


def find_format(name):
    key = name.lower()
    for k, f in FORMATS.items():
        if key == k or key in f.get("aliases", []) or key == f["code"].lower():
            return k, f
    return None, None


def format_of_project(project):
    return find_format(os.path.basename(project.rstrip("/\\")).split("-", 1)[0])


def inbox_dir(fmt):
    return os.path.join(ROOT, "00_Indbakke", fmt["folder"])


def projects_dir(fmt):
    return os.path.join(ROOT, "01_Projekter", fmt["folder"])


def finals_dir(project):
    _, fmt = format_of_project(project)
    base = os.path.join(ROOT, "03_Final", fmt["folder"])
    return base if fmt.get("finals_flat") else os.path.join(base, os.path.basename(project.rstrip("/\\")))


def chrome():
    """Path to Chrome (or Edge on Windows) for rendering slides."""
    cands = []
    if IS_MAC:
        cands = ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                 os.path.expanduser("~/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
                 "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
                 "/Applications/Chromium.app/Contents/MacOS/Chromium"]
    elif IS_WIN:
        pf = [os.environ.get("PROGRAMFILES", r"C:\Program Files"), os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)"),
              os.environ.get("LOCALAPPDATA", "")]
        cands = [os.path.join(p, "Google", "Chrome", "Application", "chrome.exe") for p in pf if p] + \
                [os.path.join(p, "Microsoft", "Edge", "Application", "msedge.exe") for p in pf if p]
    else:
        cands = [shutil.which(x) or "" for x in ("google-chrome", "chromium", "chromium-browser")]
    for c in [CFG.get("chrome")] + cands:
        if c and os.path.exists(c):
            return c
    return None


def npx():
    return shutil.which("npx.cmd" if IS_WIN else "npx") or shutil.which("npx")
