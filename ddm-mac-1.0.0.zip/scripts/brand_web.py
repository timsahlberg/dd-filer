"""Reads a website for brand clues: colours, fonts, logo and screenshots.

  python brand_web.py <url> [ud-mappe]      (default ud-mappe: 02_Materialer/Brand/fra-hjemmeside)

Fetches the front page and up to 8 of its stylesheets, counts the colours (hex/rgb) and font families used, finds
Google Fonts links, logo candidates (img/svg with "logo", og:image, apple-touch-icon) and downloads them, and takes a
desktop and a mobile screenshot with Chrome. Prints JSON; Claude looks at the screenshots and logo and decides the palette.
"""
import collections, json, os, re, subprocess, sys, urllib.parse, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import paths  # noqa: E402

UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36"}


def get(url, binary=False):
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=20) as r:
            data = r.read()
            return data if binary else data.decode("utf-8", errors="replace")
    except Exception:
        return b"" if binary else ""


def norm_hex(h):
    h = h.lower()
    if len(h) == 4:
        h = "#" + "".join(c * 2 for c in h[1:])
    return h.upper()


def main():
    url = sys.argv[1] if len(sys.argv) > 1 else sys.exit(__doc__)
    if not url.startswith("http"):
        url = "https://" + url
    try:
        paths.load()
        out = sys.argv[2] if len(sys.argv) > 2 else os.path.join(paths.ROOT, "02_Materialer", "Brand", "fra-hjemmeside")
    except SystemExit:
        out = sys.argv[2] if len(sys.argv) > 2 else "fra-hjemmeside"
    os.makedirs(out, exist_ok=True)
    page = get(url)
    if not page:
        sys.exit(f"Kunne ikke hente {url}. Tjek adressen, eller upload din visuelle identitet som fil i stedet.")
    css_urls = [urllib.parse.urljoin(url, h) for h in re.findall(r'<link[^>]+rel=["\']?stylesheet["\']?[^>]*href=["\']([^"\']+)', page, re.I)]
    css_urls += [urllib.parse.urljoin(url, h) for h in re.findall(r'<link[^>]+href=["\']([^"\']+\.css[^"\']*)', page, re.I)]
    css = "\n".join(re.findall(r"<style[^>]*>(.*?)</style>", page, re.S | re.I))
    seen = []
    for c in css_urls:
        if c not in seen and len(seen) < 8:
            seen.append(c)
            css += "\n" + get(c)
    text = page + "\n" + css
    colors = collections.Counter(norm_hex(h) for h in re.findall(r"#[0-9a-fA-F]{6}\b|#[0-9a-fA-F]{3}\b", text))
    for r, g, b in re.findall(r"rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)", text):
        colors["#%02X%02X%02X" % (int(r), int(g), int(b))] += 1
    variables = dict(re.findall(r"(--[\w-]*(?:color|colour|primary|accent|brand|bg|background|text)[\w-]*)\s*:\s*(#[0-9a-fA-F]{3,6})", css, re.I)[:40])
    fonts = collections.Counter()
    for f in re.findall(r"font-family\s*:\s*([^;}{]+)", text, re.I):
        first = f.split(",")[0].strip().strip("'\"")
        if first and not first.startswith("var(") and first.lower() not in ("inherit", "initial", "sans-serif", "serif", "monospace", "system-ui", "-apple-system"):
            fonts[first] += 1
    gfonts = sorted(set(urllib.parse.unquote(m).replace("+", " ") for m in re.findall(r"fonts\.googleapis\.com/css2?\?family=([^&\"':]+)", text)))
    logos = []
    for m in re.finditer(r'<img[^>]+>', page, re.I):
        tag = m.group(0)
        if re.search(r"logo", tag, re.I):
            src = re.search(r'src=["\']([^"\']+)', tag)
            if src:
                logos.append(urllib.parse.urljoin(url, src.group(1)))
    for pat in (r'property=["\']og:image["\'][^>]+content=["\']([^"\']+)', r'content=["\']([^"\']+)["\'][^>]+property=["\']og:image',
                r'rel=["\']apple-touch-icon["\'][^>]+href=["\']([^"\']+)', r'rel=["\']icon["\'][^>]+href=["\']([^"\']+)'):
        logos += [urllib.parse.urljoin(url, x) for x in re.findall(pat, page, re.I)]
    saved = []
    for k, l in enumerate(dict.fromkeys(logos)):
        if k >= 6:
            break
        data = get(l, binary=True)
        if data:
            ext = os.path.splitext(urllib.parse.urlparse(l).path)[1][:5] or ".png"
            p = os.path.join(out, f"logo_kandidat_{k + 1}{ext}")
            open(p, "wb").write(data)
            saved.append(p.replace("\\", "/"))
    shots = []
    ch = paths.chrome()
    if ch:
        for name, size in (("hjemmeside_desktop.png", "1440,2400"), ("hjemmeside_mobil.png", "430,2400")):
            p = os.path.join(out, name)
            subprocess.run([ch, "--headless=new", "--disable-gpu", "--hide-scrollbars", f"--window-size={size}", "--virtual-time-budget=8000",
                            f"--screenshot={p}", url], capture_output=True, timeout=120)
            if os.path.exists(p):
                shots.append(p.replace("\\", "/"))
    print(json.dumps({"url": url, "farver_mest_brugt": colors.most_common(14), "css_variabler": variables,
                      "fonte_mest_brugt": fonts.most_common(8), "google_fonts": gfonts, "logo_filer": saved, "skaermbilleder": shots},
                     ensure_ascii=False, indent=1))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
