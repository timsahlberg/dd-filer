"""EXAMPLE build file for one reel. Copy it to <projekt>/2_Projekt/build_v1.py and rewrite the scenes for the new video.

Story: hook that names the problem -> the promise ("5 ting") -> one chapter per point -> recap -> CTA with the brand keyword.
A graphics scene (split) has a header: eb = small mono line ("02 · Lyden"), h = headline, amb = the part in the accent
colour. Use full("sX", a, b) for 1-2 s of the person in full screen at punch lines; chapter() at each new point.
Scenes must follow each other without gaps from 0 to R.DUR. Anchor every beat to a word with T("ord", after).
Classes you can use in bodies: card (+ hi), tag (good/bad/info/ghost), ck (tick), pill (+ no), phone + scr (an image or
video in assets/), chipg (+ ml label, v value), big, acc (accent colour), row, sb, abs.
Put images/videos you show in 2_Projekt/film/assets/ before build() (e.g. a screenshot from 02_Materialer).
"""
import os, sys

PLUGIN_SCRIPTS = r"PLUGIN_ROOT_HER/scripts"     # Claude replaces PLUGIN_ROOT_HER with the plugin folder
sys.path.insert(0, PLUGIN_SCRIPTS)
import reel_engine as R  # noqa: E402

R.init(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))   # the project folder (this file lies in 2_Projekt)
T, up, pop = R.T, R.up, R.pop

POINTS = ["Lyset", "Lyden", "Kameraet", "Fokus", "Højden"]


def pills(sid, on):
    out = []
    for i, t in enumerate(POINTS):
        txt = f'<span style="{"" if on else "filter:blur(8px);opacity:.6"}">{t}</span>'
        ck = f'<span class="ck" id="{sid}-ck{i}">✓</span>' if on else ""
        out.append(f'<div class="pill {sid}-p" id="{sid}-p{i}"><span class="no">0{i + 1}</span>{txt}{ck}</div>')
    return f'<div style="display:flex;flex-direction:column;gap:22px;width:660px">{"".join(out)}</div>'


# 1) hook: the problem as tags
R.scene("s01", 0.0, T("fem", 4) - 0.1,
        '<div style="position:relative;width:860px;height:600px">'
        '<span class="tag bad abs s01-t" style="left:40px;top:120px">✕ Mørkt</span>'
        '<span class="tag bad abs s01-t" style="right:40px;top:280px">✕ Dårlig lyd</span>'
        '<span class="tag bad abs s01-t" style="left:80px;top:440px">✕ Skæv vinkel</span></div>',
        [up(".s01-t", 0.6)],
        eb="Mobilvideo · 5 ting", h="Det er ikke din telefon,", amb="der er problemet.")

# 2) the promise: blurred list
R.scene("s02", T("fem", 4) - 0.1, T("første", 8) - 0.1, pills("s02", False), [up(".s02-p", T("fem", 4))],
        eb="Det jeg retter først", h="Fem ting.", amb="Hver gang.")

# 3) chapter + a point with two cards
R.chapter("s03", T("første", 8) - 0.1, T("vinduet", 9) - 0.3, "01", "Lyset.")
R.scene("s04", T("vinduet", 9) - 0.3, T("anden", 14) - 0.1,
        '<div style="display:flex;gap:30px;width:860px">'
        '<div class="card hi" id="s04-a" style="flex:1;padding:34px;display:flex;flex-direction:column;gap:18px;align-items:center">'
        '<b class="big" style="font-size:46px">Mod vinduet</b><span class="tag good"><span class="ck">✓</span>Lyst ansigt</span></div>'
        '<div class="card" id="s04-b" style="flex:1;padding:34px;display:flex;flex-direction:column;gap:18px;align-items:center">'
        '<b class="big" style="font-size:46px">Ryggen til</b><span class="tag bad">✕ Silhuet</span></div></div>',
        [up("#s04-a", T("vinduet", 9)), up("#s04-b", T("ryggen", 10))],
        eb="01 · Lyset", h="Ansigtet mod", amb="vinduet.")

# 4) a punch line in full screen, then a big number
R.full("s05", T("anden", 14) - 0.1, T("procent", 16) - 0.2)
R.scene("s06", T("procent", 16) - 0.2, T("opsummering", 20) - 0.1,
        '<div class="chipg" id="s06-c" style="align-items:center;padding:40px 60px"><span class="ml">Seere der bliver</span>'
        '<span class="v acc" style="font-size:150px">80 %</span></div>',
        [pop("#s06-c", T("procent", 16))],
        eb="02 · Lyden", h="Dårlig lyd", amb="= swipe.")

# 5) recap with ticks, then the CTA
R.scene("s07", T("opsummering", 20) - 0.1, T("kommentér", 26) - 0.1, pills("s07", True),
        [up(".s07-p", T("opsummering", 20))] + [pop(f"#s07-ck{i}", T("opsummering", 20) + 0.5 + i * 0.35) for i in range(5)],
        eb="Opsamling", h="Ret de", amb="fem ting.")
R.cta("s08", T("kommentér", 26) - 0.1, R.DUR)

R.EMPH += [("fem", 4), ("vinduet", 9), ("procent", 16)]

if __name__ == "__main__":
    R.build(musik=None)          # or musik="02_Materialer/Musik/<nummer>.mp3"
