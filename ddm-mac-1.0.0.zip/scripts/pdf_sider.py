"""Turns a PDF (e.g. a brand guide) into PNG pages so Claude can look at them, and prints its text. Uses PyMuPDF.

  python pdf_sider.py <fil.pdf> [ud-mappe] [--max 30]      (default ud-mappe: next to the PDF, <navn>_sider/)

Prints JSON with the page images and the text of each page (colour codes and font names are often in the text).
"""
import json, os, sys


def main():
    a = sys.argv[1:]
    if not a:
        sys.exit(__doc__)
    mx = 30
    if "--max" in a:
        i = a.index("--max"); mx = int(a[i + 1]); del a[i:i + 2]
    src = a[0]
    out = a[1] if len(a) > 1 else os.path.splitext(src)[0] + "_sider"
    os.makedirs(out, exist_ok=True)
    import pymupdf
    doc = pymupdf.open(src)
    pages = []
    for i, page in enumerate(doc):
        if i >= mx:
            break
        p = os.path.join(out, f"side_{i + 1:02d}.png")
        page.get_pixmap(dpi=110).save(p)
        pages.append({"side": i + 1, "billede": p.replace("\\", "/"), "tekst": page.get_text()[:1500]})
    print(json.dumps({"pdf": src, "sider_i_alt": len(doc), "sider": pages}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
