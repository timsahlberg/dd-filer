"""Checks finals with ffprobe before anything is uploaded.  python _System/scripts/check_final.py <fil-eller-mappe> [...]

Video (talking-head and the like): a 9:16 H.264 MP4 at 1080x1920 with an AAC audio track with real sound (not silence),
3 s to 3 min long.
Karrusel (files named KA-...): every slide is 1080x1350 (4:5); a .png/.jpg slide just needs that size, a video slide is
H.264 (AAC if it has sound) and 3 to 60 s. A folder also gets a set check: the newest version has 2 to 20 slides,
numbered 01, 02, ... without gaps.
Prints one JSON line per file (and one for the set) and exits 1 if anything fails.
"""
import json, os, re, subprocess, sys

IMAGES = (".png", ".jpg", ".jpeg")


def probe(path):
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=codec_type,codec_name,width,height:format=duration,format_name",
                        "-of", "json", path], capture_output=True, text=True)
    if r.returncode:
        return None
    return json.loads(r.stdout)


def loudness(path):
    r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", path, "-vn", "-af", "ebur128", "-f", "null", "-"], capture_output=True, text=True)
    m = re.findall(r"I:\s+(-?[\d.]+) LUFS", r.stderr)
    return float(m[-1]) if m else None


def check(path):
    issues = []
    carousel = os.path.basename(path).startswith("KA-")
    p = probe(path)
    if not p:
        return {"file": path, "ok": False, "issues": ["ffprobe kunne ikke læse filen"]}
    v = [s for s in p["streams"] if s["codec_type"] == "video"]
    a = [s for s in p["streams"] if s["codec_type"] == "audio"]
    size = (1080, 1350) if carousel else (1080, 1920)
    if not v:
        return {"file": os.path.basename(path), "ok": False, "issues": ["intet billede/videospor"]}
    if (v[0].get("width"), v[0].get("height")) != size:
        issues.append(f"opløsning {v[0].get('width')}x{v[0].get('height')}, ikke {size[0]}x{size[1]}")
    if path.lower().endswith(IMAGES):
        return {"file": os.path.basename(path), "ok": not issues, "issues": issues}
    dur = float(p["format"].get("duration", 0))
    if v[0].get("codec_name") != "h264":
        issues.append(f"video er {v[0].get('codec_name')}, ikke h264")
    if a and a[0].get("codec_name") != "aac":
        issues.append(f"lyd er {a[0].get('codec_name')}, ikke aac")
    lufs = None
    if not carousel:
        if not a:
            issues.append("intet lydspor")
        lufs = loudness(path) if a else None
        if a and (lufs is None or lufs < -30) and not os.path.basename(path).startswith("DV-"):  # a DV may be silent (sound added in Instagram)
            issues.append(f"lyden er næsten stille ({lufs} LUFS)")
    lo, hi = (3, 60) if carousel else (3, 180)
    if not lo <= dur <= hi:
        issues.append(f"længde {dur:.1f} s ligger uden for {lo} til {hi} s")
    return {"file": os.path.basename(path), "ok": not issues, "duration": round(dur, 2), "lufs": lufs, "issues": issues}


def check_set(folder, files):
    """Karrusel: the newest version must be 2-20 slides numbered 01..N."""
    vers = {f: int(m.group(1)) for f in files if (m := re.search(r"_v(\d+)\.\w+$", f))}
    top = max(vers.values(), default=0)
    nums = sorted(int(m.group(1)) for f in files if vers.get(f) == top and (m := re.search(r"_(\d{2})_v\d+\.\w+$", f)))
    issues = []
    if not 2 <= len(nums) <= 20:
        issues.append(f"v{top} har {len(nums)} slides, Instagram kræver 2 til 20")
    if nums != list(range(1, len(nums) + 1)):
        issues.append(f"slidenumrene er ikke 01..{len(nums):02d} uden huller: {nums}")
    return {"file": f"{os.path.basename(folder)} (karrusel v{top})", "ok": not issues, "slides": len(nums), "issues": issues}


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    paths, sets = [], []
    for a in sys.argv[1:]:
        if os.path.isdir(a):
            fs = [f for f in sorted(os.listdir(a)) if f.lower().endswith((".mp4", ".mov") + IMAGES) and not f.startswith("oversigt")]
            paths += [os.path.join(a, f) for f in fs]
            if any(f.startswith("KA-") for f in fs):
                sets.append(check_set(a, [f for f in fs if f.startswith("KA-")]))
        else:
            paths.append(a)
    if not paths:
        sys.exit(__doc__)
    results = [check(p) for p in paths] + sets
    for r in results:
        print(json.dumps(r, ensure_ascii=False))
    sys.exit(0 if all(r["ok"] for r in results) else 1)
