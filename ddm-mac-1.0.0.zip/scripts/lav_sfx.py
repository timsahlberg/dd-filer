"""Makes the small sound effects the reels use, with ffmpeg only, so there is nothing to license.

  python lav_sfx.py <mappe>

whoosh-short, whoosh, click-soft, click, pop, chime, impact-bass-1, error, key-press (mp3, quiet, short).
"""
import os, subprocess, sys

SFX = {
    # filtered noise swept up and down = whoosh
    "whoosh-short": ("anoisesrc=d=0.55:c=pink:a=0.6", "highpass=f=300,lowpass=f=5000,afade=t=in:d=0.25,afade=t=out:st=0.25:d=0.3,volume=0.7"),
    "whoosh": ("anoisesrc=d=1.1:c=pink:a=0.6", "highpass=f=200,lowpass=f=4000,afade=t=in:d=0.5,afade=t=out:st=0.5:d=0.6,volume=0.7"),
    "click-soft": ("sine=f=1800:d=0.04", "afade=t=out:st=0.005:d=0.035,volume=0.5,apad=pad_dur=0.3"),
    "click": ("sine=f=2600:d=0.03", "afade=t=out:st=0.004:d=0.026,volume=0.7,apad=pad_dur=0.3"),
    "pop": ("sine=f=660:d=0.12", "asetrate=44100*1.6,aresample=44100,afade=t=out:st=0.02:d=0.1,volume=0.6,apad=pad_dur=0.5"),
    "chime": ("sine=f=1318:d=1.6", "afade=t=out:st=0.05:d=1.5,volume=0.35"),
    "impact-bass-1": ("sine=f=55:d=1.2", "afade=t=in:d=0.01,afade=t=out:st=0.05:d=1.1,volume=1.4"),
    "error": ("sine=f=220:d=0.5", "afade=t=out:st=0.1:d=0.4,volume=0.4,apad=pad_dur=0.8"),
    "key-press": ("anoisesrc=d=0.03:c=white:a=0.5", "highpass=f=2000,afade=t=out:st=0.005:d=0.025,apad=pad_dur=0.3"),
}


def main(out):
    os.makedirs(out, exist_ok=True)
    for name, (src, af) in SFX.items():
        dst = os.path.join(out, f"{name}.mp3")
        if os.path.exists(dst):
            continue
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "lavfi", "-i", src, "-af", af, "-ar", "44100", "-ac", "2", "-b:a", "160k", dst], check=True)
    print(sorted(os.listdir(out)))


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "sfx")
