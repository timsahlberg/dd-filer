"""Prints the text of the information file(s) in a project's 1_Raw (the brief for a karrusel), whatever the format.

  python _System/scripts/tekst.py <mappe-eller-fil> [...]

Reads .txt, .md, .docx (Word, and Google Docs, which rclone downloads from Drive as .docx), .rtf (TextEdit on a Mac),
.pages is not readable (export it to Word first). Paragraphs are kept, bullet lists become "- " lines.
Prints one block per file: "### <filnavn>" followed by the text.
"""
import html, os, re, sys, zipfile

TEXT = (".txt", ".md", ".docx", ".rtf")


def docx_text(path):
    with zipfile.ZipFile(path) as z:
        xml = z.read("word/document.xml").decode("utf-8")
    out = []
    for p in re.findall(r"<w:p[ >].*?</w:p>", xml, re.S):
        t = "".join(re.findall(r"<w:t[^>]*>(.*?)</w:t>", p, re.S))
        t = html.unescape(t).strip()
        if "<w:numPr>" in p and t:
            t = "- " + t
        out.append(t)
    return re.sub(r"\n{3,}", "\n\n", "\n".join(out)).strip()


def rtf_text(path):
    s = open(path, encoding="latin-1").read()
    s = re.sub(r"\\'([0-9a-f]{2})", lambda m: bytes.fromhex(m.group(1)).decode("cp1252"), s)
    s = re.sub(r"\\u(-?\d+)\??", lambda m: chr(int(m.group(1)) % 65536), s)
    s = re.sub(r"\\(par|line)\b ?", "\n", s)
    s = re.sub(r"\{\\\*[^{}]*\}|\\[a-zA-Z]+-?\d* ?|[{}]", "", s)
    return re.sub(r"\n{3,}", "\n\n", s).strip()


def read(path):
    ext = os.path.splitext(path)[1].lower()
    if ext == ".docx":
        return docx_text(path)
    if ext == ".rtf":
        return rtf_text(path)
    return open(path, encoding="utf-8", errors="replace").read().strip()


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    files = []
    for a in sys.argv[1:]:
        if os.path.isdir(a):
            files += [os.path.join(a, f) for f in sorted(os.listdir(a)) if f.lower().endswith(TEXT) and f != "LAES-MIG.txt"]
        else:
            files.append(a)
    if not files:
        sys.exit("Ingen tekstfil (.txt, .md, .docx eller .rtf) fundet. " + __doc__)
    for f in files:
        print(f"### {os.path.basename(f)}\n{read(f)}\n")
