"""Measures downloaded reference posts so Claude can describe the style (for _System/stil.md).

  python stil_analyse.py [mappe]      (default: 02_Materialer/Stil-reference; every subfolder is one post)

Per video: length, number of cuts and cuts per second (scene detection), a contact sheet (a frame every ~0.8 s, plus
one frame after each cut) and the spoken words (transcribe.py), so pacing, hook, captions and graphics can be judged.
Per carousel/image post: a contact sheet of all slides. Writes <post>/analyse.json and <post>/kontaktark.jpg, and
prints a summary. Claude looks at the contact sheets and writes stil.md.
"""
import glob, json, os, re, shutil, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import paths  # noqa: E402

VID = (".mp4", ".mov", ".webm")
IMG = (".jpg", ".jpeg", ".png", ".webp")


def dur(p):
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", p], capture_output=True, text=True)
    try:
        return float(r.stdout.strip())
    except ValueError:
        return 0.0


def cuts(p):
    r = subprocess.run(["ffmpeg", "-v", "info", "-i", p, "-vf", "select='gt(scene,0.32)',showinfo", "-f", "null", "-"], capture_output=True, text=True)
    return [round(float(x), 2) for x in re.findall(r"pts_time:([\d.]+)", r.stderr)]


def sheet(frames, out, cols=6, w=270):
    tmp = out + "_t"
    shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(tmp)
    for k, f in enumerate(frames):
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", f, "-vf", f"scale={w}:-2", os.path.join(tmp, f"{k:03d}.png")])
    rows = -(-len(frames) // cols)
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-framerate", "1", "-i", os.path.join(tmp, "%03d.png"), "-vf",
                    f"scale={w}:{int(w * 16 / 9)}:force_original_aspect_ratio=decrease,pad={w}:{int(w * 16 / 9)}:(ow-iw)/2:(oh-ih)/2,tile={cols}x{rows}:padding=4:color=0x222222",
                    "-frames:v", "1", "-q:v", "3", out])
    shutil.rmtree(tmp, ignore_errors=True)


def video(p, d):
    L = dur(p)
    c = cuts(p)
    fr_dir = os.path.join(d, "_frames")
    shutil.rmtree(fr_dir, ignore_errors=True)
    os.makedirs(fr_dir)
    times = sorted(set([round(t, 1) for t in [i * 0.8 for i in range(int(L / 0.8) + 1)] + [x + 0.15 for x in c] if t < L]))[:48]
    frames = []
    for k, t in enumerate(times):
        f = os.path.join(fr_dir, f"{k:03d}_{t:05.1f}s.jpg")
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-ss", str(t), "-i", p, "-frames:v", "1", "-vf", "scale=540:-2", f])
        if os.path.exists(f):
            frames.append(f)
    sheet(frames, os.path.join(d, "kontaktark.jpg"))
    tr = os.path.join(d, "transskription.json")
    subprocess.run([sys.executable, os.path.join(HERE, "transcribe.py"), p, tr, "--sprog", "auto"], capture_output=True)
    text = ""
    if os.path.exists(tr):
        text = " ".join(s["text"] for s in json.load(open(tr, encoding="utf-8")).get("segments", []))
    return {"fil": os.path.basename(p), "laengde_s": round(L, 1), "klip": len(c), "klip_pr_sek": round(len(c) / L, 2) if L else 0,
            "klip_tider": c[:60], "tale": text, "kontaktark": "kontaktark.jpg", "frames": len(frames)}


def main():
    paths.load()
    base = sys.argv[1] if len(sys.argv) > 1 else os.path.join(paths.ROOT, "02_Materialer", "Stil-reference")
    summary = []
    for d in sorted(x for x in glob.glob(os.path.join(base, "*")) if os.path.isdir(x)):
        vids = sorted(f for f in glob.glob(os.path.join(d, "**", "*"), recursive=True) if f.lower().endswith(VID) and "_frames" not in f)
        imgs = sorted(f for f in glob.glob(os.path.join(d, "**", "*"), recursive=True) if f.lower().endswith(IMG) and "_frames" not in f and "kontaktark" not in f)
        res = {"post": os.path.basename(d)}
        if vids:
            res["videoer"] = [video(v, d) for v in vids[:3]]
        if imgs and not vids:
            sheet(imgs[:20], os.path.join(d, "kontaktark.jpg"), cols=5, w=300)
            res["slides"] = len(imgs)
            res["kontaktark"] = "kontaktark.jpg"
        json.dump(res, open(os.path.join(d, "analyse.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        summary.append(res)
    print(json.dumps(summary, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
