"""Checks that everything the system needs is installed. Prints a checklist as JSON; exit code 0 when all required are ok.

  python doctor.py

Required: Python 3.10+, ffmpeg + ffprobe, Node.js (npx) for HyperFrames, Chrome or Edge, the Python packages
(faster-whisper, numpy, opencv, yt-dlp, gallery-dl, pymupdf). Optional: NVIDIA GPU (faster transcription on Windows), free disk.
"""
import importlib, json, os, platform, shutil, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import paths  # noqa: E402


def run(cmd):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        return r.returncode == 0, (r.stdout or r.stderr).strip().splitlines()[0] if (r.stdout or r.stderr).strip() else ""
    except Exception as e:
        return False, str(e)


def main():
    out = []
    add = lambda name, ok, info, required=True, fix="": out.append({"tjek": name, "ok": bool(ok), "info": info, "påkrævet": required, "løsning": "" if ok else fix})
    v = sys.version_info
    add("Python 3.10+", v >= (3, 10), platform.python_version(), fix="Kør opsætningen igen; den laver Python-miljøet med uv.")
    for exe in ("ffmpeg", "ffprobe"):
        ok, info = run([exe, "-version"])
        add(exe, ok, info[:60], fix="Mac: brew install ffmpeg · Windows: winget install Gyan.FFmpeg (og genstart Claude)")
    n = paths.npx()
    ok, info = run([n, "--version"]) if n else (False, "ikke fundet")
    add("Node.js (npx)", ok, info, fix="Mac: brew install node · Windows: winget install OpenJS.NodeJS.LTS (og genstart Claude)")
    try:
        paths.load()
    except SystemExit:
        pass
    c = paths.chrome()
    add("Chrome eller Edge", c, c or "ikke fundet", fix="Installér Google Chrome fra google.com/chrome")
    for mod, pkg in (("faster_whisper", "faster-whisper"), ("numpy", "numpy"), ("cv2", "opencv-python-headless"),
                     ("yt_dlp", "yt-dlp"), ("gallery_dl", "gallery-dl"), ("pymupdf", "pymupdf")):
        try:
            importlib.import_module(mod)
            add(pkg, True, "installeret")
        except Exception:
            add(pkg, False, "mangler", fix="Kør opsætningens pakke-trin igen (uv pip install ...)")
    gpu = shutil.which("nvidia-smi")
    add("NVIDIA-grafikkort (valgfrit)", bool(gpu), "fundet" if gpu else "ikke fundet: transskription kører på processoren (lidt langsommere)", required=False)
    root = paths.ROOT or os.getcwd()
    free = shutil.disk_usage(root).free / 1e9
    add("Fri diskplads (mindst 20 GB)", free >= 20, f"{free:.0f} GB fri", required=False, fix="Ryd op, eller vælg en arbejdsmappe på et drev med mere plads.")
    ok_all = all(x["ok"] for x in out if x["påkrævet"])
    print(json.dumps({"alt_ok": ok_all, "os": platform.system(), "tjek": out}, ensure_ascii=False, indent=1))
    sys.exit(0 if ok_all else 1)


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
