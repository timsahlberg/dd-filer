"""Motion first slide for a karrusel: a 1080x1350 looping MP4 rendered with HyperFrames (used by karrusel.py, type "motion").

Rule: the first slide of every karrusel moves, to stop the scroll (like carousels where a small figure hops in the
hand of the person on the cover). Frame 0 already looks finished (title, photo, figure), because
Instagram uses it as the preview in the feed; the motion loops seamlessly over "duration" seconds (default 5).

Slide fields (besides the cover text: title = small white top line, accent = big amber line with a breathing glow,
kicker = pill, text_pos = "top" | "bottom"):
  figurmodel a faceless figure from 02_Materialer/Figurer/figurer.json ("haand-a", "haand-b"): sets image, colour,
             image_scale and puts "at" in its palm, so the figure hops in the hand (no photo of the kursist needed)
  figurvideo an AI-animated loop instead of a still (02_Materialer/Figurer/loop-*.mp4), e.g. the figure bouncing
             the house with its arm moving in time; no extra figure is drawn on top (figure "ingen")
  image_scale  <1 shows the photo smaller, standing on the bottom edge with faded edges (default .88 with figurmodel)
  image      background photo, shown in black and white ("farve": true keeps colour), slow Ken Burns zoom
  focus      CSS object-position of the photo
  figure     what moves: "husfigur" (pixel house that hops and blinks), "notifikationer" (bubbles pop up one by one),
             "likes" (a heart and a counter that counts up), "telefon" (a floating phone with "screen" as its picture),
             "objekt" (your own PNG with transparency in "object")
  at         [x, y]: where the figure stands (its bottom centre), e.g. on the palm of a hand in the photo. Default [540, 1060]
  size       figure size in px (default depends on the figure)
  motion     "hop" or "float" for husfigur/objekt (default hop for husfigur, float for objekt)
  peek       true: a second, smaller husfigur peeks in from the side (like the second figure in the reference)
  messages   texts for "notifikationer" (2-4); default a message, a booked valuation and new followers
  apps       app names over each notification (default Instagram, Kalender, Instagram)
  count      [from, to] for "likes" (default [120, 4800]); label under the number (default "visninger")
  screen     picture in the phone for "telefon"
"""
import html, json, os, re, shutil, subprocess, sys

PIXEL_HOUSE = [  # 14 x 14, R roof, H roof light, C chimney, B body, W body light, E eye, D door, L leg
    ".........CC...",
    "......RR.CC...",
    ".....RHHRRR...",
    "....RHHRRRRR..",
    "...RHRRRRRRRR.",
    "..RRRRRRRRRRRR",
    "...WWBBBBBBBB.",
    "...WBEEBBEEBB.",
    "...BBEEBBEEBB.",
    "...BBBBBBBBBB.",
    "...BBBBDDBBBB.",
    "...BBBBDDBBBB.",
    "....LL....LL..",
    "....LL....LL..",
]
COLORS = {"R": "#E0902A", "H": "#F2A93C", "C": "#B8701C", "B": "#FFB547", "W": "#FFD08A", "D": "#B8701C", "L": "#C97A1E", "E": "#1A1206"}
DEFAULT = {"bg": "#0D1119", "surface": "#141A26", "line": "#252E3F", "chip_line": "#2E3748", "text": "#EEF1F6", "muted": "#97A1B4",
           "accent": "#FFB547", "on_accent": "#1A1206", "head": "Bricolage Grotesque", "body": "Instrument Sans", "mono": "JetBrains Mono"}


def shade(hexc, f):
    """Lighter (f > 0) or darker (f < 0) version of a #RRGGBB colour."""
    r, g, b = (int(hexc[i:i + 2], 16) for i in (1, 3, 5))
    t = 255 if f > 0 else 0
    return "#" + "".join(f"{round(c + (t - c) * abs(f)):02X}" for c in (r, g, b))


def rgb(hexc):
    return ",".join(str(int(hexc[i:i + 2], 16)) for i in (1, 3, 5))


def brand_tokens():
    import paths
    b = paths.brand()
    t = dict(DEFAULT)
    t.update({k: v for k, v in (b.get("farver") or {}).items() if v})
    t.update({k: v for k, v in (b.get("fonte") or {}).items() if v})
    a = t["accent"]
    COLORS.update({"B": a, "W": shade(a, .45), "H": shade(a, -.06), "R": shade(a, -.14), "C": shade(a, -.32), "D": shade(a, -.32),
                   "L": shade(a, -.22), "E": t["on_accent"]})
    return t


def house_svg(uid):
    """Pixel house as SVG, eyes in their own group so they can blink."""
    body, eyes = [], []
    for y, row in enumerate(PIXEL_HOUSE):
        for x, ch in enumerate(row):
            if ch == ".":
                continue
            r = f'<rect x="{x}" y="{y}" width="1.02" height="1.02" fill="{COLORS[ch]}"/>'
            (eyes if ch == "E" else body).append(r)
    return (f'<svg viewBox="0 0 14 14" width="100%" height="100%" shape-rendering="crispEdges">{"".join(body)}'
            f'<g id="{uid}-eyes" style="transform-origin:7px 8px">{"".join(eyes)}</g></svg>')


def recolour(page, tk, work):
    """The page is written in the default palette; swap in the kursist's colours and fonts."""
    import paths
    pairs = [("#0D1119", tk["bg"]), ("#141A26", tk["surface"]), ("#252E3F", tk["line"]), ("#2E3748", tk["chip_line"]), ("#1B2230", shade(tk["surface"], .04)),
             ("#EEF1F6", tk["text"]), ("#97A1B4", tk["muted"]), ("#FFB547", tk["accent"]), ("#1A1206", tk["on_accent"]),
             ("rgba(255,181,71", "rgba(" + rgb(tk["accent"])), ("rgba(13,17,25", "rgba(" + rgb(tk["bg"])), ("rgba(20,26,38", "rgba(" + rgb(tk["surface"]))]
    for a, b in pairs:
        page = page.replace(a, b)
    fonts = os.path.join(paths.ROOT, "_System", "fonts")
    faces = ""
    if os.path.isdir(fonts):
        for f in os.listdir(fonts):
            shutil.copy2(os.path.join(fonts, f), os.path.join(work, "assets", "fonts", f))
        css = os.path.join(paths.ROOT, "_System", "brand.css")
        if os.path.exists(css):
            faces = chr(10).join(l.replace('url("fonts/', 'url("assets/fonts/') for l in open(css, encoding="utf-8").read().splitlines() if l.startswith("@font-face"))
    for old, key in (('"Bricolage Grotesque"', "head"), ('"Instrument Sans"', "body"), ('"JetBrains Mono"', "mono")):
        if tk[key] != DEFAULT[key]:
            page = page.replace(f"font-family: {old}", f'font-family: "{tk[key]}"')
    return page.replace("</style>", faces + chr(10) + "</style>", 1) if faces else page


def grey(src, dst, farve):
    """Copy the photo; black and white via ffmpeg (HyperFrames wants no CSS filters on media)."""
    vf = "scale='min(1600,iw)':-2" + ("" if farve else ",hue=s=0,eq=contrast=1.12:brightness=-0.03")
    r = subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", src, "-vf", vf, "-q:v", "2", dst], capture_output=True, text=True)
    if r.returncode:
        sys.exit(f"ffmpeg kunne ikke klargøre {src}: {r.stderr[-400:]}")


def rich(s):
    s = html.escape(s or "")
    return re.sub(r"\*(.+?)\*", r"<em>\1</em>", s).replace("\n", "<br>")


def build(project, s, resolve, assets_dir, footer, work, out_mp4):
    tk = brand_tokens()
    D = float(s.get("duration", 5))
    if s.get("figurmodel"):
        # a faceless figure from 02_Materialer/Figurer: its palm position puts the hopping figure in its hand
        lib = json.load(open(resolve(project, "02_Materialer/Figurer/figurer.json"), encoding="utf-8"))
        if s["figurmodel"] not in lib:
            sys.exit(f"Ukendt figurmodel '{s['figurmodel']}'. Findes: {', '.join(k for k in lib if k != 'note')}")
        m = lib[s["figurmodel"]]
        s = dict(s, focus="50% 50%")
        s.setdefault("image", m["file"])
        s.setdefault("farve", True)
        s.setdefault("image_scale", .88)
        s.setdefault("size", 190)
        w0, h0 = m["size"]
        k = max(1080 / w0, 1350 / h0)
        px, py = m["palm"][0] * k - (w0 * k - 1080) / 2, m["palm"][1] * k - (h0 * k - 1350) / 2
        sc = s["image_scale"]
        s.setdefault("at", [round(540 + (px - 540) * sc), round(1350 - (1350 - py) * sc) + 8])
        if m.get("shoulder"):
            qx, qy = m["shoulder"][0] * k - (w0 * k - 1080) / 2, m["shoulder"][1] * k - (h0 * k - 1350) / 2
            s.setdefault("peek_at", [round(540 + (qx - 540) * sc), round(1350 - (1350 - qy) * sc)])
    shutil.rmtree(work, ignore_errors=True)
    os.makedirs(os.path.join(work, "assets", "fonts"))
    for f in os.listdir(os.path.join(assets_dir, "fonts")):
        shutil.copy2(os.path.join(assets_dir, "fonts", f), os.path.join(work, "assets", "fonts", f))
    for name in ("hyperframes.json", "meta.json", "package.json"):
        src = os.path.join(os.path.dirname(assets_dir), name)
        if os.path.exists(src):
            shutil.copy2(src, os.path.join(work, name))

    photo = ""
    is_video = bool(s.get("figurvideo"))
    if is_video:
        # a ready AI-animated loop (e.g. the figure bouncing the house with its arm moving): background is the video,
        # nothing extra hops on top
        shutil.copy2(resolve(project, s["figurvideo"]), os.path.join(work, "assets", "figur.mp4"))
        s = dict(s, figure="ingen")
        s.setdefault("image_scale", .88)
        photo = (f'<video id="photo" class="clip" data-start="0" data-duration="{D}" data-track-index="5" muted playsinline '
                 f'src="assets/figur.mp4"></video>')
    elif s.get("image"):
        grey(resolve(project, s["image"]), os.path.join(work, "assets", "photo.jpg"), s.get("farve"))
        photo = f'<img id="photo" src="assets/photo.jpg" style="object-position:{s.get("focus", "50% 40%")}">'
    if photo:
        sc = float(s.get("image_scale", 1))
        if sc != 1:
            # smaller photo standing on the bottom edge, edges faded into the navy background (room for the headline)
            photo = (f'<div style="position:absolute;inset:0;transform:scale({sc});transform-origin:50% 100%;'
                     f'-webkit-mask-image:radial-gradient(ellipse 75% 85% at 50% 62%, #000 62%, transparent 100%);'
                     f'mask-image:radial-gradient(ellipse 75% 85% at 50% 62%, #000 62%, transparent 100%)">{photo}</div>')

    fig = s.get("figure", "husfigur")
    x, y = s.get("at", [540, 1060])
    tl = []  # GSAP lines, all seek-safe tweens inside one paused timeline
    figure_html = ""
    if fig in ("husfigur", "objekt"):
        size = int(s.get("size", 230 if fig == "husfigur" else 300))
        motion = s.get("motion", "hop" if fig == "husfigur" else "float")
        if fig == "husfigur":
            inner = house_svg("h1")
        else:
            shutil.copy2(resolve(project, s["object"]), os.path.join(work, "assets", "object.png"))
            inner = '<img src="assets/object.png" style="width:100%;height:100%;object-fit:contain">'
        figure_html = (f'<div id="shadow" style="left:{x - size * .36}px;top:{y - 14}px;width:{size * .72}px"></div>'
                       f'<div id="fig" style="left:{x - size / 2}px;top:{y - size}px;width:{size}px;height:{size}px">{inner}</div>')
        if motion == "hop":
            hops = max(2, round(D / 1.25))
            p = D / hops
            for k in range(hops):
                t0 = k * p
                tl += [f'tl.to("#fig", {{y: -{size * s.get("hop", .42):.0f}, duration: {p * .32:.3f}, ease: "power2.out"}}, {t0:.3f});',
                       f'tl.to("#fig", {{y: 0, duration: {p * .32:.3f}, ease: "power2.in"}}, {t0 + p * .32:.3f});',
                       f'tl.to("#fig", {{scaleY: .86, scaleX: 1.1, duration: {p * .08:.3f}, ease: "power1.out"}}, {t0 + p * .64:.3f});',
                       f'tl.to("#fig", {{scaleY: 1, scaleX: 1, duration: {p * .12:.3f}, ease: "power1.inOut"}}, {t0 + p * .72:.3f});',
                       f'tl.to("#shadow", {{scaleX: .55, opacity: .35, duration: {p * .32:.3f}, ease: "power2.out"}}, {t0:.3f});',
                       f'tl.to("#shadow", {{scaleX: 1, opacity: .8, duration: {p * .32:.3f}, ease: "power2.in"}}, {t0 + p * .32:.3f});']
        else:
            tl += [f'tl.to("#fig", {{y: -26, rotation: 4, duration: {D / 2:.3f}, ease: "sine.inOut"}}, 0);',
                   f'tl.to("#fig", {{y: 0, rotation: 0, duration: {D / 2:.3f}, ease: "sine.inOut"}}, {D / 2:.3f});',
                   f'tl.to("#shadow", {{scaleX: .8, opacity: .5, duration: {D / 2:.3f}, ease: "sine.inOut"}}, 0);',
                   f'tl.to("#shadow", {{scaleX: 1, opacity: .8, duration: {D / 2:.3f}, ease: "sine.inOut"}}, {D / 2:.3f});']
        if fig == "husfigur":
            for bt in (D * .3, D * .78):
                tl += [f'tl.to("#h1-eyes", {{scaleY: .1, duration: .07, ease: "none"}}, {bt:.3f});',
                       f'tl.to("#h1-eyes", {{scaleY: 1, duration: .09, ease: "none"}}, {bt + .07:.3f});']
    elif fig == "notifikationer":
        msgs = s.get("messages") or ["Ny besked: Hvad er vores hus værd?", "Vurdering booket torsdag kl. 16", "+38 nye følgere i dag"]
        icons = ["✉", "✓", "+", "♥"]
        apps = s.get("apps") or ["Instagram", "Kalender", "Instagram", "Instagram"]
        rows = "".join(f'<div class="noti" id="n{k}"><div class="ic">{icons[k % 4]}</div><div class="nt"><b>{html.escape(apps[k % len(apps)])}</b>'
                       f'<span>{html.escape(m)}</span></div></div>' for k, m in enumerate(msgs[:4]))
        figure_html = f'<div id="notis" style="left:{x - 400}px;top:{y - 150 * len(msgs[:4])}px">{rows}</div>'
        for k in range(len(msgs[:4])):
            t0 = .35 + k * .65
            tl += [f'tl.fromTo("#n{k}", {{y: 40, opacity: 0, scale: .92}}, {{y: 0, opacity: 1, scale: 1, duration: .5, ease: "expo.out"}}, {t0:.2f});']
        tl += [f'tl.to("#notis .noti", {{opacity: 0, y: -20, duration: .35, ease: "power2.in", stagger: .05}}, {D - .5:.2f});']
    elif fig == "likes":
        a, b = s.get("count", [120, 4800])
        figure_html = (f'<div id="likes" style="left:{x - 300}px;top:{y - 330}px"><div class="heart">♥</div>'
                       f'<div class="num" id="num">{a:,}'.replace(",", ".") + f'</div><div class="lab">{html.escape(s.get("label", "visninger"))}</div></div>'
                       + "".join(f'<div class="fh" id="fh{k}" style="left:{x - 160 + k * 80}px;top:{y - 60}px">♥</div>' for k in range(5)))
        tl += [f'const c = {{v: {a}}}; tl.to(c, {{v: {b}, duration: {D * .7:.2f}, ease: "power2.out", onUpdate: () => '
               f'document.getElementById("num").textContent = Math.round(c.v).toLocaleString("da-DK")}}, .2);',
               f'tl.fromTo(".heart", {{scale: 1}}, {{scale: 1.18, duration: .25, ease: "power2.out", yoyo: true, repeat: 5}}, .2);']
        for k in range(5):
            t0 = .3 + k * .55
            tl += [f'tl.fromTo("#fh{k}", {{y: 0, opacity: 0}}, {{y: -420, opacity: 1, duration: 1.6, ease: "power1.out"}}, {t0:.2f});',
                   f'tl.to("#fh{k}", {{opacity: 0, duration: .5}}, {t0 + 1.1:.2f});']
    elif fig == "telefon":
        scr = ""
        if s.get("screen"):
            shutil.copy2(resolve(project, s["screen"]), os.path.join(work, "assets", "screen.jpg"))
            scr = '<img src="assets/screen.jpg">'
        figure_html = f'<div id="fig" class="phone" style="left:{x - 230}px;top:{y - 900}px">{scr}</div>'
        tl += [f'tl.to("#fig", {{y: -24, rotation: -1, duration: {D / 2:.3f}, ease: "sine.inOut"}}, 0);',
               f'tl.to("#fig", {{y: 0, rotation: -4, duration: {D / 2:.3f}, ease: "sine.inOut"}}, {D / 2:.3f});']
    elif fig != "ingen":
        sys.exit(f"Ukendt figure '{fig}' (husfigur, notifikationer, likes, telefon, objekt, ingen)")

    peek = ""
    if s.get("peek") and s.get("peek_at"):
        # rises from behind the shoulder: a window whose bottom edge is the shoulder line hides it until it comes up
        qx, qy = s["peek_at"]
        peek = (f'<div style="position:absolute;left:{qx - 85}px;top:{qy - 150}px;width:170px;height:150px;overflow:hidden">'
                f'<div id="peekin" style="position:absolute;left:5px;top:0;width:160px;height:160px;transform-origin:50% 100%">{house_svg("h2")}</div></div>')
        tl += [f'tl.fromTo("#peekin", {{y: 165, rotation: 0}}, {{y: 45, rotation: -8, duration: .7, ease: "expo.out"}}, {D * .25:.2f});',
               f'tl.to("#peekin", {{rotation: 6, duration: .7, ease: "sine.inOut"}}, {D * .25 + .8:.2f});',
               f'tl.to("#peekin", {{y: 165, rotation: 0, duration: .5, ease: "power2.in"}}, {D - .8:.2f});']
    elif s.get("peek"):
        peek = f'<div id="peek">{house_svg("h2")}</div>'
        tl += [f'tl.fromTo("#peek", {{x: 120, rotation: 18}}, {{x: 0, rotation: 8, duration: .7, ease: "expo.out"}}, {D * .25:.2f});',
               f'tl.to("#peek", {{rotation: -2, duration: .6, ease: "sine.inOut"}}, {D * .25 + .8:.2f});',
               f'tl.to("#peek", {{x: 120, rotation: 18, duration: .6, ease: "power2.in"}}, {D - .8:.2f});']

    top = s.get("text_pos", "top") == "top"
    kick = f'<div class="pill">{html.escape(s["kicker"])}</div>' if s.get("kicker") else ""
    text = (f'<div id="txt" style="{"top:100px" if top else "bottom:150px"}"><div class="tl">{rich(s.get("title"))}</div>'
            f'<div class="big" id="big">{rich(s.get("accent"))}</div>{kick}</div>')
    tl = ([f'tl.to("#photo", {{scale: 1.06, duration: {D / 2:.3f}, ease: "sine.inOut"}}, 0);',
           f'tl.to("#photo", {{scale: 1, duration: {D / 2:.3f}, ease: "sine.inOut"}}, {D / 2:.3f});'] if photo and not is_video else []) + \
         [f'tl.to("#big", {{textShadow: "0 0 34px rgba(255,181,71,.85), 0 0 90px rgba(255,181,71,.45)", duration: {D / 2:.3f}, ease: "sine.inOut"}}, 0);',
          f'tl.to("#big", {{textShadow: "0 0 22px rgba(255,181,71,.55), 0 0 64px rgba(255,181,71,.28)", duration: {D / 2:.3f}, ease: "sine.inOut"}}, {D / 2:.3f});'] + tl

    clip = f'class="clip" data-start="0" data-duration="{D}"'
    page = f"""<!doctype html>
<html lang="da">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=1080, height=1350">
<script src="https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js"></script>
<style>
@font-face {{ font-family: "Bricolage Grotesque"; src: url("assets/fonts/Bricolage.ttf"); font-weight: 200 800; font-stretch: 75% 100%; }}
@font-face {{ font-family: "Instrument Sans"; src: url("assets/fonts/InstrumentSans.ttf"); font-weight: 400 700; }}
@font-face {{ font-family: "JetBrains Mono"; src: url("assets/fonts/JetBrainsMono-700.woff2"); font-weight: 700; }}
@font-face {{ font-family: "JetBrains Mono"; src: url("assets/fonts/JetBrainsMono-400.woff2"); font-weight: 400; }}
* {{ margin: 0; padding: 0; box-sizing: border-box; font-style: normal; }}
html, body {{ width: 1080px; height: 1350px; overflow: hidden; background: #0D1119; }}
#root {{ position: relative; width: 1080px; height: 1350px; overflow: hidden; background: radial-gradient(70% 45% at 50% 0%, rgba(255,181,71,.08), rgba(255,181,71,0) 70%), #0D1119; }}
.layer {{ position: absolute; inset: 0; }}
#photo {{ position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; transform-origin: 50% 45%; }}
#shade {{ position: absolute; inset: 0; background: linear-gradient(180deg, rgba(13,17,25,.92) 0%, rgba(13,17,25,.5) 28%, rgba(13,17,25,.05) 52%, rgba(13,17,25,.3) 80%, rgba(13,17,25,.9) 100%); }}
#grain {{ position: absolute; inset: 0; opacity: .10; mix-blend-mode: screen; background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='300' height='300'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='.9' numOctaves='3' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 1.2 0'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>"); }}
#txt {{ position: absolute; left: 80px; right: 80px; display: flex; flex-direction: column; align-items: center; text-align: center; gap: 8px; }}
.tl {{ font-family: "Bricolage Grotesque"; font-weight: 800; font-size: 70px; line-height: 1; text-transform: uppercase; color: #EEF1F6; letter-spacing: -.01em; }}
.big {{ font-family: "Bricolage Grotesque"; font-weight: 800; font-size: {int(s.get("accent_size", 150))}px; line-height: .9; text-transform: uppercase; color: #FFB547; letter-spacing: -.03em;
  text-shadow: 0 0 22px rgba(255,181,71,.55), 0 0 64px rgba(255,181,71,.28); }}
.tl em, .big em {{ color: #FFB547; }}
.pill {{ margin-top: 18px; font-family: "JetBrains Mono"; font-size: 26px; letter-spacing: .1em; text-transform: uppercase; color: #97A1B4; border: 2px solid #2E3748; background: rgba(13,17,25,.6); border-radius: 999px; padding: 10px 22px; }}
#sign {{ position: absolute; left: 0; right: 0; bottom: 56px; text-align: center; font-family: "JetBrains Mono"; font-size: 22px; letter-spacing: .16em; text-transform: uppercase; color: #97A1B4; opacity: .75; }}
#fig {{ position: absolute; transform-origin: 50% 100%; filter: drop-shadow(0 18px 30px rgba(0,0,0,.5)) drop-shadow(0 0 40px rgba(255,181,71,.25)); }}
#shadow {{ position: absolute; height: 28px; border-radius: 50%; background: radial-gradient(closest-side, rgba(0,0,0,.65), rgba(0,0,0,0)); opacity: .8; }}
#peek {{ position: absolute; right: -40px; top: 640px; width: 170px; height: 170px; transform-origin: 100% 100%; filter: drop-shadow(0 10px 20px rgba(0,0,0,.5)); }}
#notis {{ position: absolute; width: 800px; display: flex; flex-direction: column; gap: 22px; }}
.noti {{ display: flex; gap: 22px; align-items: center; background: rgba(20,26,38,.88); border: 2px solid #2E3748; border-radius: 30px; padding: 24px 28px; box-shadow: 0 20px 50px rgba(0,0,0,.5); opacity: 0; }}
.noti .ic {{ flex: none; width: 64px; height: 64px; border-radius: 18px; background: #FFB547; color: #1A1206; font-family: "JetBrains Mono"; font-weight: 700; font-size: 32px; display: flex; align-items: center; justify-content: center; }}
.noti .nt {{ display: flex; flex-direction: column; gap: 4px; font-family: "Instrument Sans"; text-align: left; }}
.noti b {{ font-family: "JetBrains Mono"; font-size: 22px; letter-spacing: .1em; text-transform: uppercase; color: #97A1B4; font-weight: 700; }}
.noti span {{ font-size: 36px; font-weight: 600; color: #EEF1F6; }}
#likes {{ position: absolute; width: 600px; display: flex; flex-direction: column; align-items: center; gap: 6px; }}
.heart {{ font-size: 150px; line-height: 1; color: #FFB547; text-shadow: 0 0 40px rgba(255,181,71,.6); }}
.num {{ font-family: "Bricolage Grotesque"; font-weight: 800; font-size: 130px; line-height: 1; color: #EEF1F6; }}
.lab {{ font-family: "JetBrains Mono"; font-size: 26px; letter-spacing: .14em; text-transform: uppercase; color: #97A1B4; }}
.fh {{ position: absolute; font-size: 60px; color: #FFB547; opacity: 0; }}
.phone {{ width: 460px; height: 940px; border-radius: 70px; border: 14px solid #1B2230; background: #000; overflow: hidden; transform-origin: 50% 100%;
  transform: rotate(-4deg); box-shadow: 0 0 0 2px #2E3748, 0 40px 120px rgba(0,0,0,.7), 0 0 120px rgba(255,181,71,.2); }}
.phone img {{ width: 100%; height: 100%; object-fit: cover; object-position: top; }}
</style>
</head>
<body>
<div id="root" data-composition-id="main" data-start="0" data-duration="{D}" data-width="1080" data-height="1350" data-fps="30">
  <div id="l-photo" class="layer" {"" if is_video else clip} data-track-index="0">{photo}<div id="shade"></div></div>
  <div id="l-fig" class="layer" {clip} data-track-index="1">{figure_html}{peek}</div>
  <div id="l-text" class="layer" {clip} data-track-index="2">{text}<div id="sign">{html.escape(footer)}</div></div>
  <div id="l-grain" class="layer" {clip} data-track-index="3"><div id="grain"></div></div>
</div>
<script>
const tl = gsap.timeline({{ paused: true }});
{chr(10).join(tl)}
tl.set({{}}, {{}}, {D});
window.__timelines = window.__timelines || {{}};
window.__timelines["main"] = tl;
</script>
</body>
</html>
"""
    page = recolour(page, tk, work)
    open(os.path.join(work, "index.html"), "w", encoding="utf-8").write(page)
    raw = os.path.join(work, "render.mp4")
    npx = "npx.cmd" if os.name == "nt" else "npx"
    r = subprocess.run([npx, "hyperframes", "render", work, "-q", "delivery", "-o", raw, "--quiet"], capture_output=True, text=True,
                       encoding="utf-8", errors="replace", timeout=900)
    if r.returncode or not os.path.exists(raw):
        sys.exit(f"HyperFrames-render af motion-slide fejlede: {(r.stderr or r.stdout)[-1200:]}")
    # Instagram-friendly: H.264 High, yuv420p, faststart, no audio
    r = subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", raw, "-an", "-c:v", "libx264", "-crf", "17", "-preset", "slow",
                        "-profile:v", "high", "-pix_fmt", "yuv420p", "-movflags", "+faststart", out_mp4], capture_output=True, text=True)
    if r.returncode:
        sys.exit(f"ffmpeg fejlede på motion-slide: {r.stderr[-600:]}")
