"""Creates a project folder (1_Raw, 2_Projekt, 3_Final) and moves new files from the format's inbox into its 1_Raw.

  python _System/scripts/new_project.py <format> "<emne>" [--date=YYYY-MM-DD] [--file="<navn i indbakken>"]

<format> is a key or alias from config "formats" (talking-head/th/reel, karrusel/ka, detaljevideo/dv).
Each format has its own inbox and project folder: 00_Indbakke/<format folder>/ and 01_Projekter/<format folder>/.
--file names one file or one folder in that inbox (one file or folder = one project); a folder's files (also in
subfolders) are all moved, and the empty folder is removed. Without --file, every loose file in the inbox is moved.

Name: <KODE>-<nr>_<emne>_<dato>, e.g. TH-009_det-er-ikke-din-telefon_2026-10-30. Each format counts on its own: the
number is the highest one already used for that code in 01_Projekter/<format folder> or 03_Final/<format folder>, plus one.
Emne is lower case, no æ/ø/å (ae/oe/aa), words joined with "-". Moved files are renamed the same way.
If a project with the same format, emne and date exists (re-run), it is reused and only new inbox files are moved.
Prints JSON, including "id" and "final_prefix" (<KODE>-<nr>_<emne>, the start of every final file name).
"""
import datetime, json, os, re, shutil, sys

import paths
from paths import find_format, inbox_dir, projects_dir

paths.load()

SKIP = {"LAES-MIG.txt", "desktop.ini", "Thumbs.db", ".DS_Store"}


def slug(s, dots=True):
    s = s.lower().replace("æ", "ae").replace("ø", "oe").replace("å", "aa")
    if not dots:
        s = s.replace(".", "")
    s = re.sub(r"[^a-z0-9.]+", "-", s)
    return re.sub(r"-{2,}", "-", s).strip("-.")


def inbox_files(inbox, only):
    """(source path, name to use) for each file to move."""
    if only:
        src = os.path.join(inbox, only)
        if os.path.isdir(src):
            return [(os.path.join(d, f), os.path.relpath(os.path.join(d, f), src).replace(os.sep, "-"))
                    for d, _, fs in sorted(os.walk(src)) for f in sorted(fs) if f not in SKIP]
        return [(src, only)] if os.path.isfile(src) else []
    return [(os.path.join(inbox, f), f) for f in sorted(os.listdir(inbox))
            if f not in SKIP and os.path.isfile(os.path.join(inbox, f))]


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if len(args) < 2:
        sys.exit(__doc__)
    date = next((a.split("=", 1)[1] for a in sys.argv[1:] if a.startswith("--date=")), datetime.date.today().isoformat())
    fkey, fmt = find_format(args[0])
    if not fmt:
        sys.exit(f"Ukendt format '{args[0]}'. Brug et af: {', '.join(paths.FORMATS)}")
    code, emne = fmt["code"], slug(" ".join(args[1:]), dots=False)
    projects = projects_dir(fmt)
    os.makedirs(projects, exist_ok=True)
    finals = os.path.join(paths.ROOT, "03_Final", fmt["folder"])
    used = [d for base in (projects, finals) if os.path.isdir(base) for d in os.listdir(base)]
    existing = next((d for d in used if re.fullmatch(rf"{code}-\d+_{re.escape(emne)}_{date}", d)), None)
    if existing:
        name = existing
    else:
        nums = [int(m.group(1)) for d in used if (m := re.match(rf"{code}-(\d+)_", d))]
        # "next_min" lets a format start numbering above 1
        name = f"{code}-{max(max(nums, default=0) + 1, fmt.get('next_min', 1)):03d}_{emne}_{date}"
    pid = name.split("_", 1)[0]
    proj = os.path.join(projects, name)
    created = not os.path.exists(proj)
    if created:
        for sub in ("1_Raw", "2_Projekt", "3_Final"):
            os.makedirs(os.path.join(proj, sub), exist_ok=True)
    raw = os.path.join(proj, "1_Raw")
    os.makedirs(raw, exist_ok=True)
    moved = []
    inbox = inbox_dir(fmt)
    only = next((a.split("=", 1)[1] for a in sys.argv[1:] if a.startswith("--file=")), None)
    for src, f in inbox_files(inbox, only):
        base, ext = os.path.splitext(f)
        dst = os.path.join(raw, slug(base) + ext.lower())
        n = 2
        while os.path.exists(dst):
            dst = os.path.join(raw, f"{slug(base)}-{n}{ext.lower()}"); n += 1
        shutil.move(src, dst)
        moved.append({"from": f, "to": os.path.basename(dst)})
    if only and os.path.isdir(os.path.join(inbox, only)):
        leftover = [f for _, _, fs in os.walk(os.path.join(inbox, only)) for f in fs if f not in SKIP]
        if not leftover:
            shutil.rmtree(os.path.join(inbox, only))
    print(json.dumps({"project": name, "id": pid, "format": fkey, "format_label": fmt["label"], "emne_slug": emne,
                      "final_prefix": f"{pid}_{emne}", "path": proj.replace("\\", "/"), "created": created,
                      "moved": moved, "raw_files": sorted(os.listdir(raw))}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
