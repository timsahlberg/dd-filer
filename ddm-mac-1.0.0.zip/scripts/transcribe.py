"""Danish transcription with word times (faster-whisper; NVIDIA GPU if there is one, else the processor; Mac = processor).

  python transcribe.py <video eller wav> <ud.json> [--rettelser rettelser.json] [--model large-v3-turbo] [--sprog da]

Writes {"duration", "words": [{"text", "start", "end"}], "speech": [[a, b], ...], "segments": [...]}.
The audio is decoded per speech run (<= 20 s), because one pass over a whole recording can skip long stretches.
"speech" are the stretches with voice on a 10 ms loudness curve (used to cut away retakes and pauses).
--rettelser: a JSON {"forkert": "rigtigt"} applied to the words (names, trade words Whisper mishears).
"""
import argparse, json, os, subprocess, sys, tempfile, wave

import numpy as np


def to_wav(src):
    if src.lower().endswith(".wav"):
        return src
    out = os.path.join(tempfile.mkdtemp(), "lyd.wav")
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", src, "-vn", "-ac", "1", "-ar", "16000", out], check=True)
    return out


def load(p):
    w = wave.open(p)
    return np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(np.float32) / 32768.0


def speech(pcm, thr=-45.0, min_sil=0.35):
    env = np.array([np.sqrt(np.mean(pcm[i:i + 160] ** 2) + 1e-12) for i in range(0, len(pcm) - 160, 160)])
    loud = 20 * np.log10(env) > thr
    iv, start, quiet = [], None, 0
    for j, on in enumerate(loud):
        if on:
            if start is None:
                start = j
            quiet = 0
        elif start is not None:
            quiet += 1
            if quiet >= int(min_sil * 100):
                iv.append((start / 100, (j - quiet + 1) / 100)); start, quiet = None, 0
    if start is not None:
        iv.append((start / 100, len(loud) / 100))
    return [(round(a, 2), round(b, 2)) for a, b in iv if b - a >= 0.08]


def cuda_dlls():
    """On Windows the NVIDIA libraries can come as pip packages (nvidia-cublas-cu12, nvidia-cudnn-cu12): make them findable."""
    if os.name != "nt":
        return
    import site
    for sp in site.getsitepackages():
        for sub in ("cublas", "cudnn"):
            d = os.path.join(sp, "nvidia", sub, "bin")
            if os.path.isdir(d):
                os.add_dll_directory(d)
                os.environ["PATH"] = d + os.pathsep + os.environ.get("PATH", "")


def model(name):
    from faster_whisper import WhisperModel
    try:
        import ctranslate2
        if ctranslate2.get_cuda_device_count() > 0:
            cuda_dlls()
            m = WhisperModel(name, device="cuda", compute_type="float16")
            list(m.transcribe(np.zeros(16000, np.float32), language="da")[0])   # fails here when cuBLAS/cuDNN are missing
            return m, "gpu"
    except Exception:
        pass
    return WhisperModel(name, device="cpu", compute_type="int8"), "cpu"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("src")
    ap.add_argument("out")
    ap.add_argument("--rettelser")
    ap.add_argument("--model", default="large-v3-turbo")
    ap.add_argument("--sprog", default="da", help="da, en ... eller auto")
    a = ap.parse_args()
    fix = json.load(open(a.rettelser, encoding="utf-8")) if a.rettelser and os.path.exists(a.rettelser) else {}
    fixl = {k.lower(): v for k, v in fix.items()}
    pcm = load(to_wav(a.src))
    dur = len(pcm) / 16000
    sp = speech(pcm)
    chunks, cur = [], None
    for s, e in sp:
        if cur and e - cur[0] <= 20:
            cur[1] = e
        else:
            if cur:
                chunks.append(cur)
            cur = [s, e]
    if cur:
        chunks.append(cur)
    try:
        m, dev = model(a.model)
    except Exception:
        m, dev = model("medium")
    words, segs = [], []
    for s, e in chunks:
        a0, b0 = max(0, s - 0.25), min(dur, e + 0.25)
        res, _ = m.transcribe(pcm[int(a0 * 16000):int(b0 * 16000)], language=None if a.sprog == "auto" else a.sprog, word_timestamps=True, temperature=0,
                              condition_on_previous_text=False, vad_filter=False, beam_size=5)
        for seg in res:
            segs.append({"start": round(a0 + seg.start, 2), "end": round(a0 + seg.end, 2), "text": seg.text.strip()})
            for w in seg.words or []:
                t = w.word.strip()
                if not t:
                    continue
                core = t.strip(".,!?:;").lower()
                if core in fixl:
                    t = t.lower().replace(core, fixl[core])
                words.append({"text": t, "start": round(a0 + w.start, 3), "end": round(a0 + w.end, 3)})
    json.dump({"duration": round(dur, 3), "words": words, "speech": sp, "segments": segs, "enhed": dev},
              open(a.out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    for sg in segs:
        print(f"[{sg['start']:6.2f}-{sg['end']:6.2f}] {sg['text']}")
    print(f"{len(words)} ord, {dur:.1f} s, kørte på {dev}")


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
