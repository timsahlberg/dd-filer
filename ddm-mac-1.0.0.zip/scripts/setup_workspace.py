"""Creates the kursist's workspace. Run once by the setup skill (opsaetning).

  python setup_workspace.py "<mappe>" --navn "<Navn>" [--online] [--tilladelser]

<mappe> is created if it does not exist: a local folder (e.g. Dokumenter/DDM-Content) or a folder inside the Google
Drive app (then everything, also 03_Final, is online). Re-running is safe: existing files are kept.
--tilladelser writes .claude/settings.json in the workspace so the automatic runs do not stop to ask for permission
(only when the kursist said yes to it in the setup).
Prints JSON with the paths made.
"""
import argparse, json, os, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import paths  # noqa: E402

FOLDERS = ["00_Indbakke/Talking-head", "00_Indbakke/Karrusel", "00_Indbakke/Detaljevideoer",
           "01_Projekter/Talking-head", "01_Projekter/Karrusel", "01_Projekter/Detaljevideoer",
           "02_Materialer/Brand", "02_Materialer/Musik", "02_Materialer/Billeder", "02_Materialer/B-roll",
           "02_Materialer/Stil-reference", "02_Materialer/Figurer",
           "03_Final/Talking-head", "03_Final/Karrusel", "03_Final/Detaljevideoer", "_System"]

LAES_MIG = {
    "00_Indbakke/Talking-head": "TALKING-HEAD\n\nLæg din råvideo her (én fil = én reel). Kald filen det, videoen handler om.\nDen færdige reel kommer i 03_Final/Talking-head.\n",
    "00_Indbakke/Karrusel": ("KARRUSEL\n\nLæg et Word- eller Google Docs-dokument her med det, opslaget skal handle om (ét dokument = ét opslag),\n"
                             "eller lav en mappe med dokumentet + billeder/video. Skriv dokumentet færdigt et andet sted og flyt det herind bagefter.\n"
                             "Det færdige opslag kommer i 03_Final/Karrusel.\n"),
    "00_Indbakke/Detaljevideoer": ("DETALJEVIDEOER\n\nLav én mappe pr. bolig/område med alt råmaterialet (drone, b-roll). Det skal ikke klippes til.\n"
                                   "Læg gerne et dokument med om, hvad der skal fremhæves. Sæt ★ forrest i filnavnet på et klip, der SKAL med.\n"
                                   "Den færdige video kommer i 03_Final/Detaljevideoer.\n"),
    "02_Materialer/Musik": ("MUSIK\n\nLæg 5-10 musiknumre her (mp3/wav), som du har ret til at bruge, fx fra Pixabay Music eller YouTube Audio Library.\n"
                            "Detaljevideoer klippes til dem. Er mappen tom, laves videoerne uden musik, og du lægger lyd på i Instagram.\n"),
    "02_Materialer/Stil-reference": "STIL-REFERENCE\n\nHer gemmes de Instagram-opslag, du har valgt som stil-reference, og analysen af dem (stil.md).\n",
    "02_Materialer/Brand": "BRAND\n\nDin visuelle identitet: logo, brand-PDF, farver og fonte. brand.json i _System bygges ud fra det.\n",
}

CLAUDE_MD = """# {navn} · SoMe-system

Arbejdsmappe for Den Digitale Mæglers content-system (plugin). Skriv til {navn} på dansk, kort og konkret.

- `00_Indbakke/<format>/`: nyt materiale. `01_Projekter/<format>/<ID>_<emne>_<dato>/`: et projekt pr. opslag (1_Raw, 2_Projekt, 3_Final, opslag.md, udgivet.json).
- `02_Materialer/`: Brand, Musik, Billeder, B-roll, Stil-reference, Figurer. `03_Final/<format>/`: kun den nyeste version af hvert færdigt opslag.
- `_System/ddm.json` (indstillinger), `_System/brand.json` (farver, fonte, CTA, tone), `_System/stil.md` (stilen fra referencerne).
- Formater: talking-head (TH), karrusel (KA), detaljevideo (DV). Kommandoerne findes i plugin'en: talkinghead-video, karrusel, detaljevideo.
- Overskriv aldrig en færdig fil i et projekts 3_Final; nye versioner får _v2, _v3. I 03_Final erstatter den nyeste den gamle.
- Opfind aldrig fakta, tal eller påstande: kun det, der står i materialet eller siges i videoen.
"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mappe")
    ap.add_argument("--navn", default="")
    ap.add_argument("--online", action="store_true")
    ap.add_argument("--tilladelser", action="store_true")
    a = ap.parse_args()
    root = os.path.abspath(os.path.expanduser(a.mappe))
    for f in FOLDERS:
        os.makedirs(os.path.join(root, f), exist_ok=True)
    for f, txt in LAES_MIG.items():
        p = os.path.join(root, f, "LAES-MIG.txt")
        if not os.path.exists(p):
            open(p, "w", encoding="utf-8").write(txt)
    cfgp = os.path.join(root, "_System", "ddm.json")
    cfg = json.load(open(cfgp, encoding="utf-8")) if os.path.exists(cfgp) else {}
    cfg.update({"navn": a.navn or cfg.get("navn", ""), "online": a.online or cfg.get("online", False),
                "os": "mac" if paths.IS_MAC else "windows", "plugin": paths.PLUGIN, "version": 1})
    py = os.path.join(root, "_System", ".venv", "bin" if not paths.IS_WIN else "Scripts", "python.exe" if paths.IS_WIN else "python")
    cfg["python"] = py
    json.dump(cfg, open(cfgp, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    md = os.path.join(root, "CLAUDE.md")
    if not os.path.exists(md):
        open(md, "w", encoding="utf-8").write(CLAUDE_MD.format(navn=a.navn or "kursisten"))
    made_settings = False
    if a.tilladelser:
        rel_py = "_System/.venv/Scripts/python.exe" if paths.IS_WIN else "_System/.venv/bin/python"
        allow = [f"Bash({rel_py}:*)", f"Bash(./{rel_py}:*)", "Bash(ffmpeg:*)", "Bash(ffprobe:*)", "Bash(npx hyperframes:*)",
                 "Bash(npx --yes hyperframes:*)"]
        sp = os.path.join(root, ".claude", "settings.json")
        os.makedirs(os.path.dirname(sp), exist_ok=True)
        cur = json.load(open(sp, encoding="utf-8")) if os.path.exists(sp) else {}
        al = cur.setdefault("permissions", {}).setdefault("allow", [])
        for x in allow:
            if x not in al:
                al.append(x)
        json.dump(cur, open(sp, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        made_settings = True
    # license-free sound effects, made locally
    subprocess.run([sys.executable, os.path.join(HERE, "lav_sfx.py"), os.path.join(root, "_System", "sfx")], capture_output=True)
    print(json.dumps({"mappe": root.replace("\\", "/"), "python": py.replace("\\", "/"), "tilladelser": made_settings,
                      "online": cfg["online"]}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
