"""Inbox check and run lock for the automatic runs (talkinghead-video, karrusel, detaljevideo).

  python inbox.py status  [format]   show ready items and lock state, change nothing
  python inbox.py claim   [format]   if no run is active and items are ready: take the lock, print the items
  python inbox.py release [format]   remove the lock (always call this when a run ends, also after an error)


[format] is a key or alias from config "formats" (default talking-head); its inbox is 00_Indbakke/<format folder>/.
- talking-head: each video file is one item.
- karrusel and detaljevideo (config inbox_mode "folder"): each subfolder is one item (one post: images, videos and a
  text file; for a detaljevideo all the raw footage of one home or place). Loose files directly
  in the inbox count together as one item, "(løse filer)", except when they are all documents (.docx, .txt, .md, .rtf):
  then each document is its own post (a Word file dropped in without a folder).
An item is "ready" when nothing in it has changed for STABLE_MIN minutes (so something still being copied in is left
alone). Each format has its own lock, _System/koerer_<KODE>.lock; a lock older than STALE_H hours counts as abandoned.
Prints JSON: {"status": "ready" | "empty" | "busy" | "waiting", "files": [...], "lock": {...}}.
"""
import datetime, json, os, sys, time

import paths
from paths import find_format, inbox_dir

paths.load()

HERE = os.path.dirname(os.path.abspath(__file__))
VIDEO = (".mp4", ".mov", ".m4v", ".mxf")
SKIP = {"LAES-MIG.txt", "desktop.ini", "Thumbs.db", ".DS_Store"}
LOOSE = "(løse filer)"
TEXT = (".txt", ".md", ".docx", ".rtf")
STABLE_MIN, STALE_H = 2, 8


def items(fkey, inbox, folder_mode=False):
    """{item name: newest mtime of its files}."""
    out = {}
    if not os.path.isdir(inbox):
        return out
    for f in sorted(os.listdir(inbox)):
        p = os.path.join(inbox, f)
        if f in SKIP:
            continue
        if folder_mode:
            if os.path.isdir(p):
                times = [os.path.getmtime(os.path.join(d, x)) for d, _, xs in os.walk(p) for x in xs if x not in SKIP]
                if times:
                    out[f] = max(times)
            elif os.path.isfile(p):
                out[LOOSE] = max(out.get(LOOSE, 0), os.path.getmtime(p))
    if fkey == "karrusel" and LOOSE in out:
        loose = [f for f in os.listdir(inbox) if os.path.isfile(os.path.join(inbox, f)) and f not in SKIP]
        if all(f.lower().endswith(TEXT) for f in loose):
            # only documents lying loose: each one is its own post (a Word file dropped in without a folder)
            del out[LOOSE]
            for f in loose:
                out[f] = os.path.getmtime(os.path.join(inbox, f))
        elif os.path.isfile(p) and f.lower().endswith(VIDEO):
            out[f] = os.path.getmtime(p)
    return out


def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "status"
    fkey, fmt = find_format(sys.argv[2] if len(sys.argv) > 2 else "talking-head")
    if not fmt or cmd not in ("status", "claim", "release"):
        sys.exit(__doc__)
    lock_path = os.path.join(paths.ROOT, "_System", f"koerer_{fmt['code']}.lock")
    if cmd == "release":
        if os.path.exists(lock_path):
            os.remove(lock_path)
        print(json.dumps({"status": "released", "format": fkey})); return
    now = time.time()
    found = items(fkey, inbox_dir(fmt), fmt.get("inbox_mode") == "folder")
    ready = [n for n, t in found.items() if now - t >= STABLE_MIN * 60]
    waiting = [n for n in found if n not in ready]
    lock = None
    if os.path.exists(lock_path):
        try:
            lock = json.load(open(lock_path, encoding="utf-8"))
        except Exception:
            lock = {}
        lock["age_h"] = round((now - os.path.getmtime(lock_path)) / 3600, 2)
        lock["stale"] = lock["age_h"] >= STALE_H
    if lock and not lock["stale"]:
        status = "busy"
    elif ready:
        status = "ready"
    elif waiting:
        status = "waiting"
    else:
        status = "empty"
    if cmd == "claim" and status == "ready":
        json.dump({"started": datetime.datetime.now().isoformat(timespec="seconds"), "files": ready}, open(lock_path, "w", encoding="utf-8"), ensure_ascii=False)
    print(json.dumps({"status": status, "format": fkey, "inbox": inbox_dir(fmt).replace("\\", "/"),
                      "files": ready if status == "ready" else [], "waiting": waiting, "lock": lock}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
