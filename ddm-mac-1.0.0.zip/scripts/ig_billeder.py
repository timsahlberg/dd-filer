"""Saves the slides of an Instagram carousel from image addresses (found with the built-in browser, no login needed).

  python ig_billeder.py <post-kode> <adresse> [<adresse> ...]       or      python ig_billeder.py <post-kode> --fil adresser.txt

Saves 01.jpg, 02.jpg ... in 02_Materialer/Stil-reference/<post-kode>/. Prints JSON.
How to get the addresses: open the post in Claude's built-in browser, close the login pop-up, click "Next" through the
slides while collecting every <img> with naturalWidth >= 1000 (see the stil skill), then pass the list here.
"""
import json, os, sys, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import paths  # noqa: E402

UA = {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36"}


def main():
    a = sys.argv[1:]
    if len(a) < 2:
        sys.exit(__doc__)
    code, urls = a[0], a[1:]
    if urls[0] == "--fil":
        urls = [l.strip() for l in open(urls[1], encoding="utf-8") if l.strip()]
    paths.load()
    d = os.path.join(paths.ROOT, "02_Materialer", "Stil-reference", code)
    os.makedirs(d, exist_ok=True)
    saved = []
    for k, u in enumerate(dict.fromkeys(urls), 1):
        try:
            with urllib.request.urlopen(urllib.request.Request(u, headers=UA), timeout=30) as r:
                p = os.path.join(d, f"{k:02d}.jpg")
                open(p, "wb").write(r.read())
                saved.append(os.path.basename(p))
        except Exception as e:
            saved.append(f"FEJL {k}: {e}")
    print(json.dumps({"mappe": d.replace("\\", "/"), "filer": saved}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
