"""Reel engine: turns a cut talking-head clip + its transcript into a HyperFrames project in the kursist's brand.

Used by a small per-video build file that Claude writes (see reel_eksempel.py):

    import sys; sys.path.insert(0, r"<plugin>/scripts")
    import reel_engine as R
    R.init(r"<projektmappe>")            # reads 2_Projekt/v1/transcript.json + talk.mp4, brand.json, stil.md settings
    T = R.T                              # T("ord", after) = start of the first word "ord" at/after `after` seconds
    R.scene("s01", 0, T("og", 4), body, cues, eb="Mobilvideo · 5 ting", h="Det er ikke din telefon,", amb="der er problemet.")
    R.chapter("s05", a, b, "02", "Lyden.")
    R.full("s06", a, b)                  # full screen talking head, no graphics
    R.cta("s20", a, R.DUR)               # last scene: the brand's CTA keyword as a pill
    R.EMPH += [("vinduet", 16), ...]     # caption words in the accent colour
    R.build()                            # writes 2_Projekt/film/
    R.render()                           # npx hyperframes render + loudness -14 LUFS -> 3_Final/<ID>_<emne>_v<N>.mp4

Layout (brand.json "reel_layout"):
  "split" (default): graphics in the top 2/3 under a chapter header, the person in a rounded panel at the bottom (the
           face is found automatically), hard cuts to full screen for punch lines and each new chapter.
  "fuld":  the person full screen all the time; graphics and header on a dark band in the top half.
Captions: brand.json "undertekster": "ord" (one word at a time, default) or "linje" (2-3 words together).
Cues inside a scene: up(selector, t), pop(selector, t), ("set"|"to", selector, t, "{...}"), ("from", selector, t, "{from}", "{to}").
Times are seconds in the cut video. Use T("ord", after) to anchor to words; always give `after`, because short words
("og", "det", "3") appear many times.
"""
import html, json, os, re, shutil, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import paths  # noqa: E402

PROJECT = VDIR = FILM = None
words, DUR = [], 0.0
TK, B = {}, {}
SCENES, EMPH = [], []
SPLIT_CAM, FULL_CAM = (0, 940, 1.0), (0, 0, 1.0)
PANEL_CLIP = "inset(1300px 70px 0px 70px round 34px 34px 0px 0px)"
FULL_CLIP = "inset(0px 0px 0px 0px round 0px 0px 0px 0px)"
DEFAULT = {"bg": "#0D1119", "surface": "#141A26", "line": "#252E3F", "chip_line": "#2E3748", "text": "#EEF1F6", "muted": "#97A1B4",
           "accent": "#FFB547", "on_accent": "#1A1206", "good": "#FFD08A", "bad": "#FFB0B0", "info": "#AFC8FF",
           "head": "Bricolage Grotesque", "body": "Instrument Sans", "mono": "JetBrains Mono"}
norm = lambda t: re.sub(r"[^\wæøå/-]", "", t.lower())


def rgb(h):
    return ",".join(str(int(h[i:i + 2], 16)) for i in (1, 3, 5))


def init(project_dir, vdir="v1"):
    global PROJECT, VDIR, FILM, words, DUR, TK, B, SPLIT_CAM
    PROJECT = os.path.abspath(project_dir)
    paths.load(PROJECT)
    VDIR = os.path.join(PROJECT, "2_Projekt", vdir)
    FILM = os.path.join(PROJECT, "2_Projekt", "film")
    tr = json.load(open(os.path.join(VDIR, "transcript.json"), encoding="utf-8"))
    words, DUR = tr["words"], round(tr["duration"], 3)
    B = paths.brand()
    TK = dict(DEFAULT)
    TK.update({k: v for k, v in (B.get("farver") or {}).items() if v})
    TK.update({k: v for k, v in (B.get("fonte") or {}).items() if v})
    SPLIT_CAM = face_cam(os.path.join(VDIR, "talk.mp4"))
    SCENES.clear(); EMPH.clear()


def face_cam(video):
    """Find the face in the 1080x1920 clip and place it in the bottom panel (x 70-1010, y 1300-1920)."""
    try:
        import cv2
        cas = cv2.CascadeClassifier(os.path.join(cv2.data.haarcascades, "haarcascade_frontalface_default.xml"))
        cap = cv2.VideoCapture(video)
        n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 1
        faces = []
        for k in range(12):
            cap.set(cv2.CAP_PROP_POS_FRAMES, int(n * (k + .5) / 12))
            ok, fr = cap.read()
            if not ok:
                continue
            g = cv2.cvtColor(fr, cv2.COLOR_BGR2GRAY)
            f = cas.detectMultiScale(g, 1.1, 6, minSize=(120, 120))
            if len(f):
                x, y, w, h = max(f, key=lambda r: r[2] * r[3])
                faces.append((x + w / 2, y + h / 2, h))
        cap.release()
        if faces:
            faces.sort(key=lambda f: f[2])
            fx, fy, fh = faces[len(faces) // 2]
        else:
            fx, fy, fh = 540, 700, 330
    except Exception:
        fx, fy, fh = 540, 700, 330
    s = max(1.0, min(2.0, 250 / fh))     # face ~250 px high, so hair and shoulders fit
    x = 540 - fx * s
    y = 1610 - fy * s                    # face centre a bit below the panel's middle: room above the hair
    x = min(70, max(1010 - 1080 * s, x))           # the video must cover the panel
    y = min(1300, max(1920 - 1920 * s, y))
    return (round(x), round(y), round(s, 3))


def T(word, after=0.0, n=1):
    k = 0
    for w in words:
        if w["start"] >= after - 0.05 and norm(w["text"]).startswith(norm(word)):
            k += 1
            if k == n:
                return w["start"]
    raise KeyError(f"Ordet '{word}' findes ikke efter {after} s")


def css():
    fonts = ""
    bcss = os.path.join(paths.ROOT, "_System", "brand.css")
    if os.path.exists(bcss):
        fonts = "\n".join(l.replace('url("fonts/', 'url("assets/fonts/') for l in open(bcss, encoding="utf-8").read().splitlines() if l.startswith("@font-face"))
    t = TK
    return f"""
@font-face {{ font-family: "Bricolage Grotesque"; src: url("assets/fonts/Bricolage.ttf"); font-weight: 200 800; }}
@font-face {{ font-family: "Instrument Sans"; src: url("assets/fonts/InstrumentSans.ttf"); font-weight: 400 700; }}
@font-face {{ font-family: "JetBrains Mono"; src: url("assets/fonts/JetBrainsMono-400.woff2"); font-weight: 400; }}
@font-face {{ font-family: "JetBrains Mono"; src: url("assets/fonts/JetBrainsMono-700.woff2"); font-weight: 700; }}
{fonts}
#root {{ position: absolute; inset: 0; overflow: hidden; font-family: "{t['body']}", sans-serif; color: {t['text']}; }}
.wrap {{ position: absolute; inset: 0; }}
.band {{ position: absolute; left: 0; right: 0; top: 0; height: 1260px; background: linear-gradient(180deg, rgba({rgb(t['bg'])},.92) 0%, rgba({rgb(t['bg'])},.86) 70%, rgba({rgb(t['bg'])},0) 100%); }}
.hdr {{ position: absolute; left: 110px; right: 110px; top: 252px; text-align: center; display: flex; flex-direction: column; align-items: center; gap: 16px; }}
.eb {{ font-family: "{t['mono']}", monospace; font-size: 28px; letter-spacing: .14em; text-transform: uppercase; color: {t['accent']}; }}
.h {{ font-family: "{t['head']}", sans-serif; font-weight: 800; font-size: 82px; line-height: 1.04; letter-spacing: -.02em; }}
.h .a {{ color: {t['accent']}; }}
.wm {{ display: inline-block; overflow: hidden; vertical-align: top; padding-bottom: 6px; margin-bottom: -6px; }}
.wi {{ display: inline-block; }}
.gfx {{ position: absolute; left: 110px; right: 110px; top: 520px; height: 660px; display: flex; align-items: center; justify-content: center; }}
.card {{ background: {t['surface']}; border: 2px solid {t['line']}; border-radius: 30px; position: relative; }}
.card.hi {{ border-color: {t['accent']}; }}
.tag {{ display: inline-flex; align-items: center; gap: 12px; padding: 10px 24px; border-radius: 999px; font-weight: 600; font-size: 32px; white-space: nowrap; }}
.tag.bad {{ color: {t['bad']}; background: rgba({rgb(t['bad'])},.14); }}
.tag.good {{ color: {t['good']}; background: rgba({rgb(t['accent'])},.14); }}
.tag.info {{ color: {t['info']}; background: rgba({rgb(t['info'])},.14); }}
.tag.ghost {{ color: {t['muted']}; border: 2px solid {t['line']}; }}
.ck {{ width: 34px; height: 34px; border-radius: 50%; background: {t['accent']}; color: {t['on_accent']}; display: inline-flex; align-items: center; justify-content: center; font-size: 22px; font-weight: 800; flex: none; }}
.abs {{ position: absolute; }}
.phone {{ width: 300px; height: 600px; border-radius: 68px; background: {t['surface']}; padding: 14px; box-shadow: 0 0 0 2px {t['chip_line']}, 0 40px 80px rgba(0,0,0,.55), 0 0 120px rgba({rgb(t['accent'])},.10); position: relative; }}
.scr {{ width: 100%; height: 100%; border-radius: 56px; overflow: hidden; position: relative; background: #05070c; }}
.scr img, .scr video {{ width: 100%; height: 100%; object-fit: cover; display: block; }}
.chipg {{ background: rgba({rgb(t['surface'])},.86); border: 2px solid {t['chip_line']}; border-radius: 27px; padding: 22px 28px; display: flex; flex-direction: column; gap: 4px; }}
.ml {{ font-family: "{t['mono']}", monospace; font-size: 28px; letter-spacing: .14em; text-transform: uppercase; color: {t['muted']}; }}
.chipg .v {{ font-family: "{t['head']}", sans-serif; font-weight: 800; font-size: 46px; letter-spacing: -.02em; line-height: 1; }}
.pill {{ height: 72px; border-radius: 999px; border: 2px solid {t['line']}; background: {t['surface']}; display: flex; align-items: center; gap: 22px; padding: 0 30px; font-weight: 600; font-size: 34px; }}
.pill .no {{ font-family: "{t['mono']}", monospace; font-size: 30px; color: {t['accent']}; }}
.pill .ck {{ margin-left: auto; }}
.big {{ font-family: "{t['head']}", sans-serif; font-weight: 800; letter-spacing: -.02em; }}
.acc {{ color: {t['accent']}; }}
.row {{ display: flex; align-items: center; gap: 18px; }}
.sb {{ justify-content: space-between; }}
"""


def scene(sid, start, end, body, cues, eb=None, h=None, amb=None, full=False, hdr_in=True, extra_css=""):
    SCENES.append(dict(id=sid, start=round(start, 3), end=round(end, 3), body=body, cues=cues, eb=eb, h=h, amb=amb, full=full, hdr_in=hdr_in, css=extra_css))


def full(sid, start, end):
    scene(sid, start, end, "", [], full=True)


def up(sel, t, d=0.9, y=48):
    return ("up", sel, t, d, y)


def pop(sel, t):
    return ("pop", sel, t)


def chapter(sid, a, b, num, title):
    scene(sid, a, b,
          f'<div style="position:absolute;left:0;right:0;top:960px;display:flex;flex-direction:column;align-items:center;gap:6px;text-shadow:0 10px 50px rgba(0,0,0,.6)">'
          f'<div class="big acc" id="{sid}-n" style="font-size:260px;line-height:.9;letter-spacing:-.03em">{html.escape(num)}</div>'
          f'<div class="big" id="{sid}-t" style="font-size:96px">{html.escape(title)}</div></div>',
          [up(f"#{sid}-n", a, d=.7), up(f"#{sid}-t", a + 0.12, d=.7)], full=True)
    SCENES[-1]["chapter"] = True


def cta(sid, a, b, keyword=None):
    k = keyword or B.get("cta_keyword") or "INFO"
    scene(sid, a, b,
          f'<div style="position:absolute;left:0;right:0;top:1290px;display:flex;justify-content:center">'
          f'<span id="{sid}-p" style="background:{TK["accent"]};color:{TK["on_accent"]};font-family:\'{TK["head"]}\',sans-serif;font-weight:800;font-size:96px;'
          f'letter-spacing:-.02em;padding:14px 64px 22px;border-radius:999px;box-shadow:0 10px 28px rgba({rgb(TK["accent"])},.28)">{html.escape(k)}</span></div>',
          [pop(f"#{sid}-p", a + 0.1)], full=True)
    SCENES[-1]["cta"] = True


def js_for(c, start):
    kind = c[0]
    t = max(0.0, c[2] - start)
    if kind == "up":
        _, sel, _, d, y = c
        return f'tl.fromTo("{sel}", {{ y: {y}, opacity: 0 }}, {{ y: 0, opacity: 1, duration: {d}, ease: "expo.out", stagger: .07 }}, {t:.3f});'
    if kind == "pop":
        return f'tl.fromTo("{c[1]}", {{ scale: .6, opacity: 0 }}, {{ scale: 1, opacity: 1, duration: .9, ease: "expo.out" }}, {t:.3f});'
    if kind == "set":
        return f'tl.set("{c[1]}", {c[3]}, {t:.3f});'
    if kind == "to":
        return f'tl.to("{c[1]}", {c[3]}, {t:.3f});'
    if kind == "from":
        return f'tl.fromTo("{c[1]}", {c[3]}, {c[4]}, {t:.3f});'
    raise ValueError(kind)


def header(sid, eb, h, amb):
    ws = [(w, False) for w in (h or "").split()] + [(w, True) for w in (amb or "").split()]
    inner = " ".join(f'<span class="wm"><span class="wi {sid}-hw{" a" if a else ""}">{html.escape(w)}</span></span>' for w, a in ws)
    return f'<div class="hdr"><div class="eb" id="{sid}-eb">{html.escape(eb or "")}</div><div class="h">{inner}</div></div>'


def layout():
    return (B.get("reel_layout") or "split").lower()


def write_scene(s):
    dur = s["end"] - s["start"]
    body = s["body"].replace("{D}", f"{dur:.3f}")
    hdr = ""
    js = [js_for(c, s["start"]) for c in s["cues"]]
    if not s["full"]:
        hdr = header(s["id"], s["eb"], s["h"], s["amb"])
        if s["hdr_in"]:
            js.insert(0, f'tl.fromTo("#{s["id"]}-eb", {{ y: 34, opacity: 0 }}, {{ y: 0, opacity: 1, duration: .9, ease: "expo.out" }}, 0);')
            js.insert(1, f'tl.fromTo(".{s["id"]}-hw", {{ yPercent: 110 }}, {{ yPercent: 0, duration: 1.0, ease: "expo.out", stagger: .045 }}, .08);')
        body = f'<div class="gfx">{body}</div>'
        if layout() == "fuld":
            hdr = '<div class="band"></div>' + hdr
    fade = f'#{s["id"]}-wrap' if s["full"] or s["hdr_in"] else f'#{s["id"]}-wrap .gfx'
    js.insert(0, f'tl.fromTo("{fade}", {{ opacity: 0 }}, {{ opacity: 1, duration: .2 }}, 0);')
    doc = f"""<!doctype html>
<html><head><meta charset="UTF-8" /></head>
<body>
<template>
<style>
{css()}
{s['css']}
</style>
<div id="root" data-composition-id="{s['id']}" data-width="1080" data-height="1920">
<div class="wrap" id="{s['id']}-wrap">
{hdr}
{body}
</div>
</div>
<script>
(() => {{
const tl = gsap.timeline({{ paused: true }});
{chr(10).join(js)}
window.__timelines["{s['id']}"] = tl;
}})();
</script>
</template>
</body></html>
"""
    open(os.path.join(FILM, "compositions", f"{s['id']}.html"), "w", encoding="utf-8").write(doc)


def caption_words():
    emph = set()
    for w, a in EMPH:
        try:
            emph.add(round(T(w, a), 3))
        except KeyError:
            print("Fremhævet ord ikke fundet:", w, a)
    clean = lambda t: re.sub(r"[.,!?]+$", "", t)
    out = []
    for k, w in enumerate(words):
        start = max(0.12, w["start"])
        nxt = words[k + 1]["start"] if k + 1 < len(words) else DUR
        end = min(nxt if nxt - w["end"] < 0.35 else w["end"] + 0.15, DUR - 0.02)
        top, size = (1236, 50) if layout() == "split" else (1330, 56)
        for s in SCENES:
            if s["full"] and s["start"] <= start < s["end"]:
                top, size = (1490, 54) if s.get("chapter") else (1200, 54)
                if s.get("cta"):
                    top = 1180
        out.append([clean(w["text"]).lower() if not w["text"].isupper() else clean(w["text"]), start, max(end, start + 0.1), top, size, round(w["start"], 3) in emph])
    group = 3 if (B.get("undertekster") or "ord") == "linje" else 1
    merged = []
    for e in out:
        short = merged and merged[-1][2] - merged[-1][1] < 0.13 and len(merged[-1][0]) + len(e[0]) < 18
        grouped = group > 1 and merged and len(merged[-1][0].split()) < group and len(merged[-1][0]) + len(e[0]) < 22 and e[1] - merged[-1][2] < 0.3
        if merged and merged[-1][3] == e[3] and (short or grouped):
            p = merged.pop()
            e = [p[0] + " " + e[0], p[1], e[2], e[3], e[4], p[5] or e[5]]
        merged.append(e)
    return merged


def write_captions():
    cw = caption_words()
    spans = "\n".join(f'<div class="cw{" em" if em else ""}" id="cw-{i}" style="top:{top}px;font-size:{size}px">{html.escape(t)}</div>'
                      for i, (t, s, e, top, size, em) in enumerate(cw))
    js = "\n".join(f'tl.set("#cw-{i}", {{ opacity: 1 }}, {s:.3f}); tl.fromTo("#cw-{i}", {{ y: 10 }}, {{ y: 0, duration: {max(0.02, min(0.15, e - s - 0.02)):.3f}, ease: "expo.out", immediateRender: false }}, {s:.3f}); tl.set("#cw-{i}", {{ opacity: 0 }}, {e:.3f});'
                   for i, (t, s, e, top, size, em) in enumerate(cw))
    t = TK
    doc = f"""<!doctype html>
<html><head><meta charset="UTF-8" /></head>
<body>
<template>
<style>
{css()}
#root {{ position: absolute; inset: 0; pointer-events: none; }}
.cw {{ position: absolute; left: 60px; right: 60px; height: 80px; margin-top: -40px; display: flex; align-items: center; justify-content: center; opacity: 0;
  font-family: "{t['body']}", sans-serif; font-weight: 600; color: {t['text']}; text-shadow: 0 2px 14px rgba({rgb(t['bg'])},.8), 0 0 3px rgba({rgb(t['bg'])},.6); white-space: nowrap; }}
.cw.em {{ color: {t['accent']}; }}
</style>
<div id="root" data-composition-id="captions" data-width="1080" data-height="1920">
{spans}
</div>
<script>
(() => {{
const tl = gsap.timeline({{ paused: true }});
gsap.set(".cw", {{ opacity: 0 }});
{js}
window.__timelines["captions"] = tl;
}})();
</script>
</template>
</body></html>
"""
    open(os.path.join(FILM, "compositions", "captions.html"), "w", encoding="utf-8").write(doc)


SFXLEN = {"pop": 0.7, "click": 0.35, "click-soft": 0.35, "whoosh-short": 0.57, "whoosh": 1.1, "chime": 1.6, "impact-bass-1": 1.2, "key-press": 0.35, "error": 1.3}


def sfx_cues():
    c = []
    add = lambda f, t, v=0.25: c.append((f, round(t, 3), v))
    prev = None
    for s in SCENES:
        if s.get("chapter"):
            add("whoosh-short", s["start"], 0.3); add("impact-bass-1", s["start"] + 0.02, 0.18)
        elif not s["full"] and s["eb"] != prev:
            add("whoosh-short", s["start"], 0.2)
        if not s["full"]:
            prev = s["eb"]
        if s.get("cta"):
            add("pop", s["start"] + 0.1, 0.3)
        for cue in s["cues"]:
            if cue[0] in ("up", "pop", "from") and cue[2] > s["start"] + 0.3:
                add("pop" if cue[0] == "pop" else "click-soft", cue[2], 0.2)
    c.sort(key=lambda x: x[1])
    out = []
    for f, t, v in c:
        if out and t - out[-1][1] < 0.18:
            continue
        out.append((f, t, v))
    return out


def music_bed(track):
    """A quiet bed under the voice, ducked while the speaker talks (sidechain), fade in 0.6 s, out 1.8 s."""
    out = os.path.join(FILM, "assets", "music_bed.m4a")
    fc = (f"[1:a]atrim=0:{DUR:.3f},asetpts=PTS-STARTPTS,volume=-17dB,afade=t=in:d=0.6,afade=t=out:st={max(0, DUR - 1.8):.3f}:d=1.8[m];"
          f"[0:a]aformat=channel_layouts=stereo[v];[m][v]sidechaincompress=threshold=0.03:ratio=4:attack=20:release=400[o]")
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", os.path.join(VDIR, "voice.m4a"), "-stream_loop", "-1", "-i", track,
                    "-filter_complex", fc, "-map", "[o]", "-t", f"{DUR:.3f}", "-c:a", "aac", "-b:a", "192k", out], check=True)
    return out


def write_index(has_music):
    hosts = "\n".join(
        f'      <div id="{s["id"]}" data-composition-id="{s["id"]}" data-composition-src="compositions/{s["id"]}.html" data-start="{s["start"]}" data-duration="{s["end"] - s["start"]:.3f}" '
        f'data-track-index="2" data-track-kind="graphics" data-width="1080" data-height="1920" style="z-index:5"></div>'
        for s in SCENES)
    sfx = "\n".join(
        f'      <audio id="sfx-{i}" class="clip" data-start="{t}" data-duration="{SFXLEN[f]}" data-track-index="{11 + i % 4}" data-volume="{v}" src="assets/sfx/{f}.mp3"></audio>'
        for i, (f, t, v) in enumerate(sfx_cues()))
    split = layout() == "split"
    lay, rim = [], []
    for s in SCENES:
        cam, clip = (FULL_CAM, FULL_CLIP) if (s["full"] or not split) else (SPLIT_CAM, PANEL_CLIP)
        lay.append(f'tl.set("#thcam", {{ x: {cam[0]}, y: {cam[1]}, scale: {cam[2]} }}, {s["start"]}); tl.set("#th", {{ clipPath: "{clip}" }}, {s["start"]});')
        rim.append(f'tl.set("#rim", {{ opacity: {1 if (split and not s["full"]) else 0} }}, {s["start"]});')
    t = TK
    music = (f'      <audio id="music" class="clip" data-start="0" data-duration="{DUR}" data-track-index="9" data-volume="1" src="assets/music_bed.m4a"></audio>'
             if has_music else "")
    doc = f"""<!doctype html>
<html lang="da" data-resolution="portrait">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=1080, height=1920" />
    <script src="https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js"></script>
    <style>
      * {{ margin: 0; padding: 0; box-sizing: border-box; }}
      html, body {{ margin: 0; width: 1080px; height: 1920px; overflow: hidden; background: {t['bg']}; }}
      #root {{ position: relative; width: 100%; height: 100%; overflow: hidden; }}
      #bg {{ position: absolute; inset: 0; background: radial-gradient(ellipse 70% 34% at 50% 26%, rgba({rgb(t['accent'])},.10), rgba({rgb(t['accent'])},0) 62%), {t['bg']}; }}
      #th {{ position: absolute; inset: 0; z-index: 1; overflow: hidden; }}
      #thcam {{ position: absolute; left: 0; top: 0; width: 1080px; height: 1920px; transform-origin: 0 0; }}
      #talk {{ display: block; width: 1080px; height: 1920px; }}
      #rim {{ position: absolute; left: 70px; top: 1300px; width: 940px; height: 660px; border-radius: 34px; box-shadow: inset 0 0 0 2px {t['line']}; z-index: 2; pointer-events: none; }}
    </style>
  </head>
  <body>
    <div id="root" data-composition-id="main" data-start="0" data-duration="{DUR}" data-width="1080" data-height="1920">
      <div id="bg"></div>
      <div id="th"><div id="thcam">
        <video id="talk" class="clip" data-start="0" data-duration="{DUR}" data-track-index="0" muted src="assets/talk.mp4"></video>
      </div></div>
      <div id="rim"></div>
{hosts}
      <div id="captions" data-composition-id="captions" data-composition-src="compositions/captions.html" data-start="0" data-duration="{DUR}" data-track-index="3" data-track-kind="captions" data-width="1080" data-height="1920" style="z-index:10"></div>
      <audio id="voice" class="clip" data-start="0" data-duration="{DUR}" data-track-index="10" data-volume="1" src="assets/voice.m4a"></audio>
{music}
{sfx}
    </div>
    <script>
      const tl = gsap.timeline({{ paused: true }});
      {chr(10).join("      " + l for l in lay).strip()}
      {chr(10).join("      " + l for l in rim).strip()}
      window.__timelines["main"] = tl;
    </script>
  </body>
</html>
"""
    open(os.path.join(FILM, "index.html"), "w", encoding="utf-8").write(doc)


def build(musik=None):
    """Write the HyperFrames project in 2_Projekt/film. musik = a track (e.g. 02_Materialer/Musik/x.mp3) or None."""
    SCENES.sort(key=lambda x: x["start"])
    for a, b in zip(SCENES, SCENES[1:]):
        if abs(a["end"] - b["start"]) > 0.01 or a["end"] <= a["start"]:
            sys.exit(f"Scenerne skal ligge i forlængelse af hinanden: {a['id']} slutter {a['end']}, {b['id']} starter {b['start']}")
        if not b["full"]:
            prev = next((p for p in reversed(SCENES[:SCENES.index(b)]) if not p["full"]), None)
            b["hdr_in"] = not prev or prev["eb"] != b["eb"] or prev["h"] != b["h"]
    if SCENES and abs(SCENES[-1]["end"] - DUR) > 0.05:
        print(f"Bemærk: sidste scene slutter {SCENES[-1]['end']}, videoen er {DUR} s")
    os.makedirs(os.path.join(FILM, "compositions"), exist_ok=True)
    os.makedirs(os.path.join(FILM, "assets", "fonts"), exist_ok=True)
    for f in ("hyperframes.json", "package.json"):
        shutil.copy2(os.path.join(paths.ASSETS, f), os.path.join(FILM, f))
    if not os.path.exists(os.path.join(FILM, "meta.json")):
        json.dump({"id": "film", "name": "film"}, open(os.path.join(FILM, "meta.json"), "w"))
    for f in os.listdir(os.path.join(paths.ASSETS, "karrusel", "fonts")):
        shutil.copy2(os.path.join(paths.ASSETS, "karrusel", "fonts", f), os.path.join(FILM, "assets", "fonts", f))
    bf = os.path.join(paths.ROOT, "_System", "fonts")
    if os.path.isdir(bf):
        for f in os.listdir(bf):
            shutil.copy2(os.path.join(bf, f), os.path.join(FILM, "assets", "fonts", f))
    sfx_dst = os.path.join(FILM, "assets", "sfx")
    if not os.path.isdir(sfx_dst):
        src = os.path.join(paths.ROOT, "_System", "sfx")
        if not os.path.isdir(src):
            subprocess.run([sys.executable, os.path.join(HERE, "lav_sfx.py"), src], check=True)
        shutil.copytree(src, sfx_dst)
    for f in ("talk.mp4", "voice.m4a"):
        shutil.copy2(os.path.join(VDIR, f), os.path.join(FILM, "assets", f))
    has_music = False
    if musik:
        track = next((os.path.join(b, musik) for b in (PROJECT, paths.ROOT) if os.path.exists(os.path.join(b, musik))), None)
        if track:
            music_bed(track); has_music = True
        else:
            print("Musikken blev ikke fundet, reelen laves uden:", musik)
    for s in SCENES:
        write_scene(s)
    write_captions()
    write_index(has_music)
    for s in SCENES:
        print(f'{s["id"]} {s["start"]:7.2f}-{s["end"]:7.2f} {"FULD" if s["full"] else "split"} {s["eb"] or ""}')
    print(f"{len(SCENES)} scener, {len(caption_words())} undertekster, {len(sfx_cues())} lydeffekter, {DUR} s, panel {SPLIT_CAM}")


def render(version=None):
    """Render with HyperFrames and normalise the sound to -14 LUFS into 3_Final (next free version, never overwrites)."""
    name = os.path.basename(PROJECT)
    prefix = name.rsplit("_", 1)[0]
    final = os.path.join(PROJECT, "3_Final")
    os.makedirs(final, exist_ok=True)
    used = [int(m.group(1)) for f in os.listdir(final) if (m := re.search(r"_v(\d+)\.mp4$", f))]
    v = version or max(used, default=0) + 1
    raw = os.path.join(PROJECT, "2_Projekt", f"render_v{v}.mp4")
    cmd = [paths.npx(), "hyperframes", "render", FILM, "-q", "delivery", "-o", raw, "--quiet"]
    if shutil.which("nvidia-smi"):
        cmd.append("--gpu")
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode or not os.path.exists(raw):
        sys.exit(f"HyperFrames-render fejlede: {(r.stderr or r.stdout)[-1500:]}")
    out = os.path.join(final, f"{prefix}_v{v}.mp4")
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", raw, "-c:v", "copy", "-af", "loudnorm=I=-14:TP=-1.5:LRA=11", "-ar", "48000",
                    "-c:a", "aac", "-b:a", "256k", "-movflags", "+faststart", out], check=True)
    print(json.dumps({"fil": out.replace("\\", "/"), "version": v}, ensure_ascii=False))
    return out
