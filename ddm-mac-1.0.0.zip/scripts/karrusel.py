"""Renders a karrusel (Instagram carousel, 1080x1350) from <projekt>/2_Projekt/slides.json.

  python _System/scripts/karrusel.py render <projektmappe> [--v=N] [--udkast]

Each slide becomes 3_Final/<KODE>-<nr>_<emne>_<NN>_v<N>.png, or .mp4 for a video slide (H.264/AAC, max 60 s, the
Instagram limit for a video in a carousel). Without --v the next free version is used, so a final is never overwritten.
Also writes 2_Projekt/oversigt_v<N>.jpg, all slides side by side, to look the post through.
--udkast renders to 2_Projekt/udkast/ instead (overwritten each time, oversigt in 2_Projekt/udkast/oversigt.jpg): use it
while the slides are being adjusted, and render the final only when they are right.

The default look (from the course's reference carousels), in the kursist's own brand colours and fonts (_System/brand.css): dark grainy background, everything
centred, a small pill label over an upper-case title with an amber glow, a round photo with a dotted ring, a short note
at the bottom and a signature line (config "karrusel.footer"). Design lives in _System/assets/karrusel/slide.css.

slides.json:  {"footer": "<navn · firma>" (optional, default brand.json "footer"), "slides": [ {...}, ... ]}
Text fields accept *ord* for an amber word and \n for a new line; a blank line (\n\n) in "body" starts a new paragraph.
Image/video paths are relative to the project or to the workspace (e.g. 02_Materialer/...). "focus" is the CSS
object-position of a photo ("50% 30%"). Photos are shown in black and white like the reference; "farve": true keeps colour.
  cover  title (small white top line), accent (big amber line), kicker? (pill under it), image? (full-bleed behind)
  point  label? (pill, e.g. "Trin 1"), title (amber, upper case), body?, image? (round, dotted ring), shape? ("circle"|"card"),
         note?, note_label? (e.g. "Pris:")                                     the workhorse: one point per slide
  image  same fields as point, but the photo is a large rounded card by default
  duo    title (white, *amber* part), sub?, items [{image, label}, {image, label}], joiner? ("+"), result?   two things together
  list   label?, title, items[] (up to 5, numbered 01, 02 ...)
  stat   label?, value (huge amber number), title?, body?
  quote  quote, by?
  cta    word? (brand cta_word, e.g. "Kommentér"), keyword? (brand cta_keyword, shown huge in quotes), body?, image? (small round portrait)
  video  video, start?, duration?, label?, title?, body?, text_pos? ("top"|"bottom"), mute?, focus? (crop centre)
  motion  the moving first slide (rule: slide 1 always moves): title, accent, kicker?, image?, figure ("husfigur" |
          "notifikationer" | "likes" | "telefon" | "objekt"), at [x, y], peek?, ... see karrusel_motion.py. Rendered as a
          5 s looping MP4 with HyperFrames; the JSON output warns if slide 1 is not motion or video.
From the second reference (cinematic photos, story text, card wall, collectible cards, poster), photos in colour unless
"mono": true:
  poster     image, title (huge condensed caps, *amber*), captions? [left, right], handle?, text_pos? ("top"|"middle"|"bottom")
             a bold alternative cover with "Swipe →"
  statement  image, text (one short sentence in the middle of the photo), text_pos?
  story      image, body (1-3 short paragraphs at the top over a spotlight, the photo shows below)
  wall       images[] (repeated as a tilted wall of cards), label?, text                    "here is the team/the tools/..."
  cards      title, sub?, items [{image, label, tag?, corner?}] (2-6 collectible cards: 2, 3, 2+2, 2+3, 3+3)
  letter     body (plain left-aligned paragraphs, no picture), from?                        a personal note or a quiet CTA
  split      image (top half), label?, title, body?                                         left-aligned, editorial
  steps      label?, title, items [{title, body?}] (numbered steps on a dotted line, 3-5)
  compare    label?, title, left {label, items[]}, right {label, items[]}                     before/after, typical/better
  chat       title?, messages [{from: "them"|"me", text}], chat_name?, image? (avatar), body?  a DM or comment thread
  phone      label?, title, body?, image (a screenshot shown in a tilted phone)
  collage    label?, title?, images[] (2-4 photos), body?, farve? (default colour)
("text" is accepted as an old name for point.) Prints JSON with the files made.
"""
import html, json, os, re, shutil, subprocess, sys

import karrusel_motion
import paths

ASSETS = os.path.join(paths.ASSETS, "karrusel")
BRAND = {}
W, H = 1080, 1350

FIT_JS = """<script>
document.fonts.ready.then(() => {
  for (const box of document.querySelectorAll('.fit')) {
    const els = box.querySelectorAll('h1,h2,p,.quote,.item span,.stat-value,.top-line,.big,.cta-word,.note,.duo .lbl,' +
      '.poster-title,.statement,.step b,.step span,.side .row,.bubble,.tcard .cap');
    // height of the content itself (scrollHeight misreads boxes whose content sits at the bottom)
    const span = () => box.lastElementChild.getBoundingClientRect().bottom - box.firstElementChild.getBoundingClientRect().top;
    // a single long word (MÆGLERPROFIL in 250 px) is too wide even when the height fits: shrink just that element
    for (const e of box.querySelectorAll('.poster-title,.big,.cta-word,.stat-value,h2'))
      for (let i = 0; i < 40 && e.scrollWidth > box.clientWidth + 1; i++)
        e.style.fontSize = (parseFloat(getComputedStyle(e).fontSize) * 0.95) + 'px';
    for (let i = 0; i < 40 && span() > box.clientHeight; i++)
      els.forEach(e => e.style.fontSize = (parseFloat(getComputedStyle(e).fontSize) * 0.95) + 'px');
  }
  document.body.dataset.ready = '1';
});
</script>"""


def rich(s):
    """Escape, *ord* -> amber, line breaks kept."""
    s = html.escape(s or "")
    s = re.sub(r"\*(.+?)\*", r"<em>\1</em>", s)
    return s.replace("\n", "<br>")


def paras(s, cls="lead"):
    return "".join(f'<p class="{cls}">{rich(x.strip())}</p>' for x in re.split(r"\n\s*\n", s or "") if x.strip())


def resolve(project, p):
    for base in (project, paths.ROOT):
        full = os.path.join(base, p)
        if os.path.exists(full):
            return os.path.abspath(full)
    sys.exit(f"Fandt ikke filen {p} (hverken i projektet eller i {paths.ROOT})")


def url(path):
    return "file:///" + path.replace("\\", "/")


def photo(project, s, focus=None):
    f = focus or s.get("focus", "50% 50%")
    return f'<img src="{url(resolve(project, s["image"]))}" style="object-position:{f}">'


def visual(project, s, shape):
    if not s.get("image"):
        return ""
    mono = "" if s.get("farve") else " mono"
    if shape == "card":
        return f'<div class="card{mono}">{photo(project, s)}</div>'
    return f'<div class="circle{mono}"><div class="in">{photo(project, s)}</div></div>'


def pill(text, soft=False):
    return f'<div class="pill{" soft" if soft else ""}">{html.escape(text)}</div>' if text else ""


def brand_link():
    css = os.path.join(paths.ROOT or "", "_System", "brand.css")
    return f'<link rel="stylesheet" href="{url(css)}">' if paths.ROOT and os.path.exists(css) else ""


def frame(inner, footer, overlay=False):
    sign = "" if overlay else f'<div class="sign">{html.escape(footer)}</div>'
    return f"""<!doctype html><html><head><meta charset="utf-8"><link rel="stylesheet" href="{url(os.path.join(ASSETS, 'slide.css'))}">{brand_link()}</head>
<body class="{'overlay' if overlay else ''}"><div class="slide">{inner}{sign}</div>{FIT_JS}</body></html>"""


def col(content, top=120, bottom=150, justify="center"):
    return f'<div class="col fit" style="top:{top}px;bottom:{bottom}px;justify-content:{justify}">{content}</div>'


def group(content, gap=24):
    return f'<div style="display:flex;flex-direction:column;align-items:center;gap:{gap}px">{content}</div>'


def slide_html(project, s, footer):
    t = s.get("type", "point")
    if t == "text":
        t = "point"
    title = rich(s.get("title"))
    if t == "cover":
        bg = ""
        if s.get("image"):
            mono = "" if s.get("farve") else " mono"
            bg = f'<div class="photo-full{mono}">{photo(project, s)}</div><div class="shade"></div>'
        top = f'<div class="top-line">{title}</div>' if s.get("title") else ""
        big = f'<div class="big">{rich(s.get("accent"))}</div>' if s.get("accent") else ""
        content = group(top + big, gap=6) + pill(s.get("kicker"), soft=True)
        inner = bg + col(content, top=100, bottom=640 if s.get("image") else 300, justify="flex-start" if s.get("image") else "center")
    elif t in ("point", "image"):
        shape = s.get("shape", "card" if t == "image" else "circle")
        head = group(pill(s.get("label")) + f"<h2>{title}</h2>" + paras(s.get("body")))
        vis = visual(project, s, shape)
        note = ""
        if s.get("note"):
            lab = f'<b>{html.escape(s["note_label"])}</b> ' if s.get("note_label") else ""
            note = f'<div class="note">{lab}{rich(s["note"])}</div>'
        inner = col(head + vis + note, justify="space-between" if (vis and note) else ("space-around" if vis else "center"))
    elif t == "duo":
        cells = []
        for it in s.get("items", [])[:2]:
            mono = "" if it.get("farve") or s.get("farve") else " mono"
            pic = f'<div class="circle small{mono}"><div class="in">{photo(project, it, focus=it.get("focus"))}</div></div>' if it.get("image") else ""
            cells.append(f'<div class="cell">{pic}<div class="lbl">{rich(it.get("label"))}</div></div>')
        join = f'<div class="join">{html.escape(s.get("joiner", "+"))}</div>'
        duo = f'<div class="duo">{join.join(cells)}</div>'
        res = f'<div class="stem"></div><div class="note">{rich(s["result"])}</div>' if s.get("result") else ""
        sub = f'<p class="sub">{rich(s["sub"])}</p>' if s.get("sub") else ""
        inner = col(group(f'<h2 class="mixed">{title}</h2>{sub}', gap=18) + duo + res)
    elif t == "list":
        items = "".join(f'<div class="item"><div class="n">{k:02d}</div><span>{rich(x)}</span></div>' for k, x in enumerate(s.get("items", []), 1))
        inner = col(f'{pill(s.get("label"))}<h2 class="mixed">{title}</h2><div class="items">{items}</div>')
    elif t == "stat":
        h = f'<h2 class="mixed">{title}</h2>' if s.get("title") else ""
        inner = col(f'{pill(s.get("label"))}<div class="stat-value">{rich(s.get("value"))}</div>{h}{paras(s.get("body"))}')
    elif t == "quote":
        by = f'<div class="by">{html.escape(s["by"])}</div>' if s.get("by") else ""
        inner = col(f'<div class="quote-mark">“</div><div class="quote">{rich(s.get("quote"))}</div>{by}')
    elif t == "cta":
        av = f'<div class="circle small"><div class="in">{photo(project, s)}</div></div>' if s.get("image") else ""
        word = html.escape(s.get("word", BRAND.get("cta_word", "Kommentér")))
        key = html.escape(s.get("keyword", BRAND.get("cta_keyword", "INFO")))
        inner = col(f'{av}<div class="top-line" style="text-transform:none">{word}</div><div class="cta-word">“{key}”</div>{paras(s.get("body"))}')
    elif t == "video":
        pos = s.get("text_pos", "top")
        h = f"<h2>{title}</h2>" if s.get("title") else ""
        content = group(pill(s.get("label")) + h + paras(s.get("body")), gap=20)
        place = col(content, top=110, bottom=700, justify="flex-start") if pos == "top" else col(content, top=760, bottom=110, justify="flex-end")
        inner = f'<div class="vshade{" bottom-text" if pos != "top" else ""}"></div>{place}'
        return frame(inner, footer, overlay=True)
    elif t == "poster":
        caps = "".join(f"<span>{html.escape(c)}</span>" for c in s.get("captions", []))
        caps = f'<div class="caps">{caps}</div>' if caps else ""
        top, bottom, just = {"top": (130, 560, "flex-start"), "bottom": (560, 170, "flex-end")}.get(s.get("text_pos"), (300, 300, "center"))
        handle = s.get("handle", BRAND.get("handle"))
        handle = f'<div class="handle">{html.escape(handle)}</div>' if handle else ""
        inner = (bgphoto(project, s) + '<div class="dim poster"></div>' + handle
                 + col(f'<div class="poster-title">{title}</div>{caps}', top, bottom, just) + '<div class="swipe-tag">Swipe <b>→</b></div>')
    elif t == "statement":
        top, bottom, just = {"top": (140, 700, "flex-start"), "bottom": (700, 170, "flex-end")}.get(s.get("text_pos"), (300, 300, "center"))
        inner = bgphoto(project, s) + '<div class="dim"></div>' + col(f'<div class="statement">{rich(s.get("text") or s.get("title"))}</div>', top, bottom, just)
    elif t == "story":
        inner = (bgphoto(project, s) + '<div class="dim top"></div><div class="spot"></div>'
                 + col(f'<div class="story">{paras(s.get("body"), "")}</div>', top=150, bottom=s.get("text_bottom", 640), justify="flex-start"))
    elif t == "wall":
        pics = [p for p in s.get("images", [])] or ([s["image"]] if s.get("image") else [])
        if not pics:
            sys.exit("En wall-slide skal have images")
        tiles = "".join(f'<div class="tile"><img src="{url(resolve(project, pics[k % len(pics)]))}"></div>' for k in range(30))
        text = f'<div class="statement">{rich(s.get("text") or s.get("title"))}</div>'
        inner = f'<div class="wall">{tiles}</div><div class="wall-dim"></div>' + col(pill(s.get("label")) + text)
    elif t == "cards":
        items = s.get("items", [])[:6]
        rows = {1: [1], 2: [2], 3: [3], 4: [2, 2], 5: [2, 3], 6: [3, 3]}.get(len(items), [len(items)])
        cards, k = [], 0
        for r in rows:
            row = ""
            for it in items[k:k + r]:
                strip = f'<div class="strip"><span>{html.escape(it.get("tag", ""))}</span><span>{html.escape(it.get("corner", "★"))}</span></div>'
                pic = f'<div class="pic">{photo(project, it, focus=it.get("focus"))}</div>' if it.get("image") else '<div class="pic"></div>'
                row += f'<div class="tcard"><div class="frame">{strip}{pic}</div><div class="cap">{rich(it.get("label"))}</div></div>'
            cards.append(f'<div class="row">{row}</div>')
            k += r
        sub = f'<p class="sub" style="color:var(--muted)">{rich(s["sub"])}</p>' if s.get("sub") else ""
        deck = f'<div class="deck{" big" if len(items) <= 3 else ""}">{"".join(cards)}</div>'
        inner = col(group(f'<h2 class="mixed">{title}</h2>{sub}', gap=16) + deck, justify="space-around")
    elif t == "letter":
        frm = f'<div class="from">{html.escape(s["from"])}</div>' if s.get("from") else ""
        inner = f'<div class="letter fit">{paras(s.get("body"), "")}{frm}</div>'
    elif t == "split":
        mono = " mono" if s.get("mono") else ""
        pic = f'<div class="split-photo{mono}">{photo(project, s)}</div>' if s.get("image") else ""
        inner = pic + f'<div class="left fit" style="top:720px;bottom:150px">{pill(s.get("label"))}<h2>{title}</h2>{paras(s.get("body"))}</div>'
    elif t == "steps":
        steps = "".join(f'<div class="step"><div class="rail"><div class="dot">{k:02d}</div></div><div class="txt"><b>{rich(it.get("title"))}</b>'
                        f'{"<span>" + rich(it["body"]) + "</span>" if it.get("body") else ""}</div></div>'
                        for k, it in enumerate(s.get("items", []), 1))
        inner = col(f'{pill(s.get("label"))}<h2 class="mixed">{title}</h2><div class="steps">{steps}</div>')
    elif t == "compare":
        def side(d, cls, mark):
            rows = "".join(f'<div class="row"><div class="mark">{mark}</div><span>{rich(x)}</span></div>' for x in d.get("items", []))
            return f'<div class="side {cls}"><div class="head">{html.escape(d.get("label", ""))}</div>{rows}</div>'
        cmp_ = side(s.get("left", {}), "bad", "✕") + side(s.get("right", {}), "good", "✓")
        inner = col(f'{pill(s.get("label"))}<h2 class="mixed">{title}</h2><div class="compare">{cmp_}</div>')
    elif t == "chat":
        av = f'<div class="av">{photo(project, s, focus=s.get("focus"))}</div>' if s.get("image") else '<div class="av"></div>'
        msgs = "".join(f'<div class="bubble {"me" if m.get("from") == "me" else "them"}">{rich(m.get("text"))}</div>' for m in s.get("messages", []))
        head = f'<h2 class="mixed">{title}</h2>' if s.get("title") else ""
        inner = col(f'{head}<div class="chat"><div class="bar">{av}{html.escape(s.get("chat_name", "Instagram · Besked"))}</div>{msgs}</div>{paras(s.get("body"))}')
    elif t == "phone":
        head = group(pill(s.get("label")) + f'<h2 class="mixed">{title}</h2>' + paras(s.get("body"), "sub"), gap=18)
        ph = f'<div class="phone">{photo(project, s)}</div>' if s.get("image") else '<div class="phone"></div>'
        inner = col(head, top=100, bottom=920, justify="flex-start") + f'<div style="position:absolute;left:0;right:0;top:470px;display:flex;justify-content:center">{ph}</div>'
        return frame(inner, "")
    elif t == "collage":
        pics = s.get("images", [])[:4]
        if len(pics) < 2:
            sys.exit("En collage-slide skal have 2 til 4 images")
        hs = {2: ["620px", "620px"], 3: ["420px", "380px", "380px"], 4: ["400px"] * 4}[len(pics)]
        cells = "".join(f'<div class="ph{" wide" if len(pics) == 3 and k == 0 else ""}{"" if s.get("farve", True) else " mono"}" style="height:{hs[k]}">'
                        f'<img src="{url(resolve(project, p))}"></div>' for k, p in enumerate(pics))
        head = f'<h2 class="mixed">{title}</h2>' if s.get("title") else ""
        inner = col(f'{pill(s.get("label"))}{head}<div class="collage" style="grid-template-columns:1fr 1fr">{cells}</div>{paras(s.get("body"), "sub")}')
    else:
        sys.exit(f"Ukendt slide-type '{t}'")
    return frame(inner, footer)


def bgphoto(project, s):
    """Full-bleed photo behind the text; in colour unless "mono": true."""
    if not s.get("image"):
        return ""
    return f'<div class="bg-photo{" mono" if s.get("mono") else ""}">{photo(project, s)}</div>'


def shot(html_path, png, transparent=False):
    args = [paths.chrome() or sys.exit("Chrome eller Edge mangler: installér Google Chrome."), "--headless=new", "--disable-gpu", "--hide-scrollbars", "--force-device-scale-factor=1",
            f"--window-size={W},{H}", "--virtual-time-budget=6000", "--allow-file-access-from-files", f"--screenshot={png}"]
    if transparent:
        args.append("--default-background-color=00000000")
    subprocess.run(args + [url(html_path)], capture_output=True, text=True, timeout=120)
    if not os.path.exists(png):
        sys.exit(f"Chrome lavede ikke {png}")


def ff(*args):
    r = subprocess.run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", *args], capture_output=True, text=True)
    if r.returncode:
        sys.exit(f"ffmpeg fejlede: {r.stderr[-800:]}")


def video_slide(project, s, overlay_png, out):
    src = resolve(project, s["video"])
    fx, fy = (float(v.strip("%")) / 100 for v in s.get("focus", "50% 50%").split())
    dur = min(float(s.get("duration", 60)), 60)
    vf = (f"[0:v]scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H}:(iw-{W})*{fx}:(ih-{H})*{fy},"
          f"fps=30,setsar=1[v];[v][1:v]overlay=0:0,format=yuv420p[out]")
    audio = [] if s.get("mute") else ["-map", "0:a?", "-c:a", "aac", "-b:a", "192k", "-ar", "48000"]
    ff("-ss", str(s.get("start", 0)), "-t", str(dur), "-i", src, "-i", overlay_png, "-filter_complex", vf, "-map", "[out]",
       *audio, "-c:v", "libx264", "-crf", "18", "-preset", "medium", "-profile:v", "high", "-movflags", "+faststart", out)


def render(project_dir, version=None, draft=False):
    project = os.path.abspath(project_dir)
    paths.load(project)
    BRAND.clear(); BRAND.update(paths.brand())
    name = os.path.basename(project)
    prefix = name.rsplit("_", 1)[0]
    spec = json.load(open(os.path.join(project, "2_Projekt", "slides.json"), encoding="utf-8"))
    slides = spec["slides"]
    if not 2 <= len(slides) <= 20:
        sys.exit(f"En karrusel skal have 2 til 20 slides, slides.json har {len(slides)}")
    final = os.path.join(project, "3_Final")
    os.makedirs(final, exist_ok=True)
    used = [int(m.group(1)) for f in os.listdir(final) if (m := re.search(r"_v(\d+)\.\w+$", f))]
    v = version or max(used, default=0) + 1
    if version and version in used:
        sys.exit(f"v{version} findes allerede i 3_Final. Finals overskrives aldrig; brug næste version.")
    if draft:
        final = os.path.join(project, "2_Projekt", "udkast")
        shutil.rmtree(final, ignore_errors=True)
        os.makedirs(final)
    work = os.path.join(project, "2_Projekt", "udkast_render" if draft else f"render_v{v}")
    shutil.rmtree(work, ignore_errors=True)
    os.makedirs(work)
    footer = spec.get("footer", BRAND.get("footer", ""))
    made, thumbs = [], []
    warnings = []
    if slides[0].get("type") not in ("motion", "video"):
        warnings.append("Første slide bevæger sig ikke. Reglen er: slide 1 er altid motion (eller video).")
    for i, s in enumerate(slides, 1):
        if s.get("type") == "motion":
            out = os.path.join(final, f"{prefix}_{i:02d}_v{v}.mp4")
            karrusel_motion.build(project, s, resolve, ASSETS, footer, os.path.join(work, f"motion_{i:02d}"), out)
            thumb = os.path.join(work, f"t_{i:02d}.png")
            ff("-i", out, "-frames:v", "1", thumb)
            made.append(os.path.basename(out))
            thumbs.append(thumb)
            continue
        page = os.path.join(work, f"{i:02d}.html")
        open(page, "w", encoding="utf-8").write(slide_html(project, s, footer))
        if s.get("type") == "video":
            ov = os.path.join(work, f"{i:02d}_overlay.png")
            shot(page, ov, transparent=True)
            out = os.path.join(final, f"{prefix}_{i:02d}_v{v}.mp4")
            video_slide(project, s, ov, out)
            thumb = os.path.join(work, f"t_{i:02d}.png")
            ff("-ss", "1", "-i", out, "-frames:v", "1", thumb)
        else:
            out = os.path.join(final, f"{prefix}_{i:02d}_v{v}.png")
            shot(page, out)
            thumb = out
        made.append(os.path.basename(out))
        thumbs.append(thumb)
    for j, t in enumerate(thumbs, 1):
        ff("-i", t, "-vf", "scale=360:450", os.path.join(work, f"s_{j:02d}.png"))
    cols = min(len(thumbs), 5)
    rows = -(-len(thumbs) // cols)
    sheet = os.path.join(final, "oversigt.jpg") if draft else os.path.join(project, "2_Projekt", f"oversigt_v{v}.jpg")
    ff("-framerate", "1", "-i", os.path.join(work, "s_%02d.png"), "-vf",
       f"tile={cols}x{rows}:padding=16:margin=16:color=0x252E3F", "-frames:v", "1", "-q:v", "3", sheet)
    print(json.dumps({"project": name, "version": v, "udkast": draft, "folder": final.replace("\\", "/"), "files": made, "oversigt": sheet.replace("\\", "/"), "advarsler": warnings}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    if len(sys.argv) >= 3 and sys.argv[1] == "render":
        ver = next((int(a.split("=", 1)[1]) for a in sys.argv[3:] if a.startswith("--v=")), None)
        render(sys.argv[2], ver, draft="--udkast" in sys.argv)
    else:
        sys.exit(__doc__)
