"""Downloads Instagram posts (reels, videos, carousels) from links, for the style reference.

  python ig_hent.py <link> [<link> ...] [--ud <mappe>] [--login]      (default: 02_Materialer/Stil-reference)

Each post lands in its own folder (named by the post's code). Reels and videos go through yt-dlp, image posts and
carousels through gallery-dl. Instagram often wants a login, so each link is tried in this order, and the first that
works is used:
  1. without login (works for many public reels)
  2. only with --login (the kursist said yes to it): the login in their own browser (Firefox, Chrome, Edge, Brave, Safari); logged in to
     instagram.com; on Mac, Safari needs Full Disk Access for the terminal/Claude, so Chrome/Firefox are easier
  3. a cookie file 02_Materialer/Stil-reference/instagram_cookies.txt (export it with the browser extension
     "Get cookies.txt LOCALLY" while logged in to instagram.com)
Prints JSON per link: the files, which way worked, or exactly what the kursist should do when nothing worked.
"""
import glob, json, os, re, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import paths  # noqa: E402

BROWSERS = ["firefox", "chrome", "edge", "brave", "safari"] if paths.IS_MAC else ["firefox", "chrome", "edge", "brave"]
MEDIA = (".mp4", ".mov", ".webm", ".jpg", ".jpeg", ".png", ".webp")


def code_of(url):
    m = re.search(r"instagram\.com/(?:[^/]+/)?(?:p|reel|reels|tv)/([A-Za-z0-9_-]+)", url)
    return m.group(1) if m else re.sub(r"\W+", "_", url)[-20:]


def files_in(d):
    return sorted(f for f in glob.glob(os.path.join(d, "**", "*"), recursive=True) if f.lower().endswith(MEDIA))


def try_ytdlp(url, d, auth):
    cmd = [sys.executable, "-m", "yt_dlp", "-q", "--no-warnings", "-o", os.path.join(d, "%(id)s_%(autonumber)02d.%(ext)s"),
           "--write-info-json", "--no-playlist" if "/reel" in url else "--yes-playlist", *auth, url]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    return bool(files_in(d)), (r.stderr or r.stdout)[-300:]


def try_gallery(url, d, auth):
    cmd = [sys.executable, "-m", "gallery_dl", "-q", "-D", d, *auth, url]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    return bool(files_in(d)), (r.stderr or r.stdout)[-300:]


def main():
    args, out, login = [], None, False
    it = iter(sys.argv[1:])
    for a in it:
        if a == "--ud":
            out = next(it)
        elif a == "--login":
            login = True
        else:
            args.append(a)
    if not args:
        sys.exit(__doc__)
    try:
        paths.load()
        base = out or os.path.join(paths.ROOT, "02_Materialer", "Stil-reference")
    except SystemExit:
        base = out or "Stil-reference"
    cookies = os.path.join(base, "instagram_cookies.txt")
    results = []
    for url in args:
        d = os.path.join(base, code_of(url))
        os.makedirs(d, exist_ok=True)
        ways = [("uden login", [])] + ([(f"login fra {b}", ["--cookies-from-browser", b]) for b in BROWSERS] if login else [])
        if os.path.exists(cookies):
            ways.append(("cookie-fil", ["--cookies", cookies]))
        ok, how, last = False, None, ""
        is_post = "/p/" in url
        for name, auth in ways:
            tools = [try_gallery, try_ytdlp] if is_post else [try_ytdlp, try_gallery]
            for tool in tools:
                g_auth = auth
                if tool is try_gallery and auth and auth[0] == "--cookies-from-browser":
                    g_auth = ["--cookies-from-browser", auth[1]]
                try:
                    ok, last = tool(url, d, g_auth)
                except Exception as e:
                    ok, last = False, str(e)
                if ok:
                    how = name
                    break
            if ok:
                break
        res = {"link": url, "mappe": d.replace("\\", "/"), "ok": ok, "metode": how,
               "filer": [os.path.relpath(f, d).replace("\\", "/") for f in files_in(d)]}
        if not ok:
            res["hvad_du_goer"] = ("Instagram kræver login. 0) Er det en billedkarrusel: brug den indbyggede browser (se skill stil). 1) Log ind på instagram.com i Chrome eller Firefox på denne computer og prøv igen med --login (kun hvis kursisten siger ja). "
                                   "2) Virker det stadig ikke: installér browser-udvidelsen 'Get cookies.txt LOCALLY', åbn instagram.com (logget ind), "
                                   f"eksportér cookies og gem filen som {cookies}. 3) Nødløsning: gem selv opslaget (skærmoptagelse eller skærmbilleder) i {d}.")
            res["sidste_fejl"] = last
        results.append(res)
    print(json.dumps(results, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
