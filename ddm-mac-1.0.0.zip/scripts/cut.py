"""Cuts retakes and long pauses out of a talking-head recording and makes it 9:16 (1080x1920).

  python cut.py <mappe>      (mappe holds cfg.json and raw.json from transcribe.py)

cfg.json: {"src": "<råvideo>", "drop": [[a, b], ...], "crop_x": null | 0..1, "grade": null | "<ffmpeg-filter>"}
  drop   = bad takes in raw seconds (rule: the second attempt is the right one; with 3+ attempts keep the last complete
           one). A drop may cut inside a speech run; that edge is moved to the quietest 10 ms within +-0.15 s.
  crop_x = only for wide (landscape) recordings: where the 9:16 window sits, 0 = left, 0.5 = middle, 1 = right.
  grade  = optional colour filter; default a light, neutral lift.
Every kept piece starts 0.15 s before its first sound and ends 0.2 s after its last; the last piece keeps 0.5 s of tail.
Writes keep.json, talk.mp4 (cut, 9:16, graded, with sound), voice.m4a and cut.wav (16 kHz mono, for the second
transcription that gives the word times on screen).
"""
import json, os, shutil, subprocess, sys, wave

import numpy as np

D = sys.argv[1] if len(sys.argv) > 1 else sys.exit(__doc__)
cfg = json.load(open(os.path.join(D, "cfg.json"), encoding="utf-8"))
raw = json.load(open(os.path.join(D, "raw.json"), encoding="utf-8"))
# the raw file may be given absolute, relative to the workspace (where Claude runs), to this folder or to the project
cands = [cfg["src"], os.path.join(D, cfg["src"]), os.path.join(D, "..", "..", cfg["src"])]
src = next((os.path.abspath(c) for c in cands if os.path.exists(c)), None) or sys.exit(f"Fandt ikke råfilen {cfg['src']}")
wav = os.path.join(D, "raw.wav")
if not os.path.exists(wav):
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", src, "-vn", "-ac", "1", "-ar", "16000", wav], check=True)
w = wave.open(wav)
pcm = np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(np.float32) / 32768
db = 20 * np.log10(np.array([np.sqrt(np.mean(pcm[i:i + 160] ** 2) + 1e-12) for i in range(0, len(pcm) - 160, 160)]))
PAD_IN, PAD_OUT, TAIL = 0.15, 0.2, 0.5


def quietest(t, r=0.15):
    i0, i1 = max(0, int((t - r) * 100)), min(len(db), int((t + r) * 100))
    return (i0 + int(np.argmin(db[i0:i1]))) / 100


pieces = []
for a, b in raw["speech"]:
    segs = [(a, b, False, False)]
    for da, db_ in cfg.get("drop", []):
        nxt = []
        for s, e, hs, he in segs:
            if db_ <= s or da >= e:
                nxt.append((s, e, hs, he)); continue
            if da > s:
                nxt.append((s, quietest(da), hs, True))
            if db_ < e:
                nxt.append((quietest(db_), e, True, he))
        segs = nxt
    pieces += [p for p in segs if p[1] - p[0] > 0.12]
keep = []
for s, e, hs, he in pieces:
    s = s if hs else s - PAD_IN
    e = e if he else e + PAD_OUT
    if keep and s <= keep[-1][1]:
        keep[-1][1] = max(keep[-1][1], e)
    else:
        keep.append([max(0.0, s), e])
keep[-1][1] = min(len(pcm) / 16000, keep[-1][1] + TAIL)
total = sum(b - a for a, b in keep)
json.dump({"keep": keep, "duration": round(total, 3)}, open(os.path.join(D, "keep.json"), "w", encoding="utf-8"), indent=1)
print(f"{len(keep)} stykker, {total:.2f} s (af {len(pcm) / 16000:.1f})")

r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height:stream_side_data=rotation",
                    "-of", "json", src], capture_output=True, text=True)
st = json.loads(r.stdout)["streams"][0]
W, H = st["width"], st["height"]
rot = next((abs(int(x.get("rotation", 0))) for x in st.get("side_data_list", []) or []), 0)
if rot in (90, 270):
    W, H = H, W
if W / H > 9 / 16 + 0.01:      # wide: cut a 9:16 window
    cw = int(H * 9 / 16) // 2 * 2
    cx = cfg.get("crop_x")
    x = int((W - cw) * (0.5 if cx is None else float(cx)))
    geo = f"crop={cw}:{H}:{x}:0,scale=1080:1920:flags=lanczos,"
else:                           # portrait (phone): fill 1080x1920
    geo = "scale=1080:1920:force_original_aspect_ratio=increase:flags=lanczos,crop=1080:1920,"
GRADE = cfg.get("grade") or "eq=contrast=1.04:saturation=1.05:gamma=1.01"
parts = []
for i, (a, b) in enumerate(keep):
    d = b - a
    parts.append(f"[0:v]trim={a:.3f}:{b:.3f},setpts=PTS-STARTPTS[v{i}];"
                 f"[0:a]atrim={a:.3f}:{b:.3f},asetpts=PTS-STARTPTS,afade=t=in:d=0.012,afade=t=out:st={max(0, d - 0.015):.3f}:d=0.015[a{i}];")
n = len(keep)
fc = "".join(parts) + "".join(f"[v{i}][a{i}]" for i in range(n)) + f"concat=n={n}:v=1:a=1[cv][ca];[cv]{geo}{GRADE},fps=30,format=yuv420p[vo]"
enc = ["-c:v", "libx264", "-crf", "16", "-preset", "fast"]
if shutil.which("nvidia-smi"):
    probe = subprocess.run(["ffmpeg", "-hide_banner", "-encoders"], capture_output=True, text=True).stdout
    if "h264_nvenc" in probe:
        enc = ["-c:v", "h264_nvenc", "-preset", "p6", "-rc", "vbr", "-cq", "16", "-b:v", "0"]
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", src, "-filter_complex", fc, "-map", "[vo]", "-map", "[ca]", *enc, "-g", "30",
                "-c:a", "aac", "-b:a", "256k", os.path.join(D, "talk.mp4")], check=True)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", os.path.join(D, "talk.mp4"), "-vn", "-c:a", "copy", os.path.join(D, "voice.m4a")], check=True)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", os.path.join(D, "talk.mp4"), "-vn", "-ac", "1", "-ar", "16000", os.path.join(D, "cut.wav")], check=True)
print("talk.mp4, voice.m4a og cut.wav er lavet")
