"""Detaljevideo: finds the usable shots in uncut raw footage and cuts a cinematic 9:16 video to music.

Run with the workspace's Python (_System/.venv, it has OpenCV).

  detalje.py scan   <projekt>              measure every clip in 1_Raw, write 2_Projekt/scan.json and contact sheets
  detalje.py beats  <musikfil>             tempo and beat times of a music track (JSON)
  detalje.py musik  [mappe]                list the tracks in 02_Materialer/Musik with tempo and length (JSON)
  detalje.py render <projekt> [--udkast]   cut 2_Projekt/edit.json to 3_Final/<KODE>-<nr>_<emne>_v<N>.mp4 (next free version,
                                          never overwrites) or 2_Projekt/udkast/udkast.mp4

scan: each clip is decoded small (320 px wide, 10 fps) and measured per frame: sharpness (Laplacian variance), brightness,
clipped highlights/shadows and camera motion between frames (phase correlation). Shake = how much the motion jumps
around its own smoothed path. The first 0.8 s and last 0.6 s of a clip are skipped (pressing record, the drone turning).
2.5 s windows are scored (sharpness, steadiness, exposure, a calm camera move), and the best non-overlapping windows of
each clip become candidates. 2_Projekt/scan/<clip>.jpg shows each candidate's middle frame with its score, and
2_Projekt/scan/oversigt.jpg the best candidate of every clip, so the shots can be looked through before choosing.

edit.json:
  {"music": "02_Materialer/Musik/<nummer>.mp3" (or null for no music), "music_start": 0, "grade": "cinematic" | "neutral" | "<fil.cube>",
   "shots": [{"file": "1_Raw/x.mp4", "start": 12.4, "dur": 1.6, "speed": 0.6, "crop_x": 0.5}, ...]}
  dur is the shot's length in the finished video; speed < 1 is slow motion (the clip plays dur*speed seconds of source;
  50 fps footage at 0.6 stays fluid at 30 fps). crop_x picks where the 9:16 frame sits in a wide shot (0 left, 1 right).
  Hard cuts, no text, no logo. Music fades out at the end, loudness -14 LUFS, 1080x1920, 30 fps, H.264/AAC.
"""
import json, os, re, shutil, subprocess, sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import paths  # noqa: E402

VIDEO = (".mp4", ".mov", ".m4v", ".mxf")
SW, SH, SFPS = 320, 180, 10
HEAD, TAIL, WIN = 0.8, 0.6, 2.5
W, H, FPS = 1080, 1920, 30
GRADES = {
    "cinematic": "eq=contrast=1.07:saturation=1.06:gamma=0.97,colorbalance=rs=-0.02:bs=0.03:rh=0.03:bh=-0.02,vignette=PI/5",
    "neutral": "eq=contrast=1.03:saturation=1.02",
}


def probe(path):
    r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
                        "stream=width,height,r_frame_rate:stream_side_data=rotation:format=duration", "-of", "json", path],
                       capture_output=True, text=True)
    d = json.loads(r.stdout or "{}")
    st = (d.get("streams") or [{}])[0]
    num, den = (st.get("r_frame_rate") or "0/1").split("/")
    rot = 0
    for sd in st.get("side_data_list", []) or []:
        rot = int(sd.get("rotation", 0) or 0)
    w, h = st.get("width", 0), st.get("height", 0)
    if abs(rot) in (90, 270):
        w, h = h, w
    return {"width": w, "height": h, "fps": round(float(num) / float(den or 1), 2), "duration": float(d.get("format", {}).get("duration", 0))}


def frames(path):
    """Grey 320x180 frames at 10 fps as a numpy array (n, 180, 320)."""
    cmd = ["ffmpeg", "-v", "error", "-hwaccel", "auto", "-i", path, "-vf", f"fps={SFPS},scale={SW}:{SH}", "-f", "rawvideo",
           "-pix_fmt", "gray", "-"]
    raw = subprocess.run(cmd, capture_output=True).stdout
    n = len(raw) // (SW * SH)
    return np.frombuffer(raw[:n * SW * SH], np.uint8).reshape(n, SH, SW)


def measure(fr):
    import cv2
    win = cv2.createHanningWindow((SW, SH), cv2.CV_32F)
    sharp, bright, clip, motion = [], [], [], [0.0 + 0j]
    prev = None
    for f in fr:
        sharp.append(cv2.Laplacian(f, cv2.CV_64F).var())
        bright.append(float(f.mean()))
        clip.append(float(((f > 250) | (f < 5)).mean()))
        cur = f.astype(np.float32)
        if prev is not None:
            (dx, dy), _ = cv2.phaseCorrelate(prev, cur, win)
            motion.append(complex(dx, dy))
        prev = cur
    m = np.array(motion)
    k = 7  # smooth path over 0.7 s; shake = distance from it
    pad = np.pad(m, (k // 2, k // 2), mode="edge")
    smooth = np.convolve(pad, np.ones(k) / k, mode="valid")
    shake = np.abs(m - smooth)
    return np.array(sharp), np.array(bright), np.array(clip), m, shake


def describe(m):
    dx, dy = float(np.mean(m.real)), float(np.mean(m.imag))
    sp = (dx * dx + dy * dy) ** .5
    if sp < .4:
        return "statisk"
    if abs(dx) > abs(dy):
        return "panorering " + ("højre" if dx < 0 else "venstre")  # image moves left = camera turns right
    return "tilt " + ("op" if dy > 0 else "ned")


def scan(project):
    raw = os.path.join(project, "1_Raw")
    outdir = os.path.join(project, "2_Projekt", "scan")
    shutil.rmtree(outdir, ignore_errors=True)
    os.makedirs(outdir)
    clips = []
    for name in sorted(os.listdir(raw)):
        if not name.lower().endswith(VIDEO):
            continue
        path = os.path.join(raw, name)
        info = probe(path)
        fr = frames(path)
        if len(fr) < (HEAD + TAIL + WIN) * SFPS:
            clips.append({"file": f"1_Raw/{name}", **info, "candidates": [], "note": "for kort"})
            continue
        sharp, bright, clip, m, shake = measure(fr)
        ls = np.log1p(sharp)
        clips.append({"file": f"1_Raw/{name}", **info, "_m": (ls, bright, clip, m, shake)})
    # sharpness is judged against the whole project (a soft clip should lose to a crisp one)
    all_ls = np.concatenate([c["_m"][0] for c in clips if "_m" in c]) if any("_m" in c for c in clips) else np.array([1.0])
    lo, hi = np.percentile(all_ls, 10), np.percentile(all_ls, 95)
    for c in clips:
        if "_m" not in c:
            continue
        ls, bright, clip, m, shake = c.pop("_m")
        n, w = len(ls), int(WIN * SFPS)
        cands = []
        for a in range(int(HEAD * SFPS), n - int(TAIL * SFPS) - w + 1, SFPS // 2):
            sl = slice(a, a + w)
            s_sharp = float(np.clip((ls[sl].mean() - lo) / (hi - lo + 1e-6), 0, 1))
            s_steady = float(np.clip(1 - np.percentile(shake[sl], 90) / 2.5, 0, 1))
            b = bright[sl].mean()
            s_expo = float(np.clip(1 - max(0, 45 - b, b - 205) / 40, 0, 1) * np.clip(1 - clip[sl].mean() / .15, 0, 1))
            speed = float(np.abs(m[sl]).mean())
            s_move = float(np.clip(1 - abs(speed - 1.5) / 6, 0, 1))  # a calm, steady move reads as cinematic
            score = .35 * s_sharp + .35 * s_steady + .2 * s_expo + .1 * s_move
            cands.append({"start": round(a / SFPS, 2), "dur": WIN, "score": round(score, 3), "skarp": round(s_sharp, 2),
                          "rolig": round(s_steady, 2), "lys": round(s_expo, 2), "bevaegelse": describe(m[sl]),
                          "fart": round(speed, 2)})
        picked = []
        for cd in sorted(cands, key=lambda x: -x["score"]):
            if cd["score"] < .45 or any(abs(cd["start"] - p["start"]) < WIN for p in picked):
                continue
            picked.append(cd)
            if len(picked) == 3:
                break
        c["candidates"] = sorted(picked, key=lambda x: x["start"])
        c["bedste_score"] = max((p["score"] for p in picked), default=0)
        sheet(project, c, outdir)
    overview(project, clips, outdir)
    out = {"project": os.path.basename(project), "clips": clips,
           "brugbare_klip": sum(1 for c in clips if c.get("candidates")), "klip_i_alt": len(clips)}
    json.dump(out, open(os.path.join(project, "2_Projekt", "scan.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return out


def thumb(path, t, out, label):
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-ss", str(t), "-i", path, "-frames:v", "1", "-vf",
                    f"scale=480:-2,drawbox=x=0:y=0:w=iw:h=34:color=black@0.6:t=fill", out], capture_output=True)
    return out if os.path.exists(out) else None


def tile(paths, cols, out):
    if not paths:
        return
    tmp = os.path.join(os.path.dirname(out), "_t")
    shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(tmp)
    for k, p in enumerate(paths):
        shutil.copy2(p, os.path.join(tmp, f"{k:03d}.jpg"))
    rows = -(-len(paths) // cols)
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-framerate", "1", "-i", os.path.join(tmp, "%03d.jpg"), "-vf",
                    f"scale=300:400:force_original_aspect_ratio=decrease,pad=300:400:(ow-iw)/2:(oh-ih)/2,tile={cols}x{rows}:padding=6:color=0x222222",
                    "-frames:v", "1", "-q:v", "3", out], capture_output=True)
    shutil.rmtree(tmp, ignore_errors=True)


def sheet(project, c, outdir):
    stem = os.path.splitext(os.path.basename(c["file"]))[0]
    ts = []
    for k, cd in enumerate(c["candidates"]):
        p = thumb(os.path.join(project, c["file"]), cd["start"] + cd["dur"] / 2, os.path.join(outdir, f"_{stem}_{k}.jpg"), "")
        if p:
            ts.append(p)
    tile(ts, 3, os.path.join(outdir, f"{stem}.jpg"))
    for p in ts:
        os.remove(p)


def overview(project, clips, outdir):
    ts = []
    for c in sorted([c for c in clips if c.get("candidates")], key=lambda c: c["file"]):
        best = max(c["candidates"], key=lambda x: x["score"])
        stem = os.path.splitext(os.path.basename(c["file"]))[0]
        p = thumb(os.path.join(project, c["file"]), best["start"] + best["dur"] / 2, os.path.join(outdir, f"_o_{stem}.jpg"), stem)
        if p:
            ts.append(p)
    tile(ts, 5, os.path.join(outdir, "oversigt.jpg"))
    for p in ts:
        os.remove(p)


def beats(path):
    """Tempo and beat times: spectral-flux onsets, tempo by autocorrelation, beats by dynamic programming."""
    sr, hop = 22050, 512
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", path, "-ac", "1", "-ar", str(sr), "-f", "f32le", "-"], capture_output=True).stdout
    y = np.frombuffer(raw, np.float32)
    n_fft = 2048
    frames_ = np.lib.stride_tricks.sliding_window_view(np.pad(y, (n_fft // 2, n_fft // 2)), n_fft)[::hop] * np.hanning(n_fft)
    mag = np.log1p(np.abs(np.fft.rfft(frames_, axis=1)))
    flux = np.maximum(0, np.diff(mag, axis=0)).sum(axis=1)
    flux = (flux - flux.mean()) / (flux.std() + 1e-9)
    fps = sr / hop
    ac = np.correlate(flux, flux, "full")[len(flux) - 1:]
    lags = np.arange(len(ac))
    bpm_of = lambda lag: 60 * fps / lag
    valid = (lags > 0) & (bpm_of(np.maximum(lags, 1)) <= 180) & (bpm_of(np.maximum(lags, 1)) >= 60)
    weight = np.exp(-.5 * (np.log2(bpm_of(np.maximum(lags, 1)) / 110)) ** 2)  # favour ~110 bpm when ambiguous
    lag = int(lags[valid][np.argmax((ac * weight)[valid])])
    # dynamic programming beat tracker (Ellis 2007)
    score = flux.copy()
    back = np.zeros(len(flux), int)
    for i in range(len(flux)):
        lo_, hi_ = i - 2 * lag, i - lag // 2
        if hi_ <= 0:
            continue
        cand = np.arange(max(0, lo_), hi_)
        pen = -100 * (np.log((i - cand) / lag)) ** 2
        j = cand[np.argmax(score[cand] + pen)]
        score[i] += score[j] + pen[cand == j][0]
        back[i] = j
    i = int(np.argmax(score[-lag:]) + len(score) - lag)
    bt = []
    while i > 0 and len(bt) < 2000:
        bt.append(i)
        if back[i] == 0 or back[i] >= i:
            break
        i = back[i]
    times = sorted(round(b / fps, 3) for b in bt)
    return {"bpm": round(bpm_of(lag), 1), "beat_s": round(lag / fps, 3), "beats": times,
            "laengde": round(len(y) / sr, 2)}


def render(project, draft=False):
    ed = json.load(open(os.path.join(project, "2_Projekt", "edit.json"), encoding="utf-8"))
    name = os.path.basename(project.rstrip("/\\"))
    prefix = name.rsplit("_", 1)[0]
    final = os.path.join(project, "3_Final")
    os.makedirs(final, exist_ok=True)
    used = [int(m.group(1)) for f in os.listdir(final) if (m := re.search(r"_v(\d+)\.mp4$", f))]
    v = max(used, default=0) + 1
    if draft:
        outdir = os.path.join(project, "2_Projekt", "udkast")
        os.makedirs(outdir, exist_ok=True)
        out = os.path.join(outdir, "udkast.mp4")
    else:
        out = os.path.join(final, f"{prefix}_v{v}.mp4")
    work = os.path.join(project, "2_Projekt", "_render")
    shutil.rmtree(work, ignore_errors=True)
    os.makedirs(work)
    g = ed.get("grade", "cinematic")
    grade = GRADES.get(g) or (f"lut3d='{os.path.join(project, g).replace(chr(92), '/').replace(':', chr(92) + ':')}'" if g.endswith(".cube") else GRADES["cinematic"])
    parts, total, cum_frames = [], 0.0, 0
    for k, sh in enumerate(ed["shots"]):
        src = os.path.join(project, sh["file"])
        info = probe(src)
        sp = float(sh.get("speed", 1))
        # cut points are rounded to whole frames on the running total, so cuts stay on the beat (no drift)
        end_frames = round((total + float(sh["dur"])) * FPS)
        n_frames = end_frames - cum_frames
        dur = n_frames / FPS
        cum_frames = end_frames
        cx = float(sh.get("crop_x", .5))
        if info["width"] / max(info["height"], 1) > 9 / 16:
            crop = f"crop=ih*9/16:ih:(iw-ih*9/16)*{cx}:0"
        else:
            crop = f"crop=iw:iw*16/9:0:(ih-iw*16/9)*{sh.get('crop_y', .5)}"
        vf = f"setpts=PTS/{sp},{crop},scale={W}:{H}:flags=lanczos,fps={FPS},{grade},format=yuv420p"
        part = os.path.join(work, f"{k:03d}.mp4")
        r = subprocess.run(["ffmpeg", "-y", "-v", "error", "-ss", str(sh["start"]), "-t", str(dur * sp + .2), "-i", src,
                            "-vf", vf, "-frames:v", str(n_frames), "-an", "-c:v", "libx264", "-crf", "14", "-preset", "fast", part],
                           capture_output=True, text=True)
        if r.returncode:
            sys.exit(f"Klip {k + 1} ({sh['file']}) kunne ikke laves: {r.stderr[-500:]}")
        parts.append(part)
        total += dur
    lst = os.path.join(work, "list.txt")
    open(lst, "w").write("".join(f"file '{p.replace(chr(92), '/')}'\n" for p in parts))
    silent = os.path.join(work, "video.mp4")
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", silent], check=True)
    paths.load(project)
    music = None
    if ed.get("music"):
        music = next((os.path.join(base, ed["music"]) for base in (project, paths.ROOT) if os.path.exists(os.path.join(base, ed["music"]))), None)
        if not music:
            sys.exit(f"Fandt ikke musikken {ed['music']}")
    fade = min(1.5, total / 6)
    af = f"afade=t=in:d=0.05,afade=t=out:st={total - fade:.3f}:d={fade:.3f},loudnorm=I=-14:TP=-1.5:LRA=11"
    if not music:  # no track: silent audio, the kursist adds sound in Instagram
        music_in = ["-f", "lavfi", "-t", f"{total:.3f}", "-i", "anullsrc=r=48000:cl=stereo"]
        af = "anull"
    else:
        music_in = ["-ss", str(ed.get("music_start", 0)), "-t", f"{total:.3f}", "-i", music]
    r = subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", silent, *music_in, "-map", "0:v", "-map", "1:a", "-af", af, "-c:v", "libx264", "-crf", "17", "-preset", "slow",
                        "-profile:v", "high", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "256k", "-ar", "48000",
                        "-movflags", "+faststart", "-t", f"{total:.3f}", out], capture_output=True, text=True)
    if r.returncode:
        sys.exit(f"Samlingen fejlede: {r.stderr[-600:]}")
    shutil.rmtree(work, ignore_errors=True)
    return {"project": name, "udkast": draft, "fil": out.replace("\\", "/"), "laengde": round(total, 2), "klip": len(parts)}


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    a = sys.argv[1:]
    if len(a) >= 2 and a[0] == "scan":
        o = scan(os.path.abspath(a[1]))
        print(json.dumps({k: o[k] for k in ("project", "brugbare_klip", "klip_i_alt")}, ensure_ascii=False))
    elif len(a) >= 1 and a[0] == "musik":
        paths.load()
        d = a[1] if len(a) > 1 else os.path.join(paths.ROOT, "02_Materialer", "Musik")
        out = []
        for f in sorted(os.listdir(d)) if os.path.isdir(d) else []:
            if f.lower().endswith((".mp3", ".wav", ".m4a", ".aac", ".flac")):
                bt = beats(os.path.join(d, f))
                out.append({"fil": f, "bpm": bt["bpm"], "laengde": bt["laengde"]})
        print(json.dumps({"mappe": d.replace("\\", "/"), "numre": out}, ensure_ascii=False, indent=1))
    elif len(a) >= 2 and a[0] == "beats":
        print(json.dumps(beats(a[1]), ensure_ascii=False))
    elif len(a) >= 2 and a[0] == "render":
        print(json.dumps(render(os.path.abspath(a[1]), draft="--udkast" in a), ensure_ascii=False, indent=1))
    else:
        sys.exit(__doc__)
