---
name: talkinghead-video
description: Laver en færdig Instagram-reel (9:16) af kursistens talking-head-råvideo i 00_Indbakke/Talking-head - fjerner omtag, laver grafik, undertekster og lyd i kursistens brand og stil, og lægger reel + opslagstekst i 03_Final/Talking-head.
argument-hint: "[noter om emne, hook eller længde]"
---

# Talking-head-reel

Noter: **$ARGUMENTS**

Kør trinene uden at spørge undervejs (kursisten skal ikke godkende et storyboard). Arbejd fra arbejdsmappen (den med `_System/ddm.json`). Python `./_System/.venv/bin/python`, scripts `${CLAUDE_PLUGIN_ROOT}/scripts/`. Læs `CLAUDE.md`, `_System/brand.json` og `_System/stil.md` først. Skriv dansk.

**Trinstatus:** `udgivet.json` i projektmappen har `"trin": {"a": "ok", ...}`. Fejler et trin: stop, skriv `"fejlet"` + kort fejltekst i `"fejl"`, og forklar kursisten præcis hvad der gik galt, og hvad de kan gøre. Ved genkørsel springes trin med "ok" over.

## Én fil = én reel
- `./_System/.venv/bin/python "${CLAUDE_PLUGIN_ROOT}/scripts/inbox.py" claim talking-head`. `busy`/`empty`/`waiting`: stop. `ready`: behandl filerne i `files` én ad gangen. Slut altid med `... inbox.py release talking-head`, også ved fejl.

## a) Projekt
Emne: 2–6 ord fra noterne eller filnavnet. `./_System/.venv/bin/python "${CLAUDE_PLUGIN_ROOT}/scripts/new_project.py" talking-head "<emne>" --file="<filnavn>"` → `01_Projekter/Talking-head/TH-<nr>_<emne>_<dato>/`. Gem `id`, `final_prefix`, `path`. Opret `udgivet.json` (`{"projekt", "id", "emne", "noter", "trin": {}}`).

## b) Transskribér og klip
Arbejdsmappe for videoen: `<projekt>/2_Projekt/v1/`.
1. `./_System/.venv/bin/python "${CLAUDE_PLUGIN_ROOT}/scripts/transcribe.py" "<projekt>/1_Raw/<fil>" "<projekt>/2_Projekt/v1/raw.json"`.
2. Find omtag i transskriptionen: siger kursisten det samme igen, er **andet forsøg det rigtige** (også afbrudte sætninger). Skriv `v1/cfg.json`: `{"src": "<projekt>/1_Raw/<fil>", "drop": [[start, slut], ...], "crop_x": null}` (sekunder i råfilen; `crop_x` kun ved vandrette optagelser: 0–1, hvor personen står). Fjern aldrig et tal eller punkt bare fordi det står to gange; tjek tiderne.
3. `./_System/.venv/bin/python "${CLAUDE_PLUGIN_ROOT}/scripts/cut.py" "<projekt>/2_Projekt/v1"` → `talk.mp4` (9:16), `voice.m4a`, `cut.wav`.
4. Skriv `v1/rettelser.json` med ord Whisper hører forkert (fx `{"maler": "mægler"}` og navne/fagord), og kør `transcribe.py "<projekt>/2_Projekt/v1/cut.wav" "<projekt>/2_Projekt/v1/transcript.json" --rettelser "<projekt>/2_Projekt/v1/rettelser.json"`.
5. Læs hele transskriptionen igennem: mangler ord, er der gentagelser, ret dem i transcript.json (ordets tekst) eller ret drop og klip igen.

## c) Grafik og opbygning
Kopiér `${CLAUDE_PLUGIN_ROOT}/scripts/reel_eksempel.py` til `<projekt>/2_Projekt/build_v1.py`, erstat `PLUGIN_ROOT_HER` med plugin-mappen (`${CLAUDE_PLUGIN_ROOT}`), og skriv scenerne om til denne video:
- **Fortælling:** hook (navngiv problemet) → løftet → ét kapitel pr. pointe (`R.chapter`) → opsamling → CTA (`R.cta`, brandets nøgleord). Følg `_System/stil.md` (layout, tempo, hvor ofte der klippes til fuld skærm, overskrifternes stil).
- Én grafikscene pr. pointe, ca. hvert 4.–8. sekund; `R.full(...)` 1–2 sek. ved punch lines. Overskrift: `eb` (lille linje), `h` (overskrift), `amb` (delen i accentfarven), højst ca. 6 ord.
- Ankr alt til ord med `T("ord", efter_sekund)` og giv altid `efter`, så korte ord ikke rammer en tidligere forekomst.
- Vis rigtige ting, når kursisten taler om noget, der kan vises: billeder fra `02_Materialer` (kopiér dem til `2_Projekt/film/assets/` før build, og brug `<div class="phone"><div class="scr"><img src="assets/x.jpg"></div></div>`).
- `R.EMPH`: ca. ét nøgleord pr. scene i accentfarve i underteksterne.
- Musik: vil kursisten have musikbund og ligger der numre i `02_Materialer/Musik`, så `R.build(musik="02_Materialer/Musik/<nummer>")`; ellers `R.build()`.
Kør `./_System/.venv/bin/python "<projekt>/2_Projekt/build_v1.py"`. Gå ind i `<projekt>/2_Projekt/film` og kør `npx hyperframes check --json` til 0 fejl (ret scener, der overlapper eller går uden for billedet).

## d) Render og tjek
`./_System/.venv/bin/python -c "import sys,runpy; sys.path.insert(0, r'${CLAUDE_PLUGIN_ROOT}/scripts'); runpy.run_path(r'<projekt>/2_Projekt/build_v1.py', run_name='lib'); import reel_engine as R; R.render()"` → `3_Final/<final_prefix>_v1.mp4` (næste ledige version; overskriver aldrig).
Tag stillbilleder ved 4–6 tidspunkter (`ffmpeg -ss <t> -i <fil> -frames:v 1 frame.png`) og se dem: ansigtet skal være helt i panelet med lidt luft over håret, ingen tekst må dække ansigtet, ingen tekst i de øverste 250 px og nederste 350 px. Ret og render igen ved fejl (ny version).
`./_System/.venv/bin/python "${CLAUDE_PLUGIN_ROOT}/scripts/check_final.py" "<projekt>/3_Final"`: skal være ok.

## e) Opslagstekst og levering
Brug skill `opslagstekst` ud fra transskriptionen → `<projekt>/opslag.md`. Kør `./_System/.venv/bin/python "${CLAUDE_PLUGIN_ROOT}/scripts/deliver.py" "<projekt>"` → reel + `<ID>_<emne>_opslag.txt` i `03_Final/Talking-head/`.

## f) Svar
Kort: projekt-ID, længde, hvor filen og teksten ligger, og evt. ord du er i tvivl om. Rettelser fra kursisten → ny version (`_v2`) af samme projekt, og `deliver.py` igen (v2 erstatter v1 i 03_Final).
