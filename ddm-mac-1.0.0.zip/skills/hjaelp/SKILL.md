---
name: hjaelp
description: Forklarer kursisten hvordan content-systemet bruges, hvad der er vigtigt at tænke over, og hvad man gør når noget går galt. Brug når kursisten spørger "hvordan bruger jeg det", "hvor er min video", "det virker ikke", eller skriver /hjaelp.
---

# Hjælp til content-systemet

Svar kort på dansk, ud fra spørgsmålet. Tjek gerne selv: `./_System/.venv/bin/python "${CLAUDE_PLUGIN_ROOT}/scripts/doctor.py"` (installation) og `./_System/.venv/bin/python "${CLAUDE_PLUGIN_ROOT}/scripts/inbox.py" status <format>` (indbakker).

## Sådan bruges det
| Format | Læg i | Du får i |
| --- | --- | --- |
| Talking-head-reel | `00_Indbakke/Talking-head` (én råvideo = én reel) | `03_Final/Talking-head` (reel + `_opslag.txt`) |
| Karrusel | `00_Indbakke/Karrusel` (et Word-dokument, eller en mappe med dokument + billeder) | `03_Final/Karrusel/<opslag>/` (slides 01, 02 … + tekst) |
| Detaljevideo | `00_Indbakke/Detaljevideoer` (én mappe pr. bolig/område med uklippet drone/b-roll) | `03_Final/Detaljevideoer` |
Automatisk (hvert 15. minut, når computeren er tændt og Claude åben) eller med kommandoerne `/ddm-mac:talkinghead-video`, `/ddm-mac:karrusel`, `/ddm-mac:detaljevideo`. Ret brand med "ret mit brand" (skill brand), stil med nye Instagram-links (skill stil). Rettelser til et opslag: skriv ID'et og rettelsen (fx "KA-003: kortere tekst på slide 2") → ny version.

## Vigtigt at tænke over
1. Computeren skal være tændt og Claude-appen åben, ellers venter materialet.
2. Upload hele mappen på én gang; systemet venter 2 minutter efter sidste fil.
3. Skriv dokumenter færdige, før de lægges i indbakken (et halvt Google Docs kan blive hentet).
4. Én mappe = ét opslag; bland ikke to boliger.
5. Fakta skal stå i materialet: systemet opfinder intet.
6. Se altid opslaget igennem, før du poster. Intet postes automatisk.
7. Musik: kun numre du har ret til at bruge (fx Pixabay Music), i `02_Materialer/Musik`.

## Når noget går galt
| Tegn | Hvad du gør |
| --- | --- |
| Intet sker med materialet i indbakken | Er computeren tændt og Claude åben? Kør kommandoen selv. Er den automatiske opgave slået til? |
| "fejlet" i et trin | Skriv "kør <ID> igen"; færdige trin springes over |
| ffmpeg/npx/uv "ikke fundet" | Genstart Claude-appen efter installation; kør doctor.py |
| Instagram-link kan ikke hentes | Prøv den indbyggede browser (skill stil), log ind på instagram.com i Chrome, eller gem skærmbilleder i `02_Materialer/Stil-reference` |
| Forkerte farver/fonte | "ret mit brand"; kør `brand_build.py` igen |
| Video uden lyd (detaljevideo) | `02_Materialer/Musik` er tom; læg numre i, eller tilføj lyd i Instagram |
| Langsom transskription | Normalt uden NVIDIA-grafikkort (processoren arbejder); 1 min. video tager ca. 30–60 sek. |
