---
name: opslagstekst
description: Skriver opslagstekster til Instagram/Facebook og en LinkedIn-version ud fra en videos transskription eller et karruselopslags tekst, i kursistens tone og med kursistens CTA. Bruges af talkinghead-video, karrusel og detaljevideo, og når kursisten beder om en caption.
---

# Opslagstekst

Læs `_System/brand.json` (`tone`, `cta_tekst`, `cta_keyword`, `cta_word`) og `_System/stil.md` (Hooks og tone). Skriv dansk.

## Kilde
Kun videoens transskription eller dokumentets/slidenes tekst. Opfind ingen pointer, tal eller eksempler.

## Instagram / Facebook
1. **Første linje er hooket:** får folk til at trykke "... mere" (under ca. 125 tegn, gerne under 80): en påstand målgruppen genkender, en overraskelse eller en konkret gevinst. Ikke en opsummering.
2. **Brødtekst med værdi, der kan stå alene:** konkrete pointer i den rækkefølge, de kommer; korte afsnit (1–3 sætninger) med en tom linje imellem; nummererede punkter, når indholdet har punkter (overskriften på sin egen linje).
3. **Sprog:** korrekt, naturligt dansk i kursistens tone; du-form; ingen buzzwords eller AI-floskler ("i en verden hvor", "lad os dykke ned i", "game changer").
4. **Afslutning**, hver på sin egen linje: ved videndeling "Gem opslaget og send det til en, der burde vide det her."; altid til sidst brandets CTA (`cta_tekst`, fx "Kommentér GUIDE, så sender jeg dig ...").
5. Højst tre relevante hashtags til sidst.

## LinkedIn
Samme indhold, lidt mere forklaring og faglighed pr. pointe, ingen emojis som punkttegn, højst to hashtags, og CTA'en tilpasset ("Kommentér <nøgleord>, så sender jeg dig linket.").

## Forbudt
Lange tankestreger (— og –): brug punktum, komma eller kolon; søg teksten igennem før du afleverer. Udråbstegn i hver sætning, emojis i hver linje, "Kommenter" uden accent (skriv "Kommentér").

## Format i opslag.md
```
## <hook>

### Instagram / Facebook
<tekst>

### LinkedIn
<tekst>

### Alternative hooks
1. ...
2. ...
```
