---
name: stil
description: Kursisten finder 2-4 Instagram-opslag (reels og karruseller), de kan lide, og systemet henter, transskriberer og analyserer dem og låser stilen i _System/stil.md. Brug ved opsætningen og når kursisten vil ændre stilen eller giver nye referencer.
---

# Stil fra Instagram-referencer

Mål: `_System/stil.md`, en præcis beskrivelse af den stil, kursisten vil ramme, som talkinghead-video og karrusel følger. Brandet (farver/fonte) bevares; stilen handler om opbygning, tempo, layout, tekst og grafik. Skriv dansk, ét trin ad gangen. Python `./_System/.venv/bin/python`, scripts i `${CLAUDE_PLUGIN_ROOT}/scripts/`.

## 1. Find referencer (guide trin for trin)
Forklar: "Find 2–4 opslag på Instagram, hvis stil du gerne vil ligne. Det må gerne være fra andre brancher."
1. Åbn Instagram (app eller instagram.com) og find en reel eller et karruselopslag, du kan lide.
2. Tryk på **⋯** (eller papirflyveren) → **Kopiér link**.
3. Indsæt linket her i chatten. Gentag for 2–4 opslag: gerne 1–2 reels (talking head) og 1–2 karruseller.
Linkene ser ud som `instagram.com/reel/...` (video) eller `instagram.com/p/...` (opslag/karrusel).

## 2. Hent dem
- **Reels/videoer:** `./_System/.venv/bin/python "${CLAUDE_PLUGIN_ROOT}/scripts/ig_hent.py" <link> [<link> ...]`. Offentlige reels virker som regel uden login.
- **Billedkarruseller (`/p/`) og alt, der fejler:** brug den indbyggede browser (Claude-appens browser, ingen login nødvendig):
  1. Åbn linket i den indbyggede browser. Luk cookie-boksen med "Afvis valgfrie cookies" og login-vinduet med krydset.
  2. Kør JavaScript i siden, der klikker "Next" igennem slidene og samler billed-adresserne:
     ```js
     const seen = new Set(); const grab = () => document.querySelectorAll('img').forEach(i => { if (i.naturalWidth >= 1000) seen.add(i.currentSrc || i.src); });
     grab(); for (let k = 0; k < 20; k++) { const b = document.querySelector('button[aria-label="Next"]'); if (!b) break; b.click(); await new Promise(r => setTimeout(r, 1300)); grab(); }
     [...seen]
     ```
  3. Gem billederne: `./_System/.venv/bin/python "${CLAUDE_PLUGIN_ROOT}/scripts/ig_billeder.py" <post-kode> <adresse> <adresse> ...` (post-koden er delen efter `/p/` i linket).
- **Kræver Instagram login, og virker browseren ikke:** spørg "Må jeg bruge dit Instagram-login fra din browser til at hente opslaget? Jeg læser kun din adgang til instagram.com." Kun ved ja: kør `ig_hent.py` med `--login` (kursisten skal være logget ind på instagram.com i Chrome eller Firefox). Sidste udvej: bed kursisten gemme skærmbilleder af slidene (eller en skærmoptagelse af reelen) i `02_Materialer/Stil-reference/<navn>/`.

## 3. Analysér
`./_System/.venv/bin/python "${CLAUDE_PLUGIN_ROOT}/scripts/stil_analyse.py"` → pr. opslag `kontaktark.jpg` og `analyse.json` (længde, antal klip, klip pr. sekund, hvad der bliver sagt). Se hvert kontaktark med Read, og notér:
- **Reels:** layout (person i panel under grafik = "split", eller person i fuld skærm med tekst ovenpå = "fuld"); hvor meget grafik og hvilken slags (kort, lister, tal, skærmbilleder, telefoner); overskrifter (størrelse, store/små bogstaver, accentfarve); undertekster (ét ord ad gangen = "ord", eller korte linjer = "linje"; placering); tempo (klip pr. sekund, hvor ofte der skiftes til fuld skærm); hook (de første 3 sekunder: hvad siges og vises); afslutning/CTA.
- **Karruseller:** antal slides; forside (foto/figur/tekst, bevægelse); tekstmængde pr. slide; slide-typer (liste, før/efter, tal, citat, trin); billedbrug; afslutning.
- **Tale/manus:** hook-formler, sætningslængde, tone, hvordan de afslutter.

## 4. Skriv stil.md og vis et eksempel
Skriv `_System/stil.md` med overskrifterne **Reels**, **Karruseller**, **Hooks og tone**, **Gør altid**, **Undgå**, med konkrete tal (fx "klip til fuld skærm hvert 6.–8. sekund", "overskrift højst 6 ord", "6–8 slides"). Sæt i `_System/brand.json`: `"reel_layout"` ("split" eller "fuld") og `"undertekster"` ("ord" eller "linje"), og kør `brand_build.py` igen.
Opsummér stilen for kursisten i 5–8 punkter, og spørg, om det rammer. Ret til de siger ja. Sæt `"stil": true` i `"opsaetning"` i `_System/ddm.json`.
Giv aldrig referencernes egne logoer, figurer eller tekster videre i kursistens indhold: stilen bruges, indholdet er kursistens eget.
