---
name: brand
description: Guider kursisten trin for trin i at hente sin visuelle identitet ind (brand-PDF, logo, hjemmeside) og låser farver, fonte, CTA, tone og layout i _System/brand.json. Brug ved opsætningen og når kursisten vil ændre farver, fonte, CTA eller tone.
---

# Brand

Mål: `_System/brand.json` + `_System/brand.css`, så alt systemet laver, ligner kursistens brand. Skriv dansk, ét trin ad gangen, og vis altid et eksempel, før noget låses. Arbejd fra arbejdsmappen; Python er `./_System/.venv/bin/python`, scripts i `${CLAUDE_PLUGIN_ROOT}/scripts/`.

## 1. Hvad har du?
Spørg (AskUserQuestion, flere valg): "Hvad har du af dit brand?"
- **En brand-guide / visuel identitet (PDF)** → bed dem lægge filen i `02_Materialer/Brand` (træk den ind i mappen; vis stien). Kør `./_System/.venv/bin/python "${CLAUDE_PLUGIN_ROOT}/scripts/pdf_sider.py" "02_Materialer/Brand/<fil>.pdf"`, og se siderne med Read. Farvekoder og fontnavne står ofte i teksten.
- **Logo** (PNG/SVG, gerne med gennemsigtig baggrund) → i `02_Materialer/Brand`.
- **En hjemmeside** → kør `./_System/.venv/bin/python "${CLAUDE_PLUGIN_ROOT}/scripts/brand_web.py" <adresse>`. Den finder de mest brugte farver, fonte, Google Fonts, logo-kandidater og tager skærmbilleder (`02_Materialer/Brand/fra-hjemmeside/`). Se skærmbillederne og logo-filerne med Read.
- **Intet af det** → spørg om 1–2 farver, de forbinder med sig selv, og et eksempel på en side/profil, hvis udtryk de kan lide. Foreslå så en palette.

## 2. Foreslå et udtryk
Ud fra materialet foreslår du (vis som en kort liste med farvekoder):
- **Farver:** `bg` (baggrund på slides og grafik, ofte mørk for kontrast på Instagram), `surface` (kort), `line`, `chip_line`, `text`, `muted`, `accent` (brandets signaturfarve; bruges til fremhævninger og CTA), `on_accent` (tekst på accentfarven: næsten sort eller hvid), `good`, `bad`, `info`. Brug brandets egne koder; mangler nogle, så udled dem (lysere/mørkere varianter af brandfarverne).
- **Fonte:** `head` (overskrifter, gerne kraftig), `body` (brødtekst), `mono` (små mærkater). Brug brandets fonte, hvis de findes på Google Fonts; ellers den nærmeste Google Font, eller kursistens egne font-filer (`font_filer`, læg dem i `02_Materialer/Brand`).
- **Navn i bunden af slides** (`footer`, fx "Mette Hansen · Nordkyst Bolig"), Instagram-navn (`handle`).
- **CTA:** det ord følgere skal kommentere (`cta_keyword`, fx "GUIDE", "BOLIG", "VURDERING") og hvad de får (`cta_tekst`, fx "Kommentér GUIDE, så sender jeg dig min salgsguide"). Spørg, hvad de faktisk sender folk (ManyChat, en PDF, en vurdering). Ord til at starte CTA'en: `cta_word` ("Kommentér").
- **Tone:** 3–6 ord (fx "varm, rolig, faglig, aldrig sælgende").
- `reel_layout` og `undertekster` sættes af skill `stil` (standard "split" og "ord").

## 3. Vis det, før det låses
Skriv `_System/brand.json` (felterne står øverst i `brand_build.py`), og kør `./_System/.venv/bin/python "${CLAUDE_PLUGIN_ROOT}/scripts/brand_build.py"`. Tjek advarslerne (kontrast, fonte der ikke blev fundet) og ret.
Lav en prøve: opret `01_Projekter/Karrusel/KA-000_brandproeve_<dato>/2_Projekt/slides.json` med 4 slides (motion med husfigur, point, compare, cta), og kør `./_System/.venv/bin/python "${CLAUDE_PLUGIN_ROOT}/scripts/karrusel.py" render <mappe> --udkast`. Vis `2_Projekt/udkast/oversigt.jpg` for kursisten (Read, og fortæl hvor filen ligger, så de kan åbne den).
Spørg: "Ligner det dit brand?" Ret farver/fonte/tekster og vis igen, til de siger ja. Slet bagefter prøveprojektet `KA-000_...` (det er kun en prøve).

## 4. Lås det
Gem brand.json, kør brand_build.py en sidste gang, og sæt `"brand": true` i `"opsaetning"` i `_System/ddm.json`. Fortæl, at brandet kan ændres når som helst ved at skrive "ret mit brand".
